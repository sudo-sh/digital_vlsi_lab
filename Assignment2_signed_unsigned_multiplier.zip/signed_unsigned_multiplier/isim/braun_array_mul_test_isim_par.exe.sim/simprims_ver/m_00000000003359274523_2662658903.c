/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_2844883191_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2844883191", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2844883191.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0788859481_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0788859481", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0788859481.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3831093756_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3831093756", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3831093756.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2636502601_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2636502601", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2636502601.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1450771948_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1450771948", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1450771948.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3644452940_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3644452940", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3644452940.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2269818417_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2269818417", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2269818417.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2688942073_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2688942073", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2688942073.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3277228084_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3277228084", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3277228084.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0308618217_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0308618217", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0308618217.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0750343820_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0750343820", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0750343820.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0920006388_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0920006388", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0920006388.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1276542356_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1276542356", "isim/braun_array_mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1276542356.didat");
}
