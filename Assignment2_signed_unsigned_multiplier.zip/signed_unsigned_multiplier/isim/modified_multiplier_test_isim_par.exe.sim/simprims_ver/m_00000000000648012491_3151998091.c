/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_2538409362_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2538409362", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2538409362.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1544674871_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1544674871", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1544674871.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2269818417_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2269818417", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2269818417.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4264993156_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4264993156", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4264993156.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1796811868_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1796811868", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1796811868.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3292315892_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3292315892", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3292315892.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2498842951_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2498842951", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2498842951.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2314494463_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2314494463", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2314494463.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0896168481_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0896168481", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0896168481.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1118351962_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1118351962", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1118351962.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0308618217_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0308618217", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0308618217.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3644452940_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3644452940", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3644452940.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1605206754_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1605206754", "isim/modified_multiplier_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1605206754.didat");
}
