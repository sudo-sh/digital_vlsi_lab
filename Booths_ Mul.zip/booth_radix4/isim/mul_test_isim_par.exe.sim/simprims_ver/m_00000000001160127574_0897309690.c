/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001160127574_0897309690_3982081013_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3982081013", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3982081013.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0043765963_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0043765963", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0043765963.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0555668931_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0555668931", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0555668931.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0107872502_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0107872502", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0107872502.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3948223996_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3948223996", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3948223996.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1453289778_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1453289778", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1453289778.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1071113584_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1071113584", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1071113584.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0413610053_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0413610053", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0413610053.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3308382656_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3308382656", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3308382656.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3640766279_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3640766279", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3640766279.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0778032713_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0778032713", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0778032713.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0846172366_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0846172366", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0846172366.didat");
}
