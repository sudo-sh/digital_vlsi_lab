/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_3868611985_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3868611985", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3868611985.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0228716178_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0228716178", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0228716178.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3798173100_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3798173100", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3798173100.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1244191642_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1244191642", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1244191642.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0670798499_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0670798499", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0670798499.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2783621284_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2783621284", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2783621284.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3359242653_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3359242653", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3359242653.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2285813223_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2285813223", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2285813223.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4069974173_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4069974173", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4069974173.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3872379163_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3872379163", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3872379163.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0959619600_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0959619600", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0959619600.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1744623321_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1744623321", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1744623321.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0492080035_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0492080035", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0492080035.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0151894565_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0151894565", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0151894565.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3606104366_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3606104366", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3606104366.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1661535972_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1661535972", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1661535972.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4112028143_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4112028143", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4112028143.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0322001579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0322001579", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0322001579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1424091945_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1424091945", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1424091945.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0511094374_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0511094374", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0511094374.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4161200552_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4161200552", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4161200552.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2362142170_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2362142170", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2362142170.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4055156056_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4055156056", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4055156056.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0398756502_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0398756502", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0398756502.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2233519520_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2233519520", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2233519520.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0012558037_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0012558037", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0012558037.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1847031459_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1847031459", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1847031459.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4018009579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4018009579", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4018009579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2033575530_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2033575530", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2033575530.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0071978728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0071978728", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0071978728.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3951568342_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3951568342", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3951568342.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0156516015_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0156516015", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0156516015.didat");
}
