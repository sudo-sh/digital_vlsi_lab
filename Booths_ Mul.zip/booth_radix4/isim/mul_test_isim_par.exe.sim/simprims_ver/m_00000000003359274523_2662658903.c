/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_4186466186_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4186466186", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4186466186.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2455493091_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2455493091", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2455493091.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3247168877_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3247168877", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3247168877.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0875352663_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0875352663", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0875352663.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0592954900_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0592954900", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0592954900.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2107224797_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2107224797", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2107224797.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3745705438_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3745705438", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3745705438.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3361766679_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3361766679", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3361766679.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0716990062_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0716990062", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0716990062.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3432361258_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3432361258", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3432361258.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3313372496_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3313372496", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3313372496.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3139665943_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3139665943", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3139665943.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0813729504_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0813729504", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0813729504.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0664933929_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0664933929", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0664933929.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0776582739_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0776582739", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0776582739.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2703188121_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2703188121", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2703188121.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2532805972_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2532805972", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2532805972.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1036481069_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1036481069", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1036481069.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2891486292_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2891486292", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2891486292.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3743115604_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3743115604", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3743115604.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1134231402_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1134231402", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1134231402.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3523549459_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3523549459", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3523549459.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0506407660_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0506407660", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0506407660.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3689855337_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3689855337", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3689855337.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4243796373_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4243796373", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4243796373.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0819528298_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0819528298", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0819528298.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0450558673_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0450558673", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0450558673.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1323109287_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1323109287", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1323109287.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4058857938_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4058857938", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4058857938.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2885751006_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2885751006", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2885751006.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1225457247_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1225457247", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1225457247.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1136884704_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1136884704", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1136884704.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2834612451_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2834612451", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2834612451.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1194765277_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1194765277", "isim/mul_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1194765277.didat");
}
