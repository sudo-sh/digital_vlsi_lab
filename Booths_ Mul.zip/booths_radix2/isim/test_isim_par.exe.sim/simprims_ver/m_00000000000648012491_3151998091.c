/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_0151894565_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0151894565", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0151894565.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3951568342_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3951568342", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3951568342.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0322001579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0322001579", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0322001579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0071978728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0071978728", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0071978728.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4058857938_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4058857938", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4058857938.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3868611985_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3868611985", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3868611985.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3745705438_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3745705438", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3745705438.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0506407660_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0506407660", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0506407660.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0156516015_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0156516015", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0156516015.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0776582739_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0776582739", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0776582739.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4112028143_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4112028143", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4112028143.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3798173100_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3798173100", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3798173100.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2033575530_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2033575530", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2033575530.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0060668688_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0060668688", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0060668688.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0450558673_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0450558673", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0450558673.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0228716178_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0228716178", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0228716178.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0813729504_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0813729504", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0813729504.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3965702190_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3965702190", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3965702190.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4055156056_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4055156056", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4055156056.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3359242653_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3359242653", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3359242653.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3247168877_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3247168877", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3247168877.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0511094374_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0511094374", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0511094374.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0670798499_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0670798499", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0670798499.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0875352663_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0875352663", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0875352663.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4018009579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4018009579", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4018009579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3606104366_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3606104366", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3606104366.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3689855337_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3689855337", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3689855337.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0012558037_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0012558037", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0012558037.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0959619600_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0959619600", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0959619600.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2532805972_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2532805972", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2532805972.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3523549459_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3523549459", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3523549459.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1036481069_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1036481069", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1036481069.didat");
}
