/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_0151894565_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0151894565", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0151894565.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3798173100_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3798173100", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3798173100.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0450558673_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0450558673", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0450558673.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0228716178_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0228716178", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0228716178.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4055156056_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4055156056", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4055156056.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3359242653_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3359242653", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3359242653.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3247168877_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3247168877", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3247168877.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0511094374_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0511094374", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0511094374.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0670798499_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0670798499", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0670798499.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0875352663_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0875352663", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0875352663.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4018009579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4018009579", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4018009579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3606104366_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3606104366", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3606104366.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2233519520_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2233519520", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2233519520.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1134231402_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1134231402", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1134231402.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0012558037_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0012558037", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0012558037.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0959619600_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0959619600", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0959619600.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0813729504_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0813729504", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0813729504.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2891486292_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2891486292", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2891486292.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3951568342_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3951568342", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3951568342.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3523549459_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3523549459", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3523549459.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1323109287_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1323109287", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1323109287.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0071978728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0071978728", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0071978728.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0819528298_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0819528298", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0819528298.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2834612451_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2834612451", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2834612451.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3868611985_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3868611985", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3868611985.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3743115604_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3743115604", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3743115604.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1136884704_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1136884704", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1136884704.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0156516015_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0156516015", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0156516015.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0776582739_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0776582739", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0776582739.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0716990062_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0716990062", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0716990062.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2885751006_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2885751006", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2885751006.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0664933929_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0664933929", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0664933929.didat");
}
