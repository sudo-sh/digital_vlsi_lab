/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_4186466186_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4186466186", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4186466186.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4069974173_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4069974173", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4069974173.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3139665943_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3139665943", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3139665943.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1194765277_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1194765277", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1194765277.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3313372496_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3313372496", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3313372496.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2783621284_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2783621284", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2783621284.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3432361258_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3432361258", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3432361258.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1036481069_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1036481069", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1036481069.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2532805972_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2532805972", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2532805972.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2033575530_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2033575530", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2033575530.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2285813223_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2285813223", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2285813223.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1744623321_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1744623321", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1744623321.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2362142170_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2362142170", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2362142170.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1847031459_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1847031459", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1847031459.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1661535972_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1661535972", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1661535972.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1793238686_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1793238686", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1793238686.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2178227613_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2178227613", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2178227613.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3689855337_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3689855337", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3689855337.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4161200552_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4161200552", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4161200552.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0492080035_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0492080035", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0492080035.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0322001579_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0322001579", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0322001579.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3745705438_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3745705438", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3745705438.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4243796373_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4243796373", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4243796373.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2703188121_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2703188121", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2703188121.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0506407660_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0506407660", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0506407660.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1244191642_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1244191642", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1244191642.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4058857938_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4058857938", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4058857938.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0592954900_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0592954900", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0592954900.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4112028143_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4112028143", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4112028143.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1424091945_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1424091945", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1424091945.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1225457247_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1225457247", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1225457247.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3361766679_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3361766679", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3361766679.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3872379163_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3872379163", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3872379163.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0398756502_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0398756502", "isim/test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0398756502.didat");
}
