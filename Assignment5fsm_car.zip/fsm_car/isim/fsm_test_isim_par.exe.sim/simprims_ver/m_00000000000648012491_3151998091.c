/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_2981331234_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2981331234", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2981331234.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1518615073_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1518615073", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1518615073.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3092783448_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3092783448", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3092783448.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1472450284_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1472450284", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1472450284.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3087115730_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3087115730", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3087115730.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1225457247_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1225457247", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1225457247.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2798163297_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2798163297", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2798163297.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1308569186_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1308569186", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1308569186.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1584523804_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1584523804", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1584523804.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3041284383_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3041284383", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3041284383.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1085856431_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1085856431", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1085856431.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1469729382_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1469729382", "isim/fsm_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1469729382.didat");
}
