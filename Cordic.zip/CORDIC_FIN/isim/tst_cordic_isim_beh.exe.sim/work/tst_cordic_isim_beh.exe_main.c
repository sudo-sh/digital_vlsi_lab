/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_12179591876491011946_1482756881_init();
    work_m_10091390206675817477_3331260499_init();
    work_m_10378778675435624189_4011412499_init();
    work_m_06711699078304937283_3997291765_init();
    work_m_13070587735732588903_4014191922_init();
    work_m_17161313995212056482_2906101138_init();
    work_m_09442649383223532931_2806463104_init();
    work_m_16541823861846354283_2073120511_init();


    xsi_register_tops("work_m_09442649383223532931_2806463104");
    xsi_register_tops("work_m_16541823861846354283_2073120511");


    return xsi_run_simulation(argc, argv);

}
