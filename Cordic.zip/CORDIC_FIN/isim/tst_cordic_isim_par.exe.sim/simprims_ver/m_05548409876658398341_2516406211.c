/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static int ng0[] = {0, 0};
static int ng1[] = {1, 0};
static int ng2[] = {2, 0};
static int ng3[] = {3, 0};
static unsigned int ng4[] = {1U, 1U};



static int sp_lut4_mux4(char *t1, char *t2)
{
    char t6[8];
    char t18[8];
    char t24[8];
    char t40[8];
    char t54[8];
    char t70[8];
    char t82[8];
    char t88[8];
    char t104[8];
    char t118[8];
    char t126[8];
    char t163[8];
    char t171[8];
    char t178[8];
    char t183[8];
    char t192[8];
    char t208[8];
    char t216[8];
    char t257[8];
    int t0;
    char *t3;
    char *t4;
    char *t5;
    char *t7;
    char *t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    char *t16;
    char *t17;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t25;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    unsigned int t41;
    unsigned int t42;
    unsigned int t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    char *t71;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t79;
    char *t80;
    char *t81;
    char *t83;
    char *t84;
    char *t85;
    char *t86;
    char *t87;
    char *t89;
    char *t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    char *t103;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    char *t108;
    char *t109;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t119;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    char *t125;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    char *t130;
    char *t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    char *t140;
    char *t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t154;
    unsigned int t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    unsigned int t159;
    char *t160;
    char *t161;
    char *t162;
    char *t164;
    char *t165;
    char *t166;
    char *t167;
    char *t168;
    char *t169;
    char *t170;
    char *t172;
    char *t173;
    char *t174;
    char *t175;
    char *t176;
    char *t177;
    char *t179;
    char *t180;
    char *t181;
    char *t182;
    char *t184;
    char *t185;
    char *t186;
    unsigned int t187;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    char *t191;
    char *t193;
    char *t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    char *t207;
    char *t209;
    unsigned int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    char *t215;
    unsigned int t217;
    unsigned int t218;
    unsigned int t219;
    char *t220;
    char *t221;
    char *t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    unsigned int t229;
    char *t230;
    char *t231;
    unsigned int t232;
    unsigned int t233;
    unsigned int t234;
    unsigned int t235;
    unsigned int t236;
    unsigned int t237;
    unsigned int t238;
    unsigned int t239;
    int t240;
    int t241;
    unsigned int t242;
    unsigned int t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    char *t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    unsigned int t252;
    unsigned int t253;
    char *t254;
    char *t255;
    char *t256;
    char *t258;
    char *t259;
    unsigned int t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    unsigned int t264;
    unsigned int t265;
    char *t266;

LAB0:    t0 = 1;

LAB2:    t3 = (t1 + 4232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    memset(t6, 0, 8);
    t7 = (t6 + 4);
    t8 = (t5 + 4);
    t9 = *((unsigned int *)t5);
    t10 = (t9 >> 1);
    t11 = (t10 & 1);
    *((unsigned int *)t6) = t11;
    t12 = *((unsigned int *)t8);
    t13 = (t12 >> 1);
    t14 = (t13 & 1);
    *((unsigned int *)t7) = t14;
    t15 = (t1 + 4232);
    t16 = (t15 + 56U);
    t17 = *((char **)t16);
    t19 = (t1 + 4232);
    t20 = (t19 + 72U);
    t21 = *((char **)t20);
    t22 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t18, 32, t17, t21, 2, t22, 32, 1);
    t23 = ((char*)((ng1)));
    memset(t24, 0, 8);
    t25 = (t18 + 4);
    t26 = (t23 + 4);
    t27 = *((unsigned int *)t18);
    t28 = *((unsigned int *)t23);
    t29 = (t27 ^ t28);
    t30 = *((unsigned int *)t25);
    t31 = *((unsigned int *)t26);
    t32 = (t30 ^ t31);
    t33 = (t29 | t32);
    t34 = *((unsigned int *)t25);
    t35 = *((unsigned int *)t26);
    t36 = (t34 | t35);
    t37 = (~(t36));
    t38 = (t33 & t37);
    if (t38 != 0)
        goto LAB6;

LAB3:    if (t36 != 0)
        goto LAB5;

LAB4:    *((unsigned int *)t24) = 1;

LAB6:    t41 = *((unsigned int *)t6);
    t42 = *((unsigned int *)t24);
    t43 = (t41 ^ t42);
    *((unsigned int *)t40) = t43;
    t44 = (t6 + 4);
    t45 = (t24 + 4);
    t46 = (t40 + 4);
    t47 = *((unsigned int *)t44);
    t48 = *((unsigned int *)t45);
    t49 = (t47 | t48);
    *((unsigned int *)t46) = t49;
    t50 = *((unsigned int *)t46);
    t51 = (t50 != 0);
    if (t51 == 1)
        goto LAB7;

LAB8:
LAB9:    memset(t54, 0, 8);
    t55 = (t40 + 4);
    t56 = *((unsigned int *)t55);
    t57 = (~(t56));
    t58 = *((unsigned int *)t40);
    t59 = (t58 & t57);
    t60 = (t59 & 1U);
    if (t60 != 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t55) != 0)
        goto LAB12;

LAB13:    t62 = (t54 + 4);
    t63 = *((unsigned int *)t54);
    t64 = (!(t63));
    t65 = *((unsigned int *)t62);
    t66 = (t64 || t65);
    if (t66 > 0)
        goto LAB14;

LAB15:    memcpy(t126, t54, 8);

LAB16:    t154 = (t126 + 4);
    t155 = *((unsigned int *)t154);
    t156 = (~(t155));
    t157 = *((unsigned int *)t126);
    t158 = (t157 & t156);
    t159 = (t158 != 0);
    if (t159 > 0)
        goto LAB31;

LAB32:    t3 = (t1 + 4072);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t1 + 4072);
    t8 = (t7 + 72U);
    t15 = *((char **)t8);
    t16 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t15, 2, t16, 32, 1);
    t17 = (t1 + 4072);
    t19 = (t17 + 56U);
    t20 = *((char **)t19);
    t21 = (t1 + 4072);
    t22 = (t21 + 72U);
    t23 = *((char **)t22);
    t25 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t18, 32, t20, t23, 2, t25, 32, 1);
    t9 = *((unsigned int *)t6);
    t10 = *((unsigned int *)t18);
    t11 = (t9 ^ t10);
    *((unsigned int *)t24) = t11;
    t26 = (t6 + 4);
    t39 = (t18 + 4);
    t44 = (t24 + 4);
    t12 = *((unsigned int *)t26);
    t13 = *((unsigned int *)t39);
    t14 = (t12 | t13);
    *((unsigned int *)t44) = t14;
    t27 = *((unsigned int *)t44);
    t28 = (t27 != 0);
    if (t28 == 1)
        goto LAB34;

LAB35:
LAB36:    t45 = ((char*)((ng0)));
    memset(t40, 0, 8);
    t46 = (t24 + 4);
    t55 = (t45 + 4);
    t31 = *((unsigned int *)t24);
    t32 = *((unsigned int *)t45);
    t33 = (t31 ^ t32);
    t34 = *((unsigned int *)t46);
    t35 = *((unsigned int *)t55);
    t36 = (t34 ^ t35);
    t37 = (t33 | t36);
    t38 = *((unsigned int *)t46);
    t41 = *((unsigned int *)t55);
    t42 = (t38 | t41);
    t43 = (~(t42));
    t47 = (t37 & t43);
    if (t47 != 0)
        goto LAB40;

LAB37:    if (t42 != 0)
        goto LAB39;

LAB38:    *((unsigned int *)t40) = 1;

LAB40:    memset(t54, 0, 8);
    t62 = (t40 + 4);
    t48 = *((unsigned int *)t62);
    t49 = (~(t48));
    t50 = *((unsigned int *)t40);
    t51 = (t50 & t49);
    t52 = (t51 & 1U);
    if (t52 != 0)
        goto LAB41;

LAB42:    if (*((unsigned int *)t62) != 0)
        goto LAB43;

LAB44:    t68 = (t54 + 4);
    t53 = *((unsigned int *)t54);
    t56 = *((unsigned int *)t68);
    t57 = (t53 || t56);
    if (t57 > 0)
        goto LAB45;

LAB46:    memcpy(t126, t54, 8);

LAB47:    memset(t163, 0, 8);
    t164 = (t126 + 4);
    t143 = *((unsigned int *)t164);
    t144 = (~(t143));
    t146 = *((unsigned int *)t126);
    t147 = (t146 & t144);
    t148 = (t147 & 1U);
    if (t148 != 0)
        goto LAB62;

LAB63:    if (*((unsigned int *)t164) != 0)
        goto LAB64;

LAB65:    t166 = (t163 + 4);
    t150 = *((unsigned int *)t163);
    t151 = *((unsigned int *)t166);
    t152 = (t150 || t151);
    if (t152 > 0)
        goto LAB66;

LAB67:    memcpy(t216, t163, 8);

LAB68:    t248 = (t216 + 4);
    t249 = *((unsigned int *)t248);
    t250 = (~(t249));
    t251 = *((unsigned int *)t216);
    t252 = (t251 & t250);
    t253 = (t252 != 0);
    if (t253 > 0)
        goto LAB83;

LAB84:    t3 = (t1 + 4232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t1 + 4232);
    t8 = (t7 + 72U);
    t15 = *((char **)t8);
    t16 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t15, 2, t16, 32, 1);
    t17 = ((char*)((ng0)));
    memset(t18, 0, 8);
    t19 = (t6 + 4);
    t20 = (t17 + 4);
    t9 = *((unsigned int *)t6);
    t10 = *((unsigned int *)t17);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t19);
    t13 = *((unsigned int *)t20);
    t14 = (t12 ^ t13);
    t27 = (t11 | t14);
    t28 = *((unsigned int *)t19);
    t29 = *((unsigned int *)t20);
    t30 = (t28 | t29);
    t31 = (~(t30));
    t32 = (t27 & t31);
    if (t32 != 0)
        goto LAB89;

LAB86:    if (t30 != 0)
        goto LAB88;

LAB87:    *((unsigned int *)t18) = 1;

LAB89:    memset(t24, 0, 8);
    t22 = (t18 + 4);
    t33 = *((unsigned int *)t22);
    t34 = (~(t33));
    t35 = *((unsigned int *)t18);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB90;

LAB91:    if (*((unsigned int *)t22) != 0)
        goto LAB92;

LAB93:    t25 = (t24 + 4);
    t38 = *((unsigned int *)t24);
    t41 = *((unsigned int *)t25);
    t42 = (t38 || t41);
    if (t42 > 0)
        goto LAB94;

LAB95:    memcpy(t88, t24, 8);

LAB96:    t87 = (t88 + 4);
    t133 = *((unsigned int *)t87);
    t134 = (~(t133));
    t135 = *((unsigned int *)t88);
    t136 = (t135 & t134);
    t137 = (t136 != 0);
    if (t137 > 0)
        goto LAB108;

LAB109:    t3 = (t1 + 4232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t1 + 4232);
    t8 = (t7 + 72U);
    t15 = *((char **)t8);
    t16 = ((char*)((ng1)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t15, 2, t16, 32, 1);
    t17 = ((char*)((ng1)));
    memset(t18, 0, 8);
    t19 = (t6 + 4);
    t20 = (t17 + 4);
    t9 = *((unsigned int *)t6);
    t10 = *((unsigned int *)t17);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t19);
    t13 = *((unsigned int *)t20);
    t14 = (t12 ^ t13);
    t27 = (t11 | t14);
    t28 = *((unsigned int *)t19);
    t29 = *((unsigned int *)t20);
    t30 = (t28 | t29);
    t31 = (~(t30));
    t32 = (t27 & t31);
    if (t32 != 0)
        goto LAB114;

LAB111:    if (t30 != 0)
        goto LAB113;

LAB112:    *((unsigned int *)t18) = 1;

LAB114:    memset(t24, 0, 8);
    t22 = (t18 + 4);
    t33 = *((unsigned int *)t22);
    t34 = (~(t33));
    t35 = *((unsigned int *)t18);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB115;

LAB116:    if (*((unsigned int *)t22) != 0)
        goto LAB117;

LAB118:    t25 = (t24 + 4);
    t38 = *((unsigned int *)t24);
    t41 = *((unsigned int *)t25);
    t42 = (t38 || t41);
    if (t42 > 0)
        goto LAB119;

LAB120:    memcpy(t88, t24, 8);

LAB121:    t87 = (t88 + 4);
    t133 = *((unsigned int *)t87);
    t134 = (~(t133));
    t135 = *((unsigned int *)t88);
    t136 = (t135 & t134);
    t137 = (t136 != 0);
    if (t137 > 0)
        goto LAB133;

LAB134:    t3 = (t1 + 4232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t1 + 4232);
    t8 = (t7 + 72U);
    t15 = *((char **)t8);
    t16 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t15, 2, t16, 32, 1);
    t17 = ((char*)((ng0)));
    memset(t18, 0, 8);
    t19 = (t6 + 4);
    t20 = (t17 + 4);
    t9 = *((unsigned int *)t6);
    t10 = *((unsigned int *)t17);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t19);
    t13 = *((unsigned int *)t20);
    t14 = (t12 ^ t13);
    t27 = (t11 | t14);
    t28 = *((unsigned int *)t19);
    t29 = *((unsigned int *)t20);
    t30 = (t28 | t29);
    t31 = (~(t30));
    t32 = (t27 & t31);
    if (t32 != 0)
        goto LAB139;

LAB136:    if (t30 != 0)
        goto LAB138;

LAB137:    *((unsigned int *)t18) = 1;

LAB139:    memset(t24, 0, 8);
    t22 = (t18 + 4);
    t33 = *((unsigned int *)t22);
    t34 = (~(t33));
    t35 = *((unsigned int *)t18);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB140;

LAB141:    if (*((unsigned int *)t22) != 0)
        goto LAB142;

LAB143:    t25 = (t24 + 4);
    t38 = *((unsigned int *)t24);
    t41 = *((unsigned int *)t25);
    t42 = (t38 || t41);
    if (t42 > 0)
        goto LAB144;

LAB145:    memcpy(t88, t24, 8);

LAB146:    t87 = (t88 + 4);
    t133 = *((unsigned int *)t87);
    t134 = (~(t133));
    t135 = *((unsigned int *)t88);
    t136 = (t135 & t134);
    t137 = (t136 != 0);
    if (t137 > 0)
        goto LAB158;

LAB159:    t3 = (t1 + 4232);
    t4 = (t3 + 56U);
    t5 = *((char **)t4);
    t7 = (t1 + 4232);
    t8 = (t7 + 72U);
    t15 = *((char **)t8);
    t16 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t6, 32, t5, t15, 2, t16, 32, 1);
    t17 = ((char*)((ng1)));
    memset(t18, 0, 8);
    t19 = (t6 + 4);
    t20 = (t17 + 4);
    t9 = *((unsigned int *)t6);
    t10 = *((unsigned int *)t17);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t19);
    t13 = *((unsigned int *)t20);
    t14 = (t12 ^ t13);
    t27 = (t11 | t14);
    t28 = *((unsigned int *)t19);
    t29 = *((unsigned int *)t20);
    t30 = (t28 | t29);
    t31 = (~(t30));
    t32 = (t27 & t31);
    if (t32 != 0)
        goto LAB164;

LAB161:    if (t30 != 0)
        goto LAB163;

LAB162:    *((unsigned int *)t18) = 1;

LAB164:    memset(t24, 0, 8);
    t22 = (t18 + 4);
    t33 = *((unsigned int *)t22);
    t34 = (~(t33));
    t35 = *((unsigned int *)t18);
    t36 = (t35 & t34);
    t37 = (t36 & 1U);
    if (t37 != 0)
        goto LAB165;

LAB166:    if (*((unsigned int *)t22) != 0)
        goto LAB167;

LAB168:    t25 = (t24 + 4);
    t38 = *((unsigned int *)t24);
    t41 = *((unsigned int *)t25);
    t42 = (t38 || t41);
    if (t42 > 0)
        goto LAB169;

LAB170:    memcpy(t88, t24, 8);

LAB171:    t87 = (t88 + 4);
    t133 = *((unsigned int *)t87);
    t134 = (~(t133));
    t135 = *((unsigned int *)t88);
    t136 = (t135 & t134);
    t137 = (t136 != 0);
    if (t137 > 0)
        goto LAB183;

LAB184:    t3 = ((char*)((ng4)));
    t4 = (t1 + 3912);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 1);

LAB185:
LAB160:
LAB135:
LAB110:
LAB85:
LAB33:    t0 = 0;

LAB1:    return t0;
LAB5:    t39 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB6;

LAB7:    t52 = *((unsigned int *)t40);
    t53 = *((unsigned int *)t46);
    *((unsigned int *)t40) = (t52 | t53);
    goto LAB9;

LAB10:    *((unsigned int *)t54) = 1;
    goto LAB13;

LAB12:    t61 = (t54 + 4);
    *((unsigned int *)t54) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB13;

LAB14:    t67 = (t1 + 4232);
    t68 = (t67 + 56U);
    t69 = *((char **)t68);
    memset(t70, 0, 8);
    t71 = (t70 + 4);
    t72 = (t69 + 4);
    t73 = *((unsigned int *)t69);
    t74 = (t73 >> 1);
    t75 = (t74 & 1);
    *((unsigned int *)t70) = t75;
    t76 = *((unsigned int *)t72);
    t77 = (t76 >> 1);
    t78 = (t77 & 1);
    *((unsigned int *)t71) = t78;
    t79 = (t1 + 4232);
    t80 = (t79 + 56U);
    t81 = *((char **)t80);
    t83 = (t1 + 4232);
    t84 = (t83 + 72U);
    t85 = *((char **)t84);
    t86 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t82, 32, t81, t85, 2, t86, 32, 1);
    t87 = ((char*)((ng0)));
    memset(t88, 0, 8);
    t89 = (t82 + 4);
    t90 = (t87 + 4);
    t91 = *((unsigned int *)t82);
    t92 = *((unsigned int *)t87);
    t93 = (t91 ^ t92);
    t94 = *((unsigned int *)t89);
    t95 = *((unsigned int *)t90);
    t96 = (t94 ^ t95);
    t97 = (t93 | t96);
    t98 = *((unsigned int *)t89);
    t99 = *((unsigned int *)t90);
    t100 = (t98 | t99);
    t101 = (~(t100));
    t102 = (t97 & t101);
    if (t102 != 0)
        goto LAB20;

LAB17:    if (t100 != 0)
        goto LAB19;

LAB18:    *((unsigned int *)t88) = 1;

LAB20:    t105 = *((unsigned int *)t70);
    t106 = *((unsigned int *)t88);
    t107 = (t105 ^ t106);
    *((unsigned int *)t104) = t107;
    t108 = (t70 + 4);
    t109 = (t88 + 4);
    t110 = (t104 + 4);
    t111 = *((unsigned int *)t108);
    t112 = *((unsigned int *)t109);
    t113 = (t111 | t112);
    *((unsigned int *)t110) = t113;
    t114 = *((unsigned int *)t110);
    t115 = (t114 != 0);
    if (t115 == 1)
        goto LAB21;

LAB22:
LAB23:    memset(t118, 0, 8);
    t119 = (t104 + 4);
    t120 = *((unsigned int *)t119);
    t121 = (~(t120));
    t122 = *((unsigned int *)t104);
    t123 = (t122 & t121);
    t124 = (t123 & 1U);
    if (t124 != 0)
        goto LAB24;

LAB25:    if (*((unsigned int *)t119) != 0)
        goto LAB26;

LAB27:    t127 = *((unsigned int *)t54);
    t128 = *((unsigned int *)t118);
    t129 = (t127 | t128);
    *((unsigned int *)t126) = t129;
    t130 = (t54 + 4);
    t131 = (t118 + 4);
    t132 = (t126 + 4);
    t133 = *((unsigned int *)t130);
    t134 = *((unsigned int *)t131);
    t135 = (t133 | t134);
    *((unsigned int *)t132) = t135;
    t136 = *((unsigned int *)t132);
    t137 = (t136 != 0);
    if (t137 == 1)
        goto LAB28;

LAB29:
LAB30:    goto LAB16;

LAB19:    t103 = (t88 + 4);
    *((unsigned int *)t88) = 1;
    *((unsigned int *)t103) = 1;
    goto LAB20;

LAB21:    t116 = *((unsigned int *)t104);
    t117 = *((unsigned int *)t110);
    *((unsigned int *)t104) = (t116 | t117);
    goto LAB23;

LAB24:    *((unsigned int *)t118) = 1;
    goto LAB27;

LAB26:    t125 = (t118 + 4);
    *((unsigned int *)t118) = 1;
    *((unsigned int *)t125) = 1;
    goto LAB27;

LAB28:    t138 = *((unsigned int *)t126);
    t139 = *((unsigned int *)t132);
    *((unsigned int *)t126) = (t138 | t139);
    t140 = (t54 + 4);
    t141 = (t118 + 4);
    t142 = *((unsigned int *)t140);
    t143 = (~(t142));
    t144 = *((unsigned int *)t54);
    t145 = (t144 & t143);
    t146 = *((unsigned int *)t141);
    t147 = (~(t146));
    t148 = *((unsigned int *)t118);
    t149 = (t148 & t147);
    t150 = (~(t145));
    t151 = (~(t149));
    t152 = *((unsigned int *)t132);
    *((unsigned int *)t132) = (t152 & t150);
    t153 = *((unsigned int *)t132);
    *((unsigned int *)t132) = (t153 & t151);
    goto LAB30;

LAB31:    t160 = (t1 + 4072);
    t161 = (t160 + 56U);
    t162 = *((char **)t161);
    t164 = (t1 + 4072);
    t165 = (t164 + 72U);
    t166 = *((char **)t165);
    t167 = (t1 + 4232);
    t168 = (t167 + 56U);
    t169 = *((char **)t168);
    xsi_vlog_generic_get_index_select_value(t163, 1, t162, t166, 2, t169, 2, 2);
    t170 = (t1 + 3912);
    xsi_vlogvar_assign_value(t170, t163, 0, 0, 1);
    goto LAB33;

LAB34:    t29 = *((unsigned int *)t24);
    t30 = *((unsigned int *)t44);
    *((unsigned int *)t24) = (t29 | t30);
    goto LAB36;

LAB39:    t61 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB40;

LAB41:    *((unsigned int *)t54) = 1;
    goto LAB44;

LAB43:    t67 = (t54 + 4);
    *((unsigned int *)t54) = 1;
    *((unsigned int *)t67) = 1;
    goto LAB44;

LAB45:    t69 = (t1 + 4072);
    t71 = (t69 + 56U);
    t72 = *((char **)t71);
    t79 = (t1 + 4072);
    t80 = (t79 + 72U);
    t81 = *((char **)t80);
    t83 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t70, 32, t72, t81, 2, t83, 32, 1);
    t84 = (t1 + 4072);
    t85 = (t84 + 56U);
    t86 = *((char **)t85);
    t87 = (t1 + 4072);
    t89 = (t87 + 72U);
    t90 = *((char **)t89);
    t103 = ((char*)((ng3)));
    xsi_vlog_generic_get_index_select_value(t82, 32, t86, t90, 2, t103, 32, 1);
    t58 = *((unsigned int *)t70);
    t59 = *((unsigned int *)t82);
    t60 = (t58 ^ t59);
    *((unsigned int *)t88) = t60;
    t108 = (t70 + 4);
    t109 = (t82 + 4);
    t110 = (t88 + 4);
    t63 = *((unsigned int *)t108);
    t64 = *((unsigned int *)t109);
    t65 = (t63 | t64);
    *((unsigned int *)t110) = t65;
    t66 = *((unsigned int *)t110);
    t73 = (t66 != 0);
    if (t73 == 1)
        goto LAB48;

LAB49:
LAB50:    t119 = ((char*)((ng0)));
    memset(t104, 0, 8);
    t125 = (t88 + 4);
    t130 = (t119 + 4);
    t76 = *((unsigned int *)t88);
    t77 = *((unsigned int *)t119);
    t78 = (t76 ^ t77);
    t91 = *((unsigned int *)t125);
    t92 = *((unsigned int *)t130);
    t93 = (t91 ^ t92);
    t94 = (t78 | t93);
    t95 = *((unsigned int *)t125);
    t96 = *((unsigned int *)t130);
    t97 = (t95 | t96);
    t98 = (~(t97));
    t99 = (t94 & t98);
    if (t99 != 0)
        goto LAB54;

LAB51:    if (t97 != 0)
        goto LAB53;

LAB52:    *((unsigned int *)t104) = 1;

LAB54:    memset(t118, 0, 8);
    t132 = (t104 + 4);
    t100 = *((unsigned int *)t132);
    t101 = (~(t100));
    t102 = *((unsigned int *)t104);
    t105 = (t102 & t101);
    t106 = (t105 & 1U);
    if (t106 != 0)
        goto LAB55;

LAB56:    if (*((unsigned int *)t132) != 0)
        goto LAB57;

LAB58:    t107 = *((unsigned int *)t54);
    t111 = *((unsigned int *)t118);
    t112 = (t107 & t111);
    *((unsigned int *)t126) = t112;
    t141 = (t54 + 4);
    t154 = (t118 + 4);
    t160 = (t126 + 4);
    t113 = *((unsigned int *)t141);
    t114 = *((unsigned int *)t154);
    t115 = (t113 | t114);
    *((unsigned int *)t160) = t115;
    t116 = *((unsigned int *)t160);
    t117 = (t116 != 0);
    if (t117 == 1)
        goto LAB59;

LAB60:
LAB61:    goto LAB47;

LAB48:    t74 = *((unsigned int *)t88);
    t75 = *((unsigned int *)t110);
    *((unsigned int *)t88) = (t74 | t75);
    goto LAB50;

LAB53:    t131 = (t104 + 4);
    *((unsigned int *)t104) = 1;
    *((unsigned int *)t131) = 1;
    goto LAB54;

LAB55:    *((unsigned int *)t118) = 1;
    goto LAB58;

LAB57:    t140 = (t118 + 4);
    *((unsigned int *)t118) = 1;
    *((unsigned int *)t140) = 1;
    goto LAB58;

LAB59:    t120 = *((unsigned int *)t126);
    t121 = *((unsigned int *)t160);
    *((unsigned int *)t126) = (t120 | t121);
    t161 = (t54 + 4);
    t162 = (t118 + 4);
    t122 = *((unsigned int *)t54);
    t123 = (~(t122));
    t124 = *((unsigned int *)t161);
    t127 = (~(t124));
    t128 = *((unsigned int *)t118);
    t129 = (~(t128));
    t133 = *((unsigned int *)t162);
    t134 = (~(t133));
    t145 = (t123 & t127);
    t149 = (t129 & t134);
    t135 = (~(t145));
    t136 = (~(t149));
    t137 = *((unsigned int *)t160);
    *((unsigned int *)t160) = (t137 & t135);
    t138 = *((unsigned int *)t160);
    *((unsigned int *)t160) = (t138 & t136);
    t139 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t139 & t135);
    t142 = *((unsigned int *)t126);
    *((unsigned int *)t126) = (t142 & t136);
    goto LAB61;

LAB62:    *((unsigned int *)t163) = 1;
    goto LAB65;

LAB64:    t165 = (t163 + 4);
    *((unsigned int *)t163) = 1;
    *((unsigned int *)t165) = 1;
    goto LAB65;

LAB66:    t167 = (t1 + 4072);
    t168 = (t167 + 56U);
    t169 = *((char **)t168);
    t170 = (t1 + 4072);
    t172 = (t170 + 72U);
    t173 = *((char **)t172);
    t174 = ((char*)((ng0)));
    xsi_vlog_generic_get_index_select_value(t171, 32, t169, t173, 2, t174, 32, 1);
    t175 = (t1 + 4072);
    t176 = (t175 + 56U);
    t177 = *((char **)t176);
    t179 = (t1 + 4072);
    t180 = (t179 + 72U);
    t181 = *((char **)t180);
    t182 = ((char*)((ng2)));
    xsi_vlog_generic_get_index_select_value(t178, 32, t177, t181, 2, t182, 32, 1);
    t153 = *((unsigned int *)t171);
    t155 = *((unsigned int *)t178);
    t156 = (t153 ^ t155);
    *((unsigned int *)t183) = t156;
    t184 = (t171 + 4);
    t185 = (t178 + 4);
    t186 = (t183 + 4);
    t157 = *((unsigned int *)t184);
    t158 = *((unsigned int *)t185);
    t159 = (t157 | t158);
    *((unsigned int *)t186) = t159;
    t187 = *((unsigned int *)t186);
    t188 = (t187 != 0);
    if (t188 == 1)
        goto LAB69;

LAB70:
LAB71:    t191 = ((char*)((ng0)));
    memset(t192, 0, 8);
    t193 = (t183 + 4);
    t194 = (t191 + 4);
    t195 = *((unsigned int *)t183);
    t196 = *((unsigned int *)t191);
    t197 = (t195 ^ t196);
    t198 = *((unsigned int *)t193);
    t199 = *((unsigned int *)t194);
    t200 = (t198 ^ t199);
    t201 = (t197 | t200);
    t202 = *((unsigned int *)t193);
    t203 = *((unsigned int *)t194);
    t204 = (t202 | t203);
    t205 = (~(t204));
    t206 = (t201 & t205);
    if (t206 != 0)
        goto LAB75;

LAB72:    if (t204 != 0)
        goto LAB74;

LAB73:    *((unsigned int *)t192) = 1;

LAB75:    memset(t208, 0, 8);
    t209 = (t192 + 4);
    t210 = *((unsigned int *)t209);
    t211 = (~(t210));
    t212 = *((unsigned int *)t192);
    t213 = (t212 & t211);
    t214 = (t213 & 1U);
    if (t214 != 0)
        goto LAB76;

LAB77:    if (*((unsigned int *)t209) != 0)
        goto LAB78;

LAB79:    t217 = *((unsigned int *)t163);
    t218 = *((unsigned int *)t208);
    t219 = (t217 & t218);
    *((unsigned int *)t216) = t219;
    t220 = (t163 + 4);
    t221 = (t208 + 4);
    t222 = (t216 + 4);
    t223 = *((unsigned int *)t220);
    t224 = *((unsigned int *)t221);
    t225 = (t223 | t224);
    *((unsigned int *)t222) = t225;
    t226 = *((unsigned int *)t222);
    t227 = (t226 != 0);
    if (t227 == 1)
        goto LAB80;

LAB81:
LAB82:    goto LAB68;

LAB69:    t189 = *((unsigned int *)t183);
    t190 = *((unsigned int *)t186);
    *((unsigned int *)t183) = (t189 | t190);
    goto LAB71;

LAB74:    t207 = (t192 + 4);
    *((unsigned int *)t192) = 1;
    *((unsigned int *)t207) = 1;
    goto LAB75;

LAB76:    *((unsigned int *)t208) = 1;
    goto LAB79;

LAB78:    t215 = (t208 + 4);
    *((unsigned int *)t208) = 1;
    *((unsigned int *)t215) = 1;
    goto LAB79;

LAB80:    t228 = *((unsigned int *)t216);
    t229 = *((unsigned int *)t222);
    *((unsigned int *)t216) = (t228 | t229);
    t230 = (t163 + 4);
    t231 = (t208 + 4);
    t232 = *((unsigned int *)t163);
    t233 = (~(t232));
    t234 = *((unsigned int *)t230);
    t235 = (~(t234));
    t236 = *((unsigned int *)t208);
    t237 = (~(t236));
    t238 = *((unsigned int *)t231);
    t239 = (~(t238));
    t240 = (t233 & t235);
    t241 = (t237 & t239);
    t242 = (~(t240));
    t243 = (~(t241));
    t244 = *((unsigned int *)t222);
    *((unsigned int *)t222) = (t244 & t242);
    t245 = *((unsigned int *)t222);
    *((unsigned int *)t222) = (t245 & t243);
    t246 = *((unsigned int *)t216);
    *((unsigned int *)t216) = (t246 & t242);
    t247 = *((unsigned int *)t216);
    *((unsigned int *)t216) = (t247 & t243);
    goto LAB82;

LAB83:    t254 = (t1 + 4072);
    t255 = (t254 + 56U);
    t256 = *((char **)t255);
    memset(t257, 0, 8);
    t258 = (t257 + 4);
    t259 = (t256 + 4);
    t260 = *((unsigned int *)t256);
    t261 = (t260 >> 0);
    t262 = (t261 & 1);
    *((unsigned int *)t257) = t262;
    t263 = *((unsigned int *)t259);
    t264 = (t263 >> 0);
    t265 = (t264 & 1);
    *((unsigned int *)t258) = t265;
    t266 = (t1 + 3912);
    xsi_vlogvar_assign_value(t266, t257, 0, 0, 1);
    goto LAB85;

LAB88:    t21 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB89;

LAB90:    *((unsigned int *)t24) = 1;
    goto LAB93;

LAB92:    t23 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB93;

LAB94:    t26 = (t1 + 4072);
    t39 = (t26 + 56U);
    t44 = *((char **)t39);
    memset(t40, 0, 8);
    t45 = (t40 + 4);
    t46 = (t44 + 4);
    t43 = *((unsigned int *)t44);
    t47 = (t43 >> 0);
    t48 = (t47 & 1);
    *((unsigned int *)t40) = t48;
    t49 = *((unsigned int *)t46);
    t50 = (t49 >> 0);
    t51 = (t50 & 1);
    *((unsigned int *)t45) = t51;
    t55 = (t1 + 4072);
    t61 = (t55 + 56U);
    t62 = *((char **)t61);
    memset(t54, 0, 8);
    t67 = (t54 + 4);
    t68 = (t62 + 4);
    t52 = *((unsigned int *)t62);
    t53 = (t52 >> 1);
    t56 = (t53 & 1);
    *((unsigned int *)t54) = t56;
    t57 = *((unsigned int *)t68);
    t58 = (t57 >> 1);
    t59 = (t58 & 1);
    *((unsigned int *)t67) = t59;
    memset(t70, 0, 8);
    t69 = (t40 + 4);
    t71 = (t54 + 4);
    t60 = *((unsigned int *)t40);
    t63 = *((unsigned int *)t54);
    t64 = (t60 ^ t63);
    t65 = *((unsigned int *)t69);
    t66 = *((unsigned int *)t71);
    t73 = (t65 ^ t66);
    t74 = (t64 | t73);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t71);
    t77 = (t75 | t76);
    t78 = (~(t77));
    t91 = (t74 & t78);
    if (t91 != 0)
        goto LAB100;

LAB97:    if (t77 != 0)
        goto LAB99;

LAB98:    *((unsigned int *)t70) = 1;

LAB100:    memset(t82, 0, 8);
    t79 = (t70 + 4);
    t92 = *((unsigned int *)t79);
    t93 = (~(t92));
    t94 = *((unsigned int *)t70);
    t95 = (t94 & t93);
    t96 = (t95 & 1U);
    if (t96 != 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t79) != 0)
        goto LAB103;

LAB104:    t97 = *((unsigned int *)t24);
    t98 = *((unsigned int *)t82);
    t99 = (t97 & t98);
    *((unsigned int *)t88) = t99;
    t81 = (t24 + 4);
    t83 = (t82 + 4);
    t84 = (t88 + 4);
    t100 = *((unsigned int *)t81);
    t101 = *((unsigned int *)t83);
    t102 = (t100 | t101);
    *((unsigned int *)t84) = t102;
    t105 = *((unsigned int *)t84);
    t106 = (t105 != 0);
    if (t106 == 1)
        goto LAB105;

LAB106:
LAB107:    goto LAB96;

LAB99:    t72 = (t70 + 4);
    *((unsigned int *)t70) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB100;

LAB101:    *((unsigned int *)t82) = 1;
    goto LAB104;

LAB103:    t80 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB104;

LAB105:    t107 = *((unsigned int *)t88);
    t111 = *((unsigned int *)t84);
    *((unsigned int *)t88) = (t107 | t111);
    t85 = (t24 + 4);
    t86 = (t82 + 4);
    t112 = *((unsigned int *)t24);
    t113 = (~(t112));
    t114 = *((unsigned int *)t85);
    t115 = (~(t114));
    t116 = *((unsigned int *)t82);
    t117 = (~(t116));
    t120 = *((unsigned int *)t86);
    t121 = (~(t120));
    t145 = (t113 & t115);
    t149 = (t117 & t121);
    t122 = (~(t145));
    t123 = (~(t149));
    t124 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t124 & t122);
    t127 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t127 & t123);
    t128 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t128 & t122);
    t129 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t129 & t123);
    goto LAB107;

LAB108:    t89 = (t1 + 4072);
    t90 = (t89 + 56U);
    t103 = *((char **)t90);
    memset(t104, 0, 8);
    t108 = (t104 + 4);
    t109 = (t103 + 4);
    t138 = *((unsigned int *)t103);
    t139 = (t138 >> 0);
    t142 = (t139 & 1);
    *((unsigned int *)t104) = t142;
    t143 = *((unsigned int *)t109);
    t144 = (t143 >> 0);
    t146 = (t144 & 1);
    *((unsigned int *)t108) = t146;
    t110 = (t1 + 3912);
    xsi_vlogvar_assign_value(t110, t104, 0, 0, 1);
    goto LAB110;

LAB113:    t21 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB114;

LAB115:    *((unsigned int *)t24) = 1;
    goto LAB118;

LAB117:    t23 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB118;

LAB119:    t26 = (t1 + 4072);
    t39 = (t26 + 56U);
    t44 = *((char **)t39);
    memset(t40, 0, 8);
    t45 = (t40 + 4);
    t46 = (t44 + 4);
    t43 = *((unsigned int *)t44);
    t47 = (t43 >> 2);
    t48 = (t47 & 1);
    *((unsigned int *)t40) = t48;
    t49 = *((unsigned int *)t46);
    t50 = (t49 >> 2);
    t51 = (t50 & 1);
    *((unsigned int *)t45) = t51;
    t55 = (t1 + 4072);
    t61 = (t55 + 56U);
    t62 = *((char **)t61);
    memset(t54, 0, 8);
    t67 = (t54 + 4);
    t68 = (t62 + 4);
    t52 = *((unsigned int *)t62);
    t53 = (t52 >> 3);
    t56 = (t53 & 1);
    *((unsigned int *)t54) = t56;
    t57 = *((unsigned int *)t68);
    t58 = (t57 >> 3);
    t59 = (t58 & 1);
    *((unsigned int *)t67) = t59;
    memset(t70, 0, 8);
    t69 = (t40 + 4);
    t71 = (t54 + 4);
    t60 = *((unsigned int *)t40);
    t63 = *((unsigned int *)t54);
    t64 = (t60 ^ t63);
    t65 = *((unsigned int *)t69);
    t66 = *((unsigned int *)t71);
    t73 = (t65 ^ t66);
    t74 = (t64 | t73);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t71);
    t77 = (t75 | t76);
    t78 = (~(t77));
    t91 = (t74 & t78);
    if (t91 != 0)
        goto LAB125;

LAB122:    if (t77 != 0)
        goto LAB124;

LAB123:    *((unsigned int *)t70) = 1;

LAB125:    memset(t82, 0, 8);
    t79 = (t70 + 4);
    t92 = *((unsigned int *)t79);
    t93 = (~(t92));
    t94 = *((unsigned int *)t70);
    t95 = (t94 & t93);
    t96 = (t95 & 1U);
    if (t96 != 0)
        goto LAB126;

LAB127:    if (*((unsigned int *)t79) != 0)
        goto LAB128;

LAB129:    t97 = *((unsigned int *)t24);
    t98 = *((unsigned int *)t82);
    t99 = (t97 & t98);
    *((unsigned int *)t88) = t99;
    t81 = (t24 + 4);
    t83 = (t82 + 4);
    t84 = (t88 + 4);
    t100 = *((unsigned int *)t81);
    t101 = *((unsigned int *)t83);
    t102 = (t100 | t101);
    *((unsigned int *)t84) = t102;
    t105 = *((unsigned int *)t84);
    t106 = (t105 != 0);
    if (t106 == 1)
        goto LAB130;

LAB131:
LAB132:    goto LAB121;

LAB124:    t72 = (t70 + 4);
    *((unsigned int *)t70) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB125;

LAB126:    *((unsigned int *)t82) = 1;
    goto LAB129;

LAB128:    t80 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB129;

LAB130:    t107 = *((unsigned int *)t88);
    t111 = *((unsigned int *)t84);
    *((unsigned int *)t88) = (t107 | t111);
    t85 = (t24 + 4);
    t86 = (t82 + 4);
    t112 = *((unsigned int *)t24);
    t113 = (~(t112));
    t114 = *((unsigned int *)t85);
    t115 = (~(t114));
    t116 = *((unsigned int *)t82);
    t117 = (~(t116));
    t120 = *((unsigned int *)t86);
    t121 = (~(t120));
    t145 = (t113 & t115);
    t149 = (t117 & t121);
    t122 = (~(t145));
    t123 = (~(t149));
    t124 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t124 & t122);
    t127 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t127 & t123);
    t128 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t128 & t122);
    t129 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t129 & t123);
    goto LAB132;

LAB133:    t89 = (t1 + 4072);
    t90 = (t89 + 56U);
    t103 = *((char **)t90);
    memset(t104, 0, 8);
    t108 = (t104 + 4);
    t109 = (t103 + 4);
    t138 = *((unsigned int *)t103);
    t139 = (t138 >> 2);
    t142 = (t139 & 1);
    *((unsigned int *)t104) = t142;
    t143 = *((unsigned int *)t109);
    t144 = (t143 >> 2);
    t146 = (t144 & 1);
    *((unsigned int *)t108) = t146;
    t110 = (t1 + 3912);
    xsi_vlogvar_assign_value(t110, t104, 0, 0, 1);
    goto LAB135;

LAB138:    t21 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB139;

LAB140:    *((unsigned int *)t24) = 1;
    goto LAB143;

LAB142:    t23 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB143;

LAB144:    t26 = (t1 + 4072);
    t39 = (t26 + 56U);
    t44 = *((char **)t39);
    memset(t40, 0, 8);
    t45 = (t40 + 4);
    t46 = (t44 + 4);
    t43 = *((unsigned int *)t44);
    t47 = (t43 >> 0);
    t48 = (t47 & 1);
    *((unsigned int *)t40) = t48;
    t49 = *((unsigned int *)t46);
    t50 = (t49 >> 0);
    t51 = (t50 & 1);
    *((unsigned int *)t45) = t51;
    t55 = (t1 + 4072);
    t61 = (t55 + 56U);
    t62 = *((char **)t61);
    memset(t54, 0, 8);
    t67 = (t54 + 4);
    t68 = (t62 + 4);
    t52 = *((unsigned int *)t62);
    t53 = (t52 >> 2);
    t56 = (t53 & 1);
    *((unsigned int *)t54) = t56;
    t57 = *((unsigned int *)t68);
    t58 = (t57 >> 2);
    t59 = (t58 & 1);
    *((unsigned int *)t67) = t59;
    memset(t70, 0, 8);
    t69 = (t40 + 4);
    t71 = (t54 + 4);
    t60 = *((unsigned int *)t40);
    t63 = *((unsigned int *)t54);
    t64 = (t60 ^ t63);
    t65 = *((unsigned int *)t69);
    t66 = *((unsigned int *)t71);
    t73 = (t65 ^ t66);
    t74 = (t64 | t73);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t71);
    t77 = (t75 | t76);
    t78 = (~(t77));
    t91 = (t74 & t78);
    if (t91 != 0)
        goto LAB150;

LAB147:    if (t77 != 0)
        goto LAB149;

LAB148:    *((unsigned int *)t70) = 1;

LAB150:    memset(t82, 0, 8);
    t79 = (t70 + 4);
    t92 = *((unsigned int *)t79);
    t93 = (~(t92));
    t94 = *((unsigned int *)t70);
    t95 = (t94 & t93);
    t96 = (t95 & 1U);
    if (t96 != 0)
        goto LAB151;

LAB152:    if (*((unsigned int *)t79) != 0)
        goto LAB153;

LAB154:    t97 = *((unsigned int *)t24);
    t98 = *((unsigned int *)t82);
    t99 = (t97 & t98);
    *((unsigned int *)t88) = t99;
    t81 = (t24 + 4);
    t83 = (t82 + 4);
    t84 = (t88 + 4);
    t100 = *((unsigned int *)t81);
    t101 = *((unsigned int *)t83);
    t102 = (t100 | t101);
    *((unsigned int *)t84) = t102;
    t105 = *((unsigned int *)t84);
    t106 = (t105 != 0);
    if (t106 == 1)
        goto LAB155;

LAB156:
LAB157:    goto LAB146;

LAB149:    t72 = (t70 + 4);
    *((unsigned int *)t70) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB150;

LAB151:    *((unsigned int *)t82) = 1;
    goto LAB154;

LAB153:    t80 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB154;

LAB155:    t107 = *((unsigned int *)t88);
    t111 = *((unsigned int *)t84);
    *((unsigned int *)t88) = (t107 | t111);
    t85 = (t24 + 4);
    t86 = (t82 + 4);
    t112 = *((unsigned int *)t24);
    t113 = (~(t112));
    t114 = *((unsigned int *)t85);
    t115 = (~(t114));
    t116 = *((unsigned int *)t82);
    t117 = (~(t116));
    t120 = *((unsigned int *)t86);
    t121 = (~(t120));
    t145 = (t113 & t115);
    t149 = (t117 & t121);
    t122 = (~(t145));
    t123 = (~(t149));
    t124 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t124 & t122);
    t127 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t127 & t123);
    t128 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t128 & t122);
    t129 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t129 & t123);
    goto LAB157;

LAB158:    t89 = (t1 + 4072);
    t90 = (t89 + 56U);
    t103 = *((char **)t90);
    memset(t104, 0, 8);
    t108 = (t104 + 4);
    t109 = (t103 + 4);
    t138 = *((unsigned int *)t103);
    t139 = (t138 >> 0);
    t142 = (t139 & 1);
    *((unsigned int *)t104) = t142;
    t143 = *((unsigned int *)t109);
    t144 = (t143 >> 0);
    t146 = (t144 & 1);
    *((unsigned int *)t108) = t146;
    t110 = (t1 + 3912);
    xsi_vlogvar_assign_value(t110, t104, 0, 0, 1);
    goto LAB160;

LAB163:    t21 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB164;

LAB165:    *((unsigned int *)t24) = 1;
    goto LAB168;

LAB167:    t23 = (t24 + 4);
    *((unsigned int *)t24) = 1;
    *((unsigned int *)t23) = 1;
    goto LAB168;

LAB169:    t26 = (t1 + 4072);
    t39 = (t26 + 56U);
    t44 = *((char **)t39);
    memset(t40, 0, 8);
    t45 = (t40 + 4);
    t46 = (t44 + 4);
    t43 = *((unsigned int *)t44);
    t47 = (t43 >> 1);
    t48 = (t47 & 1);
    *((unsigned int *)t40) = t48;
    t49 = *((unsigned int *)t46);
    t50 = (t49 >> 1);
    t51 = (t50 & 1);
    *((unsigned int *)t45) = t51;
    t55 = (t1 + 4072);
    t61 = (t55 + 56U);
    t62 = *((char **)t61);
    memset(t54, 0, 8);
    t67 = (t54 + 4);
    t68 = (t62 + 4);
    t52 = *((unsigned int *)t62);
    t53 = (t52 >> 3);
    t56 = (t53 & 1);
    *((unsigned int *)t54) = t56;
    t57 = *((unsigned int *)t68);
    t58 = (t57 >> 3);
    t59 = (t58 & 1);
    *((unsigned int *)t67) = t59;
    memset(t70, 0, 8);
    t69 = (t40 + 4);
    t71 = (t54 + 4);
    t60 = *((unsigned int *)t40);
    t63 = *((unsigned int *)t54);
    t64 = (t60 ^ t63);
    t65 = *((unsigned int *)t69);
    t66 = *((unsigned int *)t71);
    t73 = (t65 ^ t66);
    t74 = (t64 | t73);
    t75 = *((unsigned int *)t69);
    t76 = *((unsigned int *)t71);
    t77 = (t75 | t76);
    t78 = (~(t77));
    t91 = (t74 & t78);
    if (t91 != 0)
        goto LAB175;

LAB172:    if (t77 != 0)
        goto LAB174;

LAB173:    *((unsigned int *)t70) = 1;

LAB175:    memset(t82, 0, 8);
    t79 = (t70 + 4);
    t92 = *((unsigned int *)t79);
    t93 = (~(t92));
    t94 = *((unsigned int *)t70);
    t95 = (t94 & t93);
    t96 = (t95 & 1U);
    if (t96 != 0)
        goto LAB176;

LAB177:    if (*((unsigned int *)t79) != 0)
        goto LAB178;

LAB179:    t97 = *((unsigned int *)t24);
    t98 = *((unsigned int *)t82);
    t99 = (t97 & t98);
    *((unsigned int *)t88) = t99;
    t81 = (t24 + 4);
    t83 = (t82 + 4);
    t84 = (t88 + 4);
    t100 = *((unsigned int *)t81);
    t101 = *((unsigned int *)t83);
    t102 = (t100 | t101);
    *((unsigned int *)t84) = t102;
    t105 = *((unsigned int *)t84);
    t106 = (t105 != 0);
    if (t106 == 1)
        goto LAB180;

LAB181:
LAB182:    goto LAB171;

LAB174:    t72 = (t70 + 4);
    *((unsigned int *)t70) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB175;

LAB176:    *((unsigned int *)t82) = 1;
    goto LAB179;

LAB178:    t80 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB179;

LAB180:    t107 = *((unsigned int *)t88);
    t111 = *((unsigned int *)t84);
    *((unsigned int *)t88) = (t107 | t111);
    t85 = (t24 + 4);
    t86 = (t82 + 4);
    t112 = *((unsigned int *)t24);
    t113 = (~(t112));
    t114 = *((unsigned int *)t85);
    t115 = (~(t114));
    t116 = *((unsigned int *)t82);
    t117 = (~(t116));
    t120 = *((unsigned int *)t86);
    t121 = (~(t120));
    t145 = (t113 & t115);
    t149 = (t117 & t121);
    t122 = (~(t145));
    t123 = (~(t149));
    t124 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t124 & t122);
    t127 = *((unsigned int *)t84);
    *((unsigned int *)t84) = (t127 & t123);
    t128 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t128 & t122);
    t129 = *((unsigned int *)t88);
    *((unsigned int *)t88) = (t129 & t123);
    goto LAB182;

LAB183:    t89 = (t1 + 4072);
    t90 = (t89 + 56U);
    t103 = *((char **)t90);
    memset(t104, 0, 8);
    t108 = (t104 + 4);
    t109 = (t103 + 4);
    t138 = *((unsigned int *)t103);
    t139 = (t138 >> 1);
    t142 = (t139 & 1);
    *((unsigned int *)t104) = t142;
    t143 = *((unsigned int *)t109);
    t144 = (t143 >> 1);
    t146 = (t144 & 1);
    *((unsigned int *)t108) = t146;
    t110 = (t1 + 3912);
    xsi_vlogvar_assign_value(t110, t104, 0, 0, 1);
    goto LAB185;

}

static void Gate_38_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 5144U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1912U);
    t3 = *((char **)t2);
    t2 = (t0 + 7128);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 4);
    t9 = (t3 + 4);
    if (*((unsigned int *)t9) == 1)
        goto LAB4;

LAB5:    t10 = *((unsigned int *)t3);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t9);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;

LAB6:    t14 = (t0 + 7128);
    xsi_driver_vfirst_trans(t14, 0, 0);
    t15 = (t0 + 6952);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

}

static void Gate_39_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 5392U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2072U);
    t3 = *((char **)t2);
    t2 = (t0 + 7192);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 4);
    t9 = (t3 + 4);
    if (*((unsigned int *)t9) == 1)
        goto LAB4;

LAB5:    t10 = *((unsigned int *)t3);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t9);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;

LAB6:    t14 = (t0 + 7192);
    xsi_driver_vfirst_trans(t14, 0, 0);
    t15 = (t0 + 6968);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

}

static void Gate_40_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 5640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2232U);
    t3 = *((char **)t2);
    t2 = (t0 + 7256);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 4);
    t9 = (t3 + 4);
    if (*((unsigned int *)t9) == 1)
        goto LAB4;

LAB5:    t10 = *((unsigned int *)t3);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t9);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;

LAB6:    t14 = (t0 + 7256);
    xsi_driver_vfirst_trans(t14, 0, 0);
    t15 = (t0 + 6984);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

}

static void Gate_41_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 5888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2392U);
    t3 = *((char **)t2);
    t2 = (t0 + 7320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 4);
    t9 = (t3 + 4);
    if (*((unsigned int *)t9) == 1)
        goto LAB4;

LAB5:    t10 = *((unsigned int *)t3);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t9);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;

LAB6:    t14 = (t0 + 7320);
    xsi_driver_vfirst_trans(t14, 0, 0);
    t15 = (t0 + 7000);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

}

static void Gate_43_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;

LAB0:    t1 = (t0 + 6136U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3192U);
    t3 = *((char **)t2);
    t2 = (t0 + 7384);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 4);
    t9 = (t3 + 4);
    if (*((unsigned int *)t9) == 1)
        goto LAB4;

LAB5:    t10 = *((unsigned int *)t3);
    t11 = (t10 & 1);
    *((unsigned int *)t7) = t11;
    t12 = *((unsigned int *)t9);
    t13 = (t12 & 1);
    *((unsigned int *)t8) = t13;

LAB6:    t14 = (t0 + 7384);
    xsi_driver_vfirst_trans(t14, 0, 0);
    t15 = (t0 + 7016);
    *((int *)t15) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t7) = 1;
    *((unsigned int *)t8) = 1;
    goto LAB6;

}

static void Cont_45_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 6384U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3592);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 7448);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 7032);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_47_6(char *t0)
{
    char t7[8];
    char t22[8];
    char t37[8];
    char t55[8];
    char t63[8];
    char t99[8];
    char t102[8];
    char t122[8];
    char t126[8];
    char t146[8];
    char t150[8];
    char t154[8];
    char t174[8];
    char t178[8];
    char t198[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    char *t20;
    char *t21;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    char *t26;
    char *t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    char *t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    char *t54;
    char *t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    char *t62;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    char *t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    char *t77;
    char *t78;
    unsigned int t79;
    unsigned int t80;
    unsigned int t81;
    int t82;
    unsigned int t83;
    unsigned int t84;
    unsigned int t85;
    int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    char *t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t98;
    char *t100;
    char *t101;
    char *t103;
    char *t104;
    char *t105;
    char *t106;
    char *t107;
    char *t108;
    char *t109;
    char *t110;
    char *t111;
    char *t112;
    char *t113;
    char *t114;
    char *t115;
    char *t116;
    char *t117;
    char *t118;
    char *t119;
    char *t120;
    char *t121;
    char *t123;
    char *t124;
    char *t125;
    char *t127;
    char *t128;
    char *t129;
    char *t130;
    char *t131;
    char *t132;
    char *t133;
    char *t134;
    char *t135;
    char *t136;
    char *t137;
    char *t138;
    char *t139;
    char *t140;
    char *t141;
    int t142;
    char *t143;
    char *t144;
    char *t145;
    char *t147;
    char *t148;
    char *t149;
    char *t151;
    char *t152;
    char *t153;
    char *t155;
    char *t156;
    char *t157;
    char *t158;
    char *t159;
    char *t160;
    char *t161;
    char *t162;
    char *t163;
    char *t164;
    char *t165;
    char *t166;
    char *t167;
    char *t168;
    char *t169;
    int t170;
    char *t171;
    char *t172;
    char *t173;
    char *t175;
    char *t176;
    char *t177;
    char *t179;
    char *t180;
    char *t181;
    char *t182;
    char *t183;
    char *t184;
    char *t185;
    char *t186;
    char *t187;
    char *t188;
    char *t189;
    char *t190;
    char *t191;
    char *t192;
    char *t193;
    int t194;
    char *t195;
    char *t196;
    char *t197;
    char *t199;
    char *t200;
    char *t201;
    char *t202;

LAB0:    t1 = (t0 + 6632U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 7048);
    *((int *)t2) = 1;
    t3 = (t0 + 6664);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 2552U);
    t5 = *((char **)t4);
    t4 = (t0 + 2712U);
    t6 = *((char **)t4);
    t8 = *((unsigned int *)t5);
    t9 = *((unsigned int *)t6);
    t10 = (t8 ^ t9);
    *((unsigned int *)t7) = t10;
    t4 = (t5 + 4);
    t11 = (t6 + 4);
    t12 = (t7 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t11);
    t15 = (t13 | t14);
    *((unsigned int *)t12) = t15;
    t16 = *((unsigned int *)t12);
    t17 = (t16 != 0);
    if (t17 == 1)
        goto LAB6;

LAB7:
LAB8:    t20 = (t0 + 2872U);
    t21 = *((char **)t20);
    t23 = *((unsigned int *)t7);
    t24 = *((unsigned int *)t21);
    t25 = (t23 ^ t24);
    *((unsigned int *)t22) = t25;
    t20 = (t7 + 4);
    t26 = (t21 + 4);
    t27 = (t22 + 4);
    t28 = *((unsigned int *)t20);
    t29 = *((unsigned int *)t26);
    t30 = (t28 | t29);
    *((unsigned int *)t27) = t30;
    t31 = *((unsigned int *)t27);
    t32 = (t31 != 0);
    if (t32 == 1)
        goto LAB9;

LAB10:
LAB11:    t35 = (t0 + 3032U);
    t36 = *((char **)t35);
    t38 = *((unsigned int *)t22);
    t39 = *((unsigned int *)t36);
    t40 = (t38 ^ t39);
    *((unsigned int *)t37) = t40;
    t35 = (t22 + 4);
    t41 = (t36 + 4);
    t42 = (t37 + 4);
    t43 = *((unsigned int *)t35);
    t44 = *((unsigned int *)t41);
    t45 = (t43 | t44);
    *((unsigned int *)t42) = t45;
    t46 = *((unsigned int *)t42);
    t47 = (t46 != 0);
    if (t47 == 1)
        goto LAB12;

LAB13:
LAB14:    t50 = (t0 + 3752);
    xsi_vlogvar_assign_value(t50, t37, 0, 0, 1);
    t2 = (t0 + 3752);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng0)));
    memset(t7, 0, 8);
    t6 = (t4 + 4);
    t11 = (t5 + 4);
    t8 = *((unsigned int *)t4);
    t9 = *((unsigned int *)t5);
    t10 = (t8 ^ t9);
    t13 = *((unsigned int *)t6);
    t14 = *((unsigned int *)t11);
    t15 = (t13 ^ t14);
    t16 = (t10 | t15);
    t17 = *((unsigned int *)t6);
    t18 = *((unsigned int *)t11);
    t19 = (t17 | t18);
    t23 = (~(t19));
    t24 = (t16 & t23);
    if (t24 != 0)
        goto LAB18;

LAB15:    if (t19 != 0)
        goto LAB17;

LAB16:    *((unsigned int *)t7) = 1;

LAB18:    memset(t22, 0, 8);
    t20 = (t7 + 4);
    t25 = *((unsigned int *)t20);
    t28 = (~(t25));
    t29 = *((unsigned int *)t7);
    t30 = (t29 & t28);
    t31 = (t30 & 1U);
    if (t31 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t20) != 0)
        goto LAB21;

LAB22:    t26 = (t22 + 4);
    t32 = *((unsigned int *)t22);
    t33 = (!(t32));
    t34 = *((unsigned int *)t26);
    t38 = (t33 || t34);
    if (t38 > 0)
        goto LAB23;

LAB24:    memcpy(t63, t22, 8);

LAB25:    t91 = (t63 + 4);
    t92 = *((unsigned int *)t91);
    t93 = (~(t92));
    t94 = *((unsigned int *)t63);
    t95 = (t94 & t93);
    t96 = (t95 != 0);
    if (t96 > 0)
        goto LAB37;

LAB38:    t2 = (t0 + 472);
    t3 = *((char **)t2);
    memset(t22, 0, 8);
    t2 = (t22 + 4);
    t4 = (t3 + 4);
    t8 = *((unsigned int *)t3);
    t9 = (t8 >> 0);
    *((unsigned int *)t22) = t9;
    t10 = *((unsigned int *)t4);
    t13 = (t10 >> 0);
    *((unsigned int *)t2) = t13;
    t14 = *((unsigned int *)t22);
    *((unsigned int *)t22) = (t14 & 15U);
    t15 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t15 & 15U);
    t5 = (t0 + 2552U);
    t6 = *((char **)t5);
    t5 = (t0 + 2712U);
    t11 = *((char **)t5);
    xsi_vlogtype_concat(t37, 2, 2, 2U, t11, 1, t6, 1);
    t5 = (t0 + 6440);
    t12 = (t0 + 1120);
    t20 = xsi_create_subprogram_invocation(t5, 0, t0, t12, 0, 0);
    t21 = (t0 + 4072);
    xsi_vlogvar_assign_value(t21, t22, 0, 0, 4);
    t26 = (t0 + 4232);
    xsi_vlogvar_assign_value(t26, t37, 0, 0, 2);

LAB40:    t27 = (t0 + 6536);
    t35 = *((char **)t27);
    t36 = (t35 + 80U);
    t41 = *((char **)t36);
    t42 = (t41 + 272U);
    t50 = *((char **)t42);
    t54 = (t50 + 0U);
    t56 = *((char **)t54);
    t82 = ((int  (*)(char *, char *))t56)(t0, t35);
    if (t82 != 0)
        goto LAB42;

LAB41:    t35 = (t0 + 6536);
    t62 = *((char **)t35);
    t35 = (t0 + 3912);
    t67 = (t35 + 56U);
    t68 = *((char **)t67);
    memcpy(t55, t68, 8);
    t69 = (t0 + 1120);
    t77 = (t0 + 6440);
    t78 = 0;
    xsi_delete_subprogram_invocation(t69, t62, t0, t77, t78);
    t91 = (t0 + 472);
    t97 = *((char **)t91);
    memset(t63, 0, 8);
    t91 = (t63 + 4);
    t98 = (t97 + 4);
    t16 = *((unsigned int *)t97);
    t17 = (t16 >> 4);
    *((unsigned int *)t63) = t17;
    t18 = *((unsigned int *)t98);
    t19 = (t18 >> 4);
    *((unsigned int *)t91) = t19;
    t23 = *((unsigned int *)t63);
    *((unsigned int *)t63) = (t23 & 15U);
    t24 = *((unsigned int *)t91);
    *((unsigned int *)t91) = (t24 & 15U);
    t100 = (t0 + 2552U);
    t101 = *((char **)t100);
    t100 = (t0 + 2712U);
    t103 = *((char **)t100);
    xsi_vlogtype_concat(t99, 2, 2, 2U, t103, 1, t101, 1);
    t100 = (t0 + 6440);
    t104 = (t0 + 1120);
    t105 = xsi_create_subprogram_invocation(t100, 0, t0, t104, 0, 0);
    t106 = (t0 + 4072);
    xsi_vlogvar_assign_value(t106, t63, 0, 0, 4);
    t107 = (t0 + 4232);
    xsi_vlogvar_assign_value(t107, t99, 0, 0, 2);

LAB43:    t108 = (t0 + 6536);
    t109 = *((char **)t108);
    t110 = (t109 + 80U);
    t111 = *((char **)t110);
    t112 = (t111 + 272U);
    t113 = *((char **)t112);
    t114 = (t113 + 0U);
    t115 = *((char **)t114);
    t86 = ((int  (*)(char *, char *))t115)(t0, t109);
    if (t86 != 0)
        goto LAB45;

LAB44:    t109 = (t0 + 6536);
    t116 = *((char **)t109);
    t109 = (t0 + 3912);
    t117 = (t109 + 56U);
    t118 = *((char **)t117);
    memcpy(t102, t118, 8);
    t119 = (t0 + 1120);
    t120 = (t0 + 6440);
    t121 = 0;
    xsi_delete_subprogram_invocation(t119, t116, t0, t120, t121);
    t123 = (t0 + 472);
    t124 = *((char **)t123);
    memset(t122, 0, 8);
    t123 = (t122 + 4);
    t125 = (t124 + 4);
    t25 = *((unsigned int *)t124);
    t28 = (t25 >> 8);
    *((unsigned int *)t122) = t28;
    t29 = *((unsigned int *)t125);
    t30 = (t29 >> 8);
    *((unsigned int *)t123) = t30;
    t31 = *((unsigned int *)t122);
    *((unsigned int *)t122) = (t31 & 15U);
    t32 = *((unsigned int *)t123);
    *((unsigned int *)t123) = (t32 & 15U);
    t127 = (t0 + 2552U);
    t128 = *((char **)t127);
    t127 = (t0 + 2712U);
    t129 = *((char **)t127);
    xsi_vlogtype_concat(t126, 2, 2, 2U, t129, 1, t128, 1);
    t127 = (t0 + 6440);
    t130 = (t0 + 1120);
    t131 = xsi_create_subprogram_invocation(t127, 0, t0, t130, 0, 0);
    t132 = (t0 + 4072);
    xsi_vlogvar_assign_value(t132, t122, 0, 0, 4);
    t133 = (t0 + 4232);
    xsi_vlogvar_assign_value(t133, t126, 0, 0, 2);

LAB46:    t134 = (t0 + 6536);
    t135 = *((char **)t134);
    t136 = (t135 + 80U);
    t137 = *((char **)t136);
    t138 = (t137 + 272U);
    t139 = *((char **)t138);
    t140 = (t139 + 0U);
    t141 = *((char **)t140);
    t142 = ((int  (*)(char *, char *))t141)(t0, t135);
    if (t142 != 0)
        goto LAB48;

LAB47:    t135 = (t0 + 6536);
    t143 = *((char **)t135);
    t135 = (t0 + 3912);
    t144 = (t135 + 56U);
    t145 = *((char **)t144);
    memcpy(t146, t145, 8);
    t147 = (t0 + 1120);
    t148 = (t0 + 6440);
    t149 = 0;
    xsi_delete_subprogram_invocation(t147, t143, t0, t148, t149);
    t151 = (t0 + 472);
    t152 = *((char **)t151);
    memset(t150, 0, 8);
    t151 = (t150 + 4);
    t153 = (t152 + 4);
    t33 = *((unsigned int *)t152);
    t34 = (t33 >> 12);
    *((unsigned int *)t150) = t34;
    t38 = *((unsigned int *)t153);
    t39 = (t38 >> 12);
    *((unsigned int *)t151) = t39;
    t40 = *((unsigned int *)t150);
    *((unsigned int *)t150) = (t40 & 15U);
    t43 = *((unsigned int *)t151);
    *((unsigned int *)t151) = (t43 & 15U);
    t155 = (t0 + 2552U);
    t156 = *((char **)t155);
    t155 = (t0 + 2712U);
    t157 = *((char **)t155);
    xsi_vlogtype_concat(t154, 2, 2, 2U, t157, 1, t156, 1);
    t155 = (t0 + 6440);
    t158 = (t0 + 1120);
    t159 = xsi_create_subprogram_invocation(t155, 0, t0, t158, 0, 0);
    t160 = (t0 + 4072);
    xsi_vlogvar_assign_value(t160, t150, 0, 0, 4);
    t161 = (t0 + 4232);
    xsi_vlogvar_assign_value(t161, t154, 0, 0, 2);

LAB49:    t162 = (t0 + 6536);
    t163 = *((char **)t162);
    t164 = (t163 + 80U);
    t165 = *((char **)t164);
    t166 = (t165 + 272U);
    t167 = *((char **)t166);
    t168 = (t167 + 0U);
    t169 = *((char **)t168);
    t170 = ((int  (*)(char *, char *))t169)(t0, t163);
    if (t170 != 0)
        goto LAB51;

LAB50:    t163 = (t0 + 6536);
    t171 = *((char **)t163);
    t163 = (t0 + 3912);
    t172 = (t163 + 56U);
    t173 = *((char **)t172);
    memcpy(t174, t173, 8);
    t175 = (t0 + 1120);
    t176 = (t0 + 6440);
    t177 = 0;
    xsi_delete_subprogram_invocation(t175, t171, t0, t176, t177);
    xsi_vlogtype_concat(t7, 4, 4, 4U, t174, 1, t146, 1, t102, 1, t55, 1);
    t179 = (t0 + 2872U);
    t180 = *((char **)t179);
    t179 = (t0 + 3032U);
    t181 = *((char **)t179);
    xsi_vlogtype_concat(t178, 2, 2, 2U, t181, 1, t180, 1);
    t179 = (t0 + 6440);
    t182 = (t0 + 1120);
    t183 = xsi_create_subprogram_invocation(t179, 0, t0, t182, 0, 0);
    t184 = (t0 + 4072);
    xsi_vlogvar_assign_value(t184, t7, 0, 0, 4);
    t185 = (t0 + 4232);
    xsi_vlogvar_assign_value(t185, t178, 0, 0, 2);

LAB52:    t186 = (t0 + 6536);
    t187 = *((char **)t186);
    t188 = (t187 + 80U);
    t189 = *((char **)t188);
    t190 = (t189 + 272U);
    t191 = *((char **)t190);
    t192 = (t191 + 0U);
    t193 = *((char **)t192);
    t194 = ((int  (*)(char *, char *))t193)(t0, t187);
    if (t194 != 0)
        goto LAB54;

LAB53:    t187 = (t0 + 6536);
    t195 = *((char **)t187);
    t187 = (t0 + 3912);
    t196 = (t187 + 56U);
    t197 = *((char **)t196);
    memcpy(t198, t197, 8);
    t199 = (t0 + 1120);
    t200 = (t0 + 6440);
    t201 = 0;
    xsi_delete_subprogram_invocation(t199, t195, t0, t200, t201);
    t202 = (t0 + 3592);
    xsi_vlogvar_assign_value(t202, t198, 0, 0, 1);

LAB39:    goto LAB2;

LAB6:    t18 = *((unsigned int *)t7);
    t19 = *((unsigned int *)t12);
    *((unsigned int *)t7) = (t18 | t19);
    goto LAB8;

LAB9:    t33 = *((unsigned int *)t22);
    t34 = *((unsigned int *)t27);
    *((unsigned int *)t22) = (t33 | t34);
    goto LAB11;

LAB12:    t48 = *((unsigned int *)t37);
    t49 = *((unsigned int *)t42);
    *((unsigned int *)t37) = (t48 | t49);
    goto LAB14;

LAB17:    t12 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t12) = 1;
    goto LAB18;

LAB19:    *((unsigned int *)t22) = 1;
    goto LAB22;

LAB21:    t21 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB22;

LAB23:    t27 = (t0 + 3752);
    t35 = (t27 + 56U);
    t36 = *((char **)t35);
    t41 = ((char*)((ng1)));
    memset(t37, 0, 8);
    t42 = (t36 + 4);
    t50 = (t41 + 4);
    t39 = *((unsigned int *)t36);
    t40 = *((unsigned int *)t41);
    t43 = (t39 ^ t40);
    t44 = *((unsigned int *)t42);
    t45 = *((unsigned int *)t50);
    t46 = (t44 ^ t45);
    t47 = (t43 | t46);
    t48 = *((unsigned int *)t42);
    t49 = *((unsigned int *)t50);
    t51 = (t48 | t49);
    t52 = (~(t51));
    t53 = (t47 & t52);
    if (t53 != 0)
        goto LAB29;

LAB26:    if (t51 != 0)
        goto LAB28;

LAB27:    *((unsigned int *)t37) = 1;

LAB29:    memset(t55, 0, 8);
    t56 = (t37 + 4);
    t57 = *((unsigned int *)t56);
    t58 = (~(t57));
    t59 = *((unsigned int *)t37);
    t60 = (t59 & t58);
    t61 = (t60 & 1U);
    if (t61 != 0)
        goto LAB30;

LAB31:    if (*((unsigned int *)t56) != 0)
        goto LAB32;

LAB33:    t64 = *((unsigned int *)t22);
    t65 = *((unsigned int *)t55);
    t66 = (t64 | t65);
    *((unsigned int *)t63) = t66;
    t67 = (t22 + 4);
    t68 = (t55 + 4);
    t69 = (t63 + 4);
    t70 = *((unsigned int *)t67);
    t71 = *((unsigned int *)t68);
    t72 = (t70 | t71);
    *((unsigned int *)t69) = t72;
    t73 = *((unsigned int *)t69);
    t74 = (t73 != 0);
    if (t74 == 1)
        goto LAB34;

LAB35:
LAB36:    goto LAB25;

LAB28:    t54 = (t37 + 4);
    *((unsigned int *)t37) = 1;
    *((unsigned int *)t54) = 1;
    goto LAB29;

LAB30:    *((unsigned int *)t55) = 1;
    goto LAB33;

LAB32:    t62 = (t55 + 4);
    *((unsigned int *)t55) = 1;
    *((unsigned int *)t62) = 1;
    goto LAB33;

LAB34:    t75 = *((unsigned int *)t63);
    t76 = *((unsigned int *)t69);
    *((unsigned int *)t63) = (t75 | t76);
    t77 = (t22 + 4);
    t78 = (t55 + 4);
    t79 = *((unsigned int *)t77);
    t80 = (~(t79));
    t81 = *((unsigned int *)t22);
    t82 = (t81 & t80);
    t83 = *((unsigned int *)t78);
    t84 = (~(t83));
    t85 = *((unsigned int *)t55);
    t86 = (t85 & t84);
    t87 = (~(t82));
    t88 = (~(t86));
    t89 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t89 & t87);
    t90 = *((unsigned int *)t69);
    *((unsigned int *)t69) = (t90 & t88);
    goto LAB36;

LAB37:    t97 = (t0 + 472);
    t98 = *((char **)t97);
    t97 = (t0 + 416);
    t100 = (t97 + 72U);
    t101 = *((char **)t100);
    t103 = (t0 + 2552U);
    t104 = *((char **)t103);
    t103 = (t0 + 2712U);
    t105 = *((char **)t103);
    t103 = (t0 + 2872U);
    t106 = *((char **)t103);
    t103 = (t0 + 3032U);
    t107 = *((char **)t103);
    xsi_vlogtype_concat(t102, 4, 4, 4U, t107, 1, t106, 1, t105, 1, t104, 1);
    xsi_vlog_generic_get_index_select_value(t99, 1, t98, t101, 2, t102, 4, 2);
    t103 = (t0 + 3592);
    xsi_vlogvar_assign_value(t103, t99, 0, 0, 1);
    goto LAB39;

LAB42:    t27 = (t0 + 6632U);
    *((char **)t27) = &&LAB40;
    goto LAB1;

LAB45:    t108 = (t0 + 6632U);
    *((char **)t108) = &&LAB43;
    goto LAB1;

LAB48:    t134 = (t0 + 6632U);
    *((char **)t134) = &&LAB46;
    goto LAB1;

LAB51:    t162 = (t0 + 6632U);
    *((char **)t162) = &&LAB49;
    goto LAB1;

LAB54:    t186 = (t0 + 6632U);
    *((char **)t186) = &&LAB52;
    goto LAB1;

}


extern void simprims_ver_m_05548409876658398341_2516406211_2827745283_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_2827745283", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_2827745283.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0599726513_3382816651_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0599726513_3382816651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0599726513_3382816651.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0250244551_2112952440_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0250244551_2112952440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0250244551_2112952440.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2686165248_2112952440_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2686165248_2112952440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2686165248_2112952440.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2472010458_2529600379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2472010458_2529600379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2472010458_2529600379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4003543351_2529600379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4003543351_2529600379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4003543351_2529600379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_0150795661_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_0150795661", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_0150795661.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_0150795661_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_0150795661", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_0150795661.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0203804537_2691154429_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0203804537_2691154429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0203804537_2691154429.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1382765425_1765083921_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1382765425_1765083921", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1382765425_1765083921.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762427062_1765083921_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762427062_1765083921", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762427062_1765083921.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2472010458_1899742619_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2472010458_1899742619", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2472010458_1899742619.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0604975857_1899742619_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0604975857_1899742619", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0604975857_1899742619.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1769993442_0849860572_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1769993442_0849860572", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1769993442_0849860572.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2632078529_4012969561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2632078529_4012969561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2632078529_4012969561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2672376343_2500386582_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2672376343_2500386582", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2672376343_2500386582.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3627133698_2500386582_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3627133698_2500386582", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3627133698_2500386582.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0269632109_2449280811_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0269632109_2449280811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0269632109_2449280811.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_2449280811_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_2449280811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_2449280811.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090574438_3798436231_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090574438_3798436231", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090574438_3798436231.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1435829159_3798436231_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1435829159_3798436231", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1435829159_3798436231.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3334539077_1360078270_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3334539077_1360078270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3334539077_1360078270.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2451334614_1360078270_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2451334614_1360078270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2451334614_1360078270.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1107252353_2137549041_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1107252353_2137549041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1107252353_2137549041.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2666664084_2137549041_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2666664084_2137549041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2666664084_2137549041.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3313460342_1181364733_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3313460342_1181364733", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3313460342_1181364733.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3758455735_1181364733_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3758455735_1181364733", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3758455735_1181364733.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2867798990_1703853813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2867798990_1703853813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2867798990_1703853813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3447485887_1703853813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3447485887_1703853813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3447485887_1703853813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3308098572_2730799931_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3308098572_2730799931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3308098572_2730799931.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2537795031_1096735068_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2537795031_1096735068", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2537795031_1096735068.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3750152449_0370636159_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3750152449_0370636159", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3750152449_0370636159.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1748602302_2440949773_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1748602302_2440949773", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1748602302_2440949773.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2887204203_0426518830_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2887204203_0426518830", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2887204203_0426518830.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3175179893_2073934028_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3175179893_2073934028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3175179893_2073934028.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3353346636_0837243269_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3353346636_0837243269", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3353346636_0837243269.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3040116309_0837243269_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3040116309_0837243269", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3040116309_0837243269.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3512302648_1775690561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3512302648_1775690561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3512302648_1775690561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2453541079_0767165798_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2453541079_0767165798", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2453541079_0767165798.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0967764732_0947784384_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0967764732_0947784384", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0967764732_0947784384.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3353346636_1273563398_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3353346636_1273563398", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3353346636_1273563398.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3040116309_1273563398_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3040116309_1273563398", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3040116309_1273563398.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3589448462_2425356672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3589448462_2425356672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3589448462_2425356672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2336711608_2425356672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2336711608_2425356672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2336711608_2425356672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1605496554_2929504866_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1605496554_2929504866", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1605496554_2929504866.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0464483153_2929504866_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0464483153_2929504866", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0464483153_2929504866.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2529870283_4191493697_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2529870283_4191493697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2529870283_4191493697.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1701517519_4191493697_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1701517519_4191493697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1701517519_4191493697.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2530491679_1880306848_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2530491679_1880306848", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2530491679_1880306848.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0887259993_1880306848_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0887259993_1880306848", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0887259993_1880306848.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1605496554_2306717727_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1605496554_2306717727", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1605496554_2306717727.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0464483153_2306717727_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0464483153_2306717727", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0464483153_2306717727.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3849801695_2048727649_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3849801695_2048727649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3849801695_2048727649.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3282992400_2048727649_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3282992400_2048727649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3282992400_2048727649.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4095126544_4183158670_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4095126544_4183158670", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4095126544_4183158670.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0402368595_4183158670_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0402368595_4183158670", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0402368595_4183158670.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1216323143_2096268495_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1216323143_2096268495", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1216323143_2096268495.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3357544279_2096268495_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3357544279_2096268495", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3357544279_2096268495.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1826694876_2142372502_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1826694876_2142372502", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1826694876_2142372502.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0046053061_2142372502_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0046053061_2142372502", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0046053061_2142372502.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2787288474_1158483096_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2787288474_1158483096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2787288474_1158483096.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0068426716_1158483096_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0068426716_1158483096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0068426716_1158483096.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2258165848_2310431653_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2258165848_2310431653", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2258165848_2310431653.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_2310431653_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_2310431653", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_2310431653.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_0143114566_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_0143114566", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_0143114566.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2666846366_0221899750_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2666846366_0221899750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2666846366_0221899750.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2747895650_0221899750_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2747895650_0221899750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2747895650_0221899750.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4106386431_0130763087_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4106386431_0130763087", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4106386431_0130763087.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2428712131_0553806871_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2428712131_0553806871", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2428712131_0553806871.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4017722443_0553806871_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4017722443_0553806871", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4017722443_0553806871.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1410930008_1332925565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1410930008_1332925565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1410930008_1332925565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709045835_1332925565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709045835_1332925565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709045835_1332925565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2666846366_3215814137_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2666846366_3215814137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2666846366_3215814137.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1886030106_3215814137_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1886030106_3215814137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1886030106_3215814137.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_3413326160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_3413326160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_3413326160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1262360998_3413326160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1262360998_3413326160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1262360998_3413326160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_0832676622_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_0832676622", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_0832676622.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2747895650_0832676622_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2747895650_0832676622", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2747895650_0832676622.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0269632109_3462791888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0269632109_3462791888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0269632109_3462791888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_3462791888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_3462791888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_3462791888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2632078529_3841402577_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2632078529_3841402577", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2632078529_3841402577.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3145906246_0900114740_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3145906246_0900114740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3145906246_0900114740.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_0900114740_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_0900114740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_0900114740.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3286204028_3318577041_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3286204028_3318577041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3286204028_3318577041.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_3318577041_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_3318577041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_3318577041.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922406896_1641887708_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922406896_1641887708", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922406896_1641887708.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_1641887708_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_1641887708", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_1641887708.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0965110568_0615600750_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0965110568_0615600750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0965110568_0615600750.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_0615600750_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_0615600750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_0615600750.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2007753456_2437184723_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2007753456_2437184723", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2007753456_2437184723.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3580249038_2437184723_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3580249038_2437184723", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3580249038_2437184723.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2863026909_0635224991_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2863026909_0635224991", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2863026909_0635224991.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2641769766_0635224991_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2641769766_0635224991", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2641769766_0635224991.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0366253308_1572495645_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0366253308_1572495645", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0366253308_1572495645.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2721373801_1572495645_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2721373801_1572495645", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2721373801_1572495645.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1629967213_2509917185_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1629967213_2509917185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1629967213_2509917185.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1383570267_1053495238_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1383570267_1053495238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1383570267_1053495238.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0829907043_0729658610_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0829907043_0729658610", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0829907043_0729658610.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1012121405_0729658610_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1012121405_0729658610", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1012121405_0729658610.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2125608614_3951831549_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2125608614_3951831549", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2125608614_3951831549.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2125608614_2476327169_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2125608614_2476327169", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2125608614_2476327169.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0297360240_2904569136_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0297360240_2904569136", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0297360240_2904569136.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4247503379_2904569136_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4247503379_2904569136", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4247503379_2904569136.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4145343985_1119607428_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4145343985_1119607428", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4145343985_1119607428.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762900403_1119607428_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762900403_1119607428", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762900403_1119607428.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4186630640_1894737983_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4186630640_1894737983", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4186630640_1894737983.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3028986520_1894737983_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3028986520_1894737983", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3028986520_1894737983.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_2749056687_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_2749056687", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_2749056687.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_2749056687_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_2749056687", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_2749056687.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0108713357_0629787697_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0108713357_0629787697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0108713357_0629787697.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2686165248_0804855688_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2686165248_0804855688", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2686165248_0804855688.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0250244551_0804855688_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0250244551_0804855688", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0250244551_0804855688.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4003543351_3301876875_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4003543351_3301876875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4003543351_3301876875.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2472010458_3301876875_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2472010458_3301876875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2472010458_3301876875.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4060388279_0702420675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4060388279_0702420675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4060388279_0702420675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2514646726_0702420675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2514646726_0702420675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2514646726_0702420675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1654508532_3323756029_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1654508532_3323756029", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1654508532_3323756029.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3586464735_3323756029_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3586464735_3323756029", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3586464735_3323756029.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_1408986209_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_1408986209", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_1408986209.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4231770271_3400821201_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4231770271_3400821201", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4231770271_3400821201.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1507483282_3400821201_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1507483282_3400821201", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1507483282_3400821201.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0099302895_0508563980_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0099302895_0508563980", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0099302895_0508563980.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4005104311_0508563980_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4005104311_0508563980", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4005104311_0508563980.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0099302895_1158866371_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0099302895_1158866371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0099302895_1158866371.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2636709597_1158866371_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2636709597_1158866371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2636709597_1158866371.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0579792659_0737110088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0579792659_0737110088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0579792659_0737110088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0432469059_0737110088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0432469059_0737110088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0432469059_0737110088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951154365_1105671678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951154365_1105671678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951154365_1105671678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1360325192_1105671678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1360325192_1105671678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1360325192_1105671678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2584836960_1824720950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2584836960_1824720950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2584836960_1824720950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3650192155_1824720950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3650192155_1824720950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3650192155_1824720950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1612996771_4070854346_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1612996771_4070854346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1612996771_4070854346.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3699488411_4070854346_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3699488411_4070854346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3699488411_4070854346.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2584836960_2204103546_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2584836960_2204103546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2584836960_2204103546.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4116176841_2204103546_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4116176841_2204103546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4116176841_2204103546.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1454477099_2820501031_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1454477099_2820501031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1454477099_2820501031.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1767935521_0497921331_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1767935521_0497921331", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1767935521_0497921331.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_2558803014_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_2558803014", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_2558803014.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_0431741683_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_0431741683", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_0431741683.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_1532342302_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_1532342302", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_1532342302.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2863026909_2120671391_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2863026909_2120671391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2863026909_2120671391.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0348082703_2120671391_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0348082703_2120671391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0348082703_2120671391.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2545941484_3338721510_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2545941484_3338721510", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2545941484_3338721510.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2721373801_3338721510_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2721373801_3338721510", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2721373801_3338721510.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1239469732_0765911334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1239469732_0765911334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1239469732_0765911334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3731696986_0765911334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3731696986_0765911334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3731696986_0765911334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4042476406_0838132493_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4042476406_0838132493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4042476406_0838132493.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2193476988_0838132493_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2193476988_0838132493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2193476988_0838132493.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2456823943_3261368856_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2456823943_3261368856", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2456823943_3261368856.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3789703807_3261368856_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3789703807_3261368856", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3789703807_3261368856.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2055716419_2857480034_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2055716419_2857480034", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2055716419_2857480034.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1592034989_2857480034_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1592034989_2857480034", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1592034989_2857480034.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0967191255_1842546268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0967191255_1842546268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0967191255_1842546268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3327913892_1842546268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3327913892_1842546268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3327913892_1842546268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3480110802_2141347742_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3480110802_2141347742", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3480110802_2141347742.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1316383567_0996644681_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1316383567_0996644681", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1316383567_0996644681.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2290106431_0996644681_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2290106431_0996644681", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2290106431_0996644681.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3998749361_3892912753_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3998749361_3892912753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3998749361_3892912753.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0615211109_3892912753_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0615211109_3892912753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0615211109_3892912753.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2428712131_2829666370_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2428712131_2829666370", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2428712131_2829666370.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3770095068_2829666370_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3770095068_2829666370", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3770095068_2829666370.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3715886357_2248598606_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3715886357_2248598606", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3715886357_2248598606.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2931222138_2248598606_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2931222138_2248598606", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2931222138_2248598606.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0220313076_4188940938_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0220313076_4188940938", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0220313076_4188940938.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1302531182_4188940938_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1302531182_4188940938", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1302531182_4188940938.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4120129853_3181317200_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4120129853_3181317200", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4120129853_3181317200.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3401590456_3181317200_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3401590456_3181317200", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3401590456_3181317200.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1410930008_1697179617_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1410930008_1697179617", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1410930008_1697179617.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3373707446_1697179617_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3373707446_1697179617", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3373707446_1697179617.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0394829761_1969215038_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0394829761_1969215038", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0394829761_1969215038.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1410930008_0517644966_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1410930008_0517644966", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1410930008_0517644966.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709045835_0517644966_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709045835_0517644966", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709045835_0517644966.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_3246496761_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_3246496761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_3246496761.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2336560256_3246496761_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2336560256_3246496761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2336560256_3246496761.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2336560256_1276718481_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2336560256_1276718481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2336560256_1276718481.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_1276718481_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_1276718481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_1276718481.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0492475300_3664036362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0492475300_3664036362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0492475300_3664036362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_3664036362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_3664036362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_3664036362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0423980638_0018306551_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0423980638_0018306551", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0423980638_0018306551.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_0018306551_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_0018306551", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_0018306551.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1288467185_2338562242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1288467185_2338562242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1288467185_2338562242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_2338562242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_2338562242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_2338562242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3926464302_2412494571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3926464302_2412494571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3926464302_2412494571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3580249038_2412494571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3580249038_2412494571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3580249038_2412494571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0965110568_3318560828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0965110568_3318560828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0965110568_3318560828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_3318560828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_3318560828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_3318560828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2955151379_1191928965_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2955151379_1191928965", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2955151379_1191928965.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2336560256_1122131470_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2336560256_1122131470", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2336560256_1122131470.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_1122131470_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_1122131470", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_1122131470.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3766886815_0157924954_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3766886815_0157924954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3766886815_0157924954.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762900403_0157924954_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762900403_0157924954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762900403_0157924954.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0233462558_2670527233_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0233462558_2670527233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0233462558_2670527233.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4186630640_2670527233_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4186630640_2670527233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4186630640_2670527233.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0915164424_2300853397_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0915164424_2300853397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0915164424_2300853397.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0435370922_2194225365_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0435370922_2194225365", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0435370922_2194225365.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_0507139540_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_0507139540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_0507139540.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3584929060_0507139540_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3584929060_0507139540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3584929060_0507139540.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3746180462_1494627754_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3746180462_1494627754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3746180462_1494627754.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0376310885_1494627754_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0376310885_1494627754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0376310885_1494627754.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1594082119_1622134828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1594082119_1622134828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1594082119_1622134828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2747895650_3471538332_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2747895650_3471538332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2747895650_3471538332.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_3471538332_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_3471538332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_3471538332.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0000626974_2060104744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0000626974_2060104744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0000626974_2060104744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_2060104744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_2060104744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_2060104744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0682082248_1320849312_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0682082248_1320849312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0682082248_1320849312.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2669214583_1317951203_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2669214583_1317951203", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2669214583_1317951203.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1727070620_1070128348_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1727070620_1070128348", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1727070620_1070128348.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0250244551_1070128348_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0250244551_1070128348", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0250244551_1070128348.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2827578994_4013978910_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2827578994_4013978910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2827578994_4013978910.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3270640434_4013978910_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3270640434_4013978910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3270640434_4013978910.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0749847611_0776204487_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0749847611_0776204487", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0749847611_0776204487.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4063746252_0776204487_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4063746252_0776204487", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4063746252_0776204487.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2881216001_2343769242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2881216001_2343769242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2881216001_2343769242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3687841566_2343769242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3687841566_2343769242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3687841566_2343769242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0749847611_1237814511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0749847611_1237814511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0749847611_1237814511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4063746252_1237814511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4063746252_1237814511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4063746252_1237814511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0615211109_1671295198_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0615211109_1671295198", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0615211109_1671295198.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3534476176_1671295198_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3534476176_1671295198", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3534476176_1671295198.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0749847611_2623766602_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0749847611_2623766602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0749847611_2623766602.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3998749361_2623766602_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3998749361_2623766602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3998749361_2623766602.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1304277884_2253501729_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1304277884_2253501729", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1304277884_2253501729.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2470162315_2253501729_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2470162315_2253501729", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2470162315_2253501729.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1316383567_3059381335_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1316383567_3059381335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1316383567_3059381335.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2290106431_3059381335_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2290106431_3059381335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2290106431_3059381335.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3133376601_1611257301_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3133376601_1611257301", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3133376601_1611257301.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1992645054_0705647362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1992645054_0705647362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1992645054_0705647362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0905890388_0705647362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0905890388_0705647362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0905890388_0705647362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4056892292_2831749051_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4056892292_2831749051", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4056892292_2831749051.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0470216070_2831749051_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0470216070_2831749051", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0470216070_2831749051.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3702759929_3276569379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3702759929_3276569379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3702759929_3276569379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3424373515_3276569379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3424373515_3276569379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3424373515_3276569379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1512178353_3874574028_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1512178353_3874574028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1512178353_3874574028.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_3874574028_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_3874574028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_3874574028.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3286204028_3118966305_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3286204028_3118966305", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3286204028_3118966305.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_3118966305_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_3118966305", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_3118966305.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0050233834_3978069675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0050233834_3978069675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0050233834_3978069675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3580249038_3978069675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3580249038_3978069675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3580249038_3978069675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3312833381_1943723967_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3312833381_1943723967", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3312833381_1943723967.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_1943723967_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_1943723967", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_1943723967.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3312833381_0376193460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3312833381_0376193460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3312833381_0376193460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_0376193460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_0376193460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_0376193460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0359419268_1771298335_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0359419268_1771298335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0359419268_1771298335.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3580249038_1771298335_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3580249038_1771298335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3580249038_1771298335.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1939367284_2129185372_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1939367284_2129185372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1939367284_2129185372.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_2129185372_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_2129185372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_2129185372.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1856103883_0838980133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1856103883_0838980133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1856103883_0838980133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0380081591_4154034823_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0380081591_4154034823", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0380081591_4154034823.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_4154034823_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_4154034823", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_4154034823.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3789056835_1805051533_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3789056835_1805051533", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3789056835_1805051533.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_1805051533_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_1805051533", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_1805051533.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2445281037_3495113576_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2445281037_3495113576", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2445281037_3495113576.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_3495113576_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_3495113576", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_3495113576.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_0962723668_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_0962723668", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_0962723668.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_0962723668_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_0962723668", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_0962723668.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2259775028_2054408144_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2259775028_2054408144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2259775028_2054408144.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1311648806_2054408144_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1311648806_2054408144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1311648806_2054408144.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0269632109_1934651157_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0269632109_1934651157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0269632109_1934651157.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_1934651157_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_1934651157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_1934651157.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3862165061_3144645541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3862165061_3144645541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3862165061_3144645541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4060388279_3144645541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4060388279_3144645541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4060388279_3144645541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1654508532_1131378464_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1654508532_1131378464", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1654508532_1131378464.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2779623724_1131378464_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2779623724_1131378464", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2779623724_1131378464.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0118779587_3236694536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0118779587_3236694536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0118779587_3236694536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2863026909_2453800961_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2863026909_2453800961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2863026909_2453800961.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2304627512_2453800961_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2304627512_2453800961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2304627512_2453800961.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2572025941_1339347332_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2572025941_1339347332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2572025941_1339347332.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2461206086_1339347332_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2461206086_1339347332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2461206086_1339347332.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3621625761_3818048004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3621625761_3818048004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3621625761_3818048004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1726363783_1421632392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1726363783_1421632392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1726363783_1421632392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1726363783_0880774931_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1726363783_0880774931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1726363783_0880774931.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_1805755238_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_1805755238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_1805755238.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4211390896_3447751024_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4211390896_3447751024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4211390896_3447751024.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_2872019995_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_2872019995", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_2872019995.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3621625761_1006011430_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3621625761_1006011430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3621625761_1006011430.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3792286734_3205195776_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3792286734_3205195776", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3792286734_3205195776.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1696556574_3814577731_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1696556574_3814577731", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1696556574_3814577731.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3025879820_1743062843_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3025879820_1743062843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3025879820_1743062843.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1262360998_1743062843_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1262360998_1743062843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1262360998_1743062843.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_2284284933_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_2284284933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_2284284933.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1939367284_2284284933_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1939367284_2284284933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1939367284_2284284933.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0337313947_3721362834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0337313947_3721362834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0337313947_3721362834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1815377700_3721362834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1815377700_3721362834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1815377700_3721362834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2796195184_2427061199_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2796195184_2427061199", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2796195184_2427061199.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0761016561_2427061199_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0761016561_2427061199", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0761016561_2427061199.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1516909952_2151787260_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1516909952_2151787260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1516909952_2151787260.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2840081759_2151787260_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2840081759_2151787260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2840081759_2151787260.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2746923248_4072192179_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2746923248_4072192179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2746923248_4072192179.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1223200680_4072192179_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1223200680_4072192179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1223200680_4072192179.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0453698580_1574400889_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0453698580_1574400889", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0453698580_1574400889.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951154365_1574400889_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951154365_1574400889", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951154365_1574400889.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1480836731_0211795325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1480836731_0211795325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1480836731_0211795325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2584836960_0211795325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2584836960_0211795325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2584836960_0211795325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3699488411_3173694241_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3699488411_3173694241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3699488411_3173694241.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1612996771_3173694241_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1612996771_3173694241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1612996771_3173694241.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1612996771_0228975289_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1612996771_0228975289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1612996771_0228975289.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1165806166_0228975289_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1165806166_0228975289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1165806166_0228975289.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3533709985_2297679703_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3533709985_2297679703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3533709985_2297679703.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_3145599158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_3145599158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_3145599158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3533709985_4241305880_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3533709985_4241305880", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3533709985_4241305880.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0330047838_4244061630_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0330047838_4244061630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0330047838_4244061630.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3621625761_4292096971_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3621625761_4292096971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3621625761_4292096971.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3968405277_1325445144_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3968405277_1325445144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3968405277_1325445144.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_3865075107_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_3865075107", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_3865075107.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2243143290_2925552542_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2243143290_2925552542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2243143290_2925552542.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3583043198_1282135726_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3583043198_1282135726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3583043198_1282135726.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0568696350_2825944131_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0568696350_2825944131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0568696350_2825944131.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3158797248_3375592241_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3158797248_3375592241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3158797248_3375592241.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_3099488713_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_3099488713", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_3099488713.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3547742359_3099488713_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3547742359_3099488713", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3547742359_3099488713.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_1648079996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_1648079996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_1648079996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0718769485_1648079996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0718769485_1648079996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0718769485_1648079996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3547742359_1372160171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3547742359_1372160171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3547742359_1372160171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_1372160171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_1372160171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_1372160171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_0097329490_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_0097329490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_0097329490.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2120374565_0097329490_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2120374565_0097329490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2120374565_0097329490.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0338475082_0339179022_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0338475082_0339179022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0338475082_0339179022.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2536383831_0339179022_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2536383831_0339179022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2536383831_0339179022.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1754977711_0570738738_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1754977711_0570738738", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1754977711_0570738738.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1096892564_0570738738_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1096892564_0570738738", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1096892564_0570738738.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2258165848_0037651901_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2258165848_0037651901", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2258165848_0037651901.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_0037651901_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_0037651901", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_0037651901.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2545941484_3053469448_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2545941484_3053469448", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2545941484_3053469448.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2721373801_3053469448_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2721373801_3053469448", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2721373801_3053469448.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3746180462_2715627186_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3746180462_2715627186", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3746180462_2715627186.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4167961964_2715627186_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4167961964_2715627186", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4167961964_2715627186.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0461005167_0402197091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0461005167_0402197091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0461005167_0402197091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2461206086_0402197091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2461206086_0402197091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2461206086_0402197091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2747337681_2025666600_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2747337681_2025666600", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2747337681_2025666600.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_1256819347_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_1256819347", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_1256819347.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3025879820_3159073268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3025879820_3159073268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3025879820_3159073268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3401590456_3159073268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3401590456_3159073268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3401590456_3159073268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2259775028_3436779829_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2259775028_3436779829", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2259775028_3436779829.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3627133698_3436779829_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3627133698_3436779829", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3627133698_3436779829.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_0559442149_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_0559442149", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_0559442149.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1262360998_0559442149_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1262360998_0559442149", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1262360998_0559442149.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0965110568_1401539274_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0965110568_1401539274", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0965110568_1401539274.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_1401539274_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_1401539274", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_1401539274.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2445281037_2265677291_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2445281037_2265677291", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2445281037_2265677291.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_2265677291_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_2265677291", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_2265677291.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3335474172_1490992768_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3335474172_1490992768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3335474172_1490992768.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3580249038_1490992768_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3580249038_1490992768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3580249038_1490992768.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_1573591642_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_1573591642", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_1573591642.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3766886815_1679794709_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3766886815_1679794709", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3766886815_1679794709.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762900403_1679794709_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762900403_1679794709", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762900403_1679794709.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3762257648_2346567979_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3762257648_2346567979", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3762257648_2346567979.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4186630640_2346567979_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4186630640_2346567979", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4186630640_2346567979.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0705143048_1160147757_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0705143048_1160147757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0705143048_1160147757.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1490279697_1160147757_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1490279697_1160147757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1490279697_1160147757.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3297866815_2867075091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3297866815_2867075091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3297866815_2867075091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2974780710_2867075091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2974780710_2867075091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2974780710_2867075091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762900403_3573508063_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762900403_3573508063", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762900403_3573508063.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0250228225_3573508063_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0250228225_3573508063", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0250228225_3573508063.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4186630640_3870020964_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4186630640_3870020964", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4186630640_3870020964.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0233462558_3870020964_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0233462558_3870020964", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0233462558_3870020964.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1741877342_1735691022_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1741877342_1735691022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1741877342_1735691022.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1108674716_1735691022_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1108674716_1735691022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1108674716_1735691022.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1096892564_2855495341_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1096892564_2855495341", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1096892564_2855495341.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1754977711_2855495341_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1754977711_2855495341", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1754977711_2855495341.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2259775028_0780724058_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2259775028_0780724058", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2259775028_0780724058.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1311648806_0780724058_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1311648806_0780724058", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1311648806_0780724058.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0000626974_0484201953_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0000626974_0484201953", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0000626974_0484201953.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_0484201953_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_0484201953", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_0484201953.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3968405277_2094708517_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3968405277_2094708517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3968405277_2094708517.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2377645808_2483766177_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2377645808_2483766177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2377645808_2483766177.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3133393823_0742758618_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3133393823_0742758618", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3133393823_0742758618.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1727721645_0742758618_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1727721645_0742758618", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1727721645_0742758618.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3147467718_4151960239_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3147467718_4151960239", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3147467718_4151960239.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3645302301_0494588813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3645302301_0494588813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3645302301_0494588813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2614925375_0494588813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2614925375_0494588813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2614925375_0494588813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3645302301_0882894651_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3645302301_0882894651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3645302301_0882894651.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0810312212_0882894651_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0810312212_0882894651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0810312212_0882894651.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_2574991008_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_2574991008", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_2574991008.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3584929060_2574991008_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3584929060_2574991008", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3584929060_2574991008.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4258815622_0632203258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4258815622_0632203258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4258815622_0632203258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1936247035_0632203258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1936247035_0632203258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1936247035_0632203258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3858389326_4164641117_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3858389326_4164641117", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3858389326_4164641117.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1573120145_4164641117_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1573120145_4164641117", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1573120145_4164641117.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4097496686_1223490988_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4097496686_1223490988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4097496686_1223490988.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0400020013_1223490988_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0400020013_1223490988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0400020013_1223490988.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2986951556_0414943633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2986951556_0414943633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2986951556_0414943633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2450234616_0414943633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2450234616_0414943633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2450234616_0414943633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1754977711_2695937859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1754977711_2695937859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1754977711_2695937859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2721373801_2695937859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2721373801_2695937859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2721373801_2695937859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3746180462_1349453511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3746180462_1349453511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3746180462_1349453511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4273332447_1349453511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4273332447_1349453511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4273332447_1349453511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2545941484_2220133811_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2545941484_2220133811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2545941484_2220133811.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0161752130_2220133811_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0161752130_2220133811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0161752130_2220133811.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1918776540_2475269129_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1918776540_2475269129", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1918776540_2475269129.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2348808454_2475269129_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2348808454_2475269129", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2348808454_2475269129.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0461005167_0319609438_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0461005167_0319609438", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0461005167_0319609438.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_0319609438_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_0319609438", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_0319609438.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1718316496_4241404256_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1718316496_4241404256", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1718316496_4241404256.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1037392457_0368848417_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1037392457_0368848417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1037392457_0368848417.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4000734257_2893948990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4000734257_2893948990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4000734257_2893948990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_2886016245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_2886016245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_2886016245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2649204827_2429630212_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2649204827_2429630212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2649204827_2429630212.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_3004499080_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_3004499080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_3004499080.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2691224916_3891182424_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2691224916_3891182424", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2691224916_3891182424.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0109169397_3026737747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0109169397_3026737747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0109169397_3026737747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3482774339_2624711803_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3482774339_2624711803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3482774339_2624711803.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1973556332_4135170509_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1973556332_4135170509", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1973556332_4135170509.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0118779587_4280824512_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0118779587_4280824512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0118779587_4280824512.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0640091355_2986963300_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0640091355_2986963300", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0640091355_2986963300.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2516406211_3879640755_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_3879640755", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_3879640755.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2219750583_0290486934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2219750583_0290486934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2219750583_0290486934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3388370273_1136411392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3388370273_1136411392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3388370273_1136411392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3388370273_3496229166_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3388370273_3496229166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3388370273_3496229166.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0108713357_4114492805_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0108713357_4114492805", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0108713357_4114492805.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3388370273_1106828453_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3388370273_1106828453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3388370273_1106828453.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2219750583_0980968157_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2219750583_0980968157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2219750583_0980968157.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3035046424_1537880429_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3035046424_1537880429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3035046424_1537880429.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4183817166_1349762835_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4183817166_1349762835", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4183817166_1349762835.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0581413654_1562964490_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0581413654_1562964490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0581413654_1562964490.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2353720381_0653334543_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2353720381_0653334543", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2353720381_0653334543.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_1822267460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_1822267460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_1822267460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3872789993_1829458923_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3872789993_1829458923", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3872789993_1829458923.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0108713357_2057835039_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0108713357_2057835039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0108713357_2057835039.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1187469099_1853873158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1187469099_1853873158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1187469099_1853873158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1199631270_1853873158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1199631270_1853873158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1199631270_1853873158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_1774173115_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_1774173115", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_1774173115.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_1774173115_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_1774173115", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_1774173115.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0682082248_0182644048_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0682082248_0182644048", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0682082248_0182644048.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4211390896_3769082778_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4211390896_3769082778", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4211390896_3769082778.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2445758030_4099405546_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2445758030_4099405546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2445758030_4099405546.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3533318118_2953807395_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3533318118_2953807395", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3533318118_2953807395.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4145343985_1368157442_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4145343985_1368157442", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4145343985_1368157442.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0250244551_1368157442_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0250244551_1368157442", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0250244551_1368157442.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3586464735_1313201700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3586464735_1313201700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3586464735_1313201700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1654508532_1313201700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1654508532_1313201700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1654508532_1313201700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_3731081264_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_3731081264", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_3731081264.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1421999720_1533131178_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1421999720_1533131178", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1421999720_1533131178.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2928010951_1533131178_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2928010951_1533131178", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2928010951_1533131178.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1654508532_1233298312_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1654508532_1233298312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1654508532_1233298312.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3586464735_1233298312_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3586464735_1233298312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3586464735_1233298312.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_1748408230_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_1748408230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_1748408230.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3547742359_1748408230_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3547742359_1748408230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3547742359_1748408230.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3645302301_2865794813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3645302301_2865794813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3645302301_2865794813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2614925375_2865794813_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2614925375_2865794813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2614925375_2865794813.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0312011143_2754306616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0312011143_2754306616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0312011143_2754306616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0928977221_2754306616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0928977221_2754306616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0928977221_2754306616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2258165848_3452347148_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2258165848_3452347148", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2258165848_3452347148.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_3452347148_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_3452347148", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_3452347148.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1754977711_3065597168_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1754977711_3065597168", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1754977711_3065597168.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1096892564_3065597168_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1096892564_3065597168", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1096892564_3065597168.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1754977711_1173425555_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1754977711_1173425555", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1754977711_1173425555.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0161752130_1173425555_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0161752130_1173425555", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0161752130_1173425555.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_3733143362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_3733143362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_3733143362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1262360998_3733143362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1262360998_3733143362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1262360998_3733143362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2336560256_4078845663_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2336560256_4078845663", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2336560256_4078845663.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_4078845663_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_4078845663", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_4078845663.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0645401329_0419592700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0645401329_0419592700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0645401329_0419592700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3512302648_1460583516_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3512302648_1460583516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3512302648_1460583516.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2887204203_2414691380_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2887204203_2414691380", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2887204203_2414691380.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2537795031_2046334170_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2537795031_2046334170", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2537795031_2046334170.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2863026909_0616773131_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2863026909_0616773131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2863026909_0616773131.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0348082703_0616773131_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0348082703_0616773131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0348082703_0616773131.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0332947343_2469457905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0332947343_2469457905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0332947343_2469457905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0187187452_2469457905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0187187452_2469457905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0187187452_2469457905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0446596595_4029471971_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0446596595_4029471971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0446596595_4029471971.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3509192812_4029471971_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3509192812_4029471971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3509192812_4029471971.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3750152449_4173815894_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3750152449_4173815894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3750152449_4173815894.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1740459040_2556941334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1740459040_2556941334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1740459040_2556941334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2886320575_2556941334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2886320575_2556941334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2886320575_2556941334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0527178396_2526848905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0527178396_2526848905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0527178396_2526848905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3620101390_2526848905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3620101390_2526848905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3620101390_2526848905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1826694876_0990512807_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1826694876_0990512807", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1826694876_0990512807.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1699177137_0990512807_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1699177137_0990512807", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1699177137_0990512807.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1551513305_1786138788_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1551513305_1786138788", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1551513305_1786138788.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3784992914_1786138788_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3784992914_1786138788", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3784992914_1786138788.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3582056282_4105198285_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3582056282_4105198285", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3582056282_4105198285.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4082689429_4105198285_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4082689429_4105198285", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4082689429_4105198285.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3005301623_3405864245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3005301623_3405864245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3005301623_3405864245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1096892564_3405864245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1096892564_3405864245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1096892564_3405864245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3746180462_1319515764_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3746180462_1319515764", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3746180462_1319515764.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4167961964_1319515764_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4167961964_1319515764", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4167961964_1319515764.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2065231520_3613133270_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2065231520_3613133270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2065231520_3613133270.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0088630782_3613133270_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0088630782_3613133270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0088630782_3613133270.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2787288474_3791953649_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2787288474_3791953649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2787288474_3791953649.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0068426716_3791953649_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0068426716_3791953649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0068426716_3791953649.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0461005167_2176694072_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0461005167_2176694072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0461005167_2176694072.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_2176694072_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_2176694072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_2176694072.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4106386431_0535937500_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4106386431_0535937500", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4106386431_0535937500.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0112477914_4154049834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0112477914_4154049834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0112477914_4154049834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1311648806_4154049834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1311648806_4154049834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1311648806_4154049834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4200247466_2987726919_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4200247466_2987726919", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4200247466_2987726919.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2747895650_2987726919_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2747895650_2987726919", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2747895650_2987726919.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3025879820_1156441893_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3025879820_1156441893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3025879820_1156441893.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1262360998_1156441893_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1262360998_1156441893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1262360998_1156441893.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0112477914_2816810581_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0112477914_2816810581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0112477914_2816810581.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1311648806_2816810581_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1311648806_2816810581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1311648806_2816810581.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4175523013_0334551893_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4175523013_0334551893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4175523013_0334551893.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3789056835_3241715628_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3789056835_3241715628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3789056835_3241715628.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_3241715628_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_3241715628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_3241715628.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3789056835_1998574578_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3789056835_1998574578", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3789056835_1998574578.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1819657756_1998574578_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1819657756_1998574578", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1819657756_1998574578.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0380081591_4206954571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0380081591_4206954571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0380081591_4206954571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2078706789_4206954571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2078706789_4206954571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2078706789_4206954571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3312833381_1210545515_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3312833381_1210545515", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3312833381_1210545515.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0529239560_1210545515_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0529239560_1210545515", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0529239560_1210545515.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0330047838_1101138080_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0330047838_1101138080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0330047838_1101138080.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4211390896_3916973561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4211390896_3916973561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4211390896_3916973561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_2273874694_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_2273874694", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_2273874694.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3872789993_2229458242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3872789993_2229458242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3872789993_2229458242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2863026909_1363436989_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2863026909_1363436989", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2863026909_1363436989.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2641769766_1363436989_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2641769766_1363436989", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2641769766_1363436989.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0461005167_2362620984_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0461005167_2362620984", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0461005167_2362620984.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1204546957_2362620984_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1204546957_2362620984", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1204546957_2362620984.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3024108228_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3024108228", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3024108228.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2422559401_1292294149_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2422559401_1292294149", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2422559401_1292294149.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0317303085_4219987471_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0317303085_4219987471", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0317303085_4219987471.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3506860562_3569905049_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3506860562_3569905049", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3506860562_3569905049.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4282158275_0808389208_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4282158275_0808389208", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4282158275_0808389208.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2383649469_0252384533_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2383649469_0252384533", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2383649469_0252384533.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4259143933_3355400597_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4259143933_3355400597", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4259143933_3355400597.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_0062120766_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_0062120766", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_0062120766.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_3988378589_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_3988378589", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_3988378589.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_1166046932_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_1166046932", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_1166046932.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_3585739235_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_3585739235", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_3585739235.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_2560349469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_2560349469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_2560349469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_3896440361_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_3896440361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_3896440361.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4279317356_1802899967_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4279317356_1802899967", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4279317356_1802899967.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0905772714_4217880970_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0905772714_4217880970", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0905772714_4217880970.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0798997602_4084991922_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0798997602_4084991922", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0798997602_4084991922.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_3192784444_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_3192784444", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_3192784444.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_2330627295_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_2330627295", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_2330627295.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_2295430934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_2295430934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_2295430934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3579922763_0501012084_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3579922763_0501012084", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3579922763_0501012084.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_2516016741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_2516016741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_2516016741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_0869609516_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_0869609516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_0869609516.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_3248418296_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_3248418296", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_3248418296.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_3170016673_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_3170016673", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_3170016673.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_0471286396_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_0471286396", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_0471286396.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_0814374702_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_0814374702", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_0814374702.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_2435085447_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_2435085447", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_2435085447.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3579922763_1774489456_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3579922763_1774489456", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3579922763_1774489456.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1460282971_0908295334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1460282971_0908295334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1460282971_0908295334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0138461406_0650814952_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0138461406_0650814952", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0138461406_0650814952.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1856103883_0066392501_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1856103883_0066392501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1856103883_0066392501.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_3797812569_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_3797812569", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_3797812569.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2422559401_2379333589_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2422559401_2379333589", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2422559401_2379333589.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2445590369_0446038371_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2445590369_0446038371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2445590369_0446038371.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_3152204062_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_3152204062", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_3152204062.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_0277317972_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_0277317972", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_0277317972.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_1972090786_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_1972090786", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_1972090786.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_4009400913_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_4009400913", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_4009400913.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_1015798525_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_1015798525", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_1015798525.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_3976000076_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_3976000076", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_3976000076.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_0773516055_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_0773516055", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_0773516055.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2520448996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2520448996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2520448996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1732519008_1799522065_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1732519008_1799522065", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1732519008_1799522065.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_1100369593_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_1100369593", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_1100369593.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_2464419320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_2464419320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_2464419320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3983810000_2865719206_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3983810000_2865719206", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3983810000_2865719206.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3775749744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3775749744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3775749744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_2226420417_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_2226420417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_2226420417.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_3291284342_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_3291284342", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_3291284342.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_3597147309_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_3597147309", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_3597147309.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1460282971_2828008752_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1460282971_2828008752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1460282971_2828008752.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_3175641838_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_3175641838", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_3175641838.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4238007408_3361635738_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4238007408_3361635738", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4238007408_3361635738.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_3053711581_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_3053711581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_3053711581.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0057941209_3573774875_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0057941209_3573774875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0057941209_3573774875.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_0895515271_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_0895515271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_0895515271.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_1854111897_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_1854111897", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_1854111897.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0629232744_3112795024_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0629232744_3112795024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0629232744_3112795024.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1287388431_1685159844_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1287388431_1685159844", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1287388431_1685159844.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_3829181974_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_3829181974", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_3829181974.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_0091509418_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_0091509418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_0091509418.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_1306964013_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_1306964013", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_1306964013.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_0564423150_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_0564423150", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_0564423150.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_3396127940_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_3396127940", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_3396127940.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2556712046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2556712046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2556712046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_1592073254_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_1592073254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_1592073254.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_1202617950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_1202617950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_1202617950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0092506900_1613704970_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0092506900_1613704970", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0092506900_1613704970.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2410918564_3841422764_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2410918564_3841422764", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2410918564_3841422764.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1372703720_2220311142_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1372703720_2220311142", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1372703720_2220311142.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_3494915146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_3494915146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_3494915146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_2223041583_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_2223041583", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_2223041583.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_2050307419_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_2050307419", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_2050307419.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_1247012425_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_1247012425", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_1247012425.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_2230189643_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_2230189643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_2230189643.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_1633960996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_1633960996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_1633960996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_1310672268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_1310672268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_1310672268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_2099668678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_2099668678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_2099668678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_1437709696_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_1437709696", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_1437709696.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2367250415_2293686320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2367250415_2293686320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2367250415_2293686320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_3490363362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_3490363362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_3490363362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1054284712_2328848331_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1054284712_2328848331", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1054284712_2328848331.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2992882049_2042477501_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2992882049_2042477501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2992882049_2042477501.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_0462070904_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_0462070904", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_0462070904.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_1942158338_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_1942158338", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_1942158338.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_0231142863_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_0231142863", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_0231142863.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3506860562_3365255920_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3506860562_3365255920", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3506860562_3365255920.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_2489308146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_2489308146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_2489308146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2745268831_0475115767_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2745268831_0475115767", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2745268831_0475115767.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1287388431_0015951207_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1287388431_0015951207", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1287388431_0015951207.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1544598748_3842554733_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1544598748_3842554733", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1544598748_3842554733.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_3880102520_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_3880102520", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_3880102520.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_2295917942_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_2295917942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_2295917942.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_3924383382_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_3924383382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_3924383382.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_2972153624_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_2972153624", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_2972153624.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_1956499542_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_1956499542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_1956499542.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_0041662691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_0041662691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_0041662691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_2630353113_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_2630353113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_2630353113.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_4012812463_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_4012812463", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_4012812463.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0092506900_1723847457_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0092506900_1723847457", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0092506900_1723847457.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3475865810_2514448735_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3475865810_2514448735", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3475865810_2514448735.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_4115950173_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_4115950173", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_4115950173.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1530284962_0626112979_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1530284962_0626112979", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1530284962_0626112979.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1372703720_4198402360_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1372703720_4198402360", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1372703720_4198402360.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0317303085_3917744991_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0317303085_3917744991", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0317303085_3917744991.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_0201245992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_0201245992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_0201245992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2856459754_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2856459754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2856459754.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_2350560391_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_2350560391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_2350560391.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4205225303_2333643785_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4205225303_2333643785", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4205225303_2333643785.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1287388431_4098412358_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1287388431_4098412358", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1287388431_4098412358.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_1346856528_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_1346856528", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_1346856528.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_2131975226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_2131975226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_2131975226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_1665749900_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_1665749900", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_1665749900.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1460282971_1308214828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1460282971_1308214828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1460282971_1308214828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_1066551156_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_1066551156", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_1066551156.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_4057153887_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_4057153887", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_4057153887.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_0414964460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_0414964460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_0414964460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_0363178667_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_0363178667", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_0363178667.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_0535738333_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_0535738333", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_0535738333.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4259143933_3814562286_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4259143933_3814562286", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4259143933_3814562286.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_1804937560_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_1804937560", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_1804937560.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_2565418530_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_2565418530", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_2565418530.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_3567647863_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_3567647863", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_3567647863.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_3202320905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_3202320905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_3202320905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3983810000_0208802171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3983810000_0208802171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3983810000_0208802171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_3539144993_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_3539144993", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_3539144993.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_1099573146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_1099573146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_1099573146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_1746107570_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_1746107570", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_1746107570.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_1428175285_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_1428175285", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_1428175285.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2012179891_2923083675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2012179891_2923083675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2012179891_2923083675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3579922763_3990294124_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3579922763_3990294124", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3579922763_3990294124.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_3047181859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_3047181859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_3047181859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1460282971_2304084981_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1460282971_2304084981", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1460282971_2304084981.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_2369825978_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_2369825978", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_2369825978.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3579922763_2074589827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3579922763_2074589827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3579922763_2074589827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_4164477221_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_4164477221", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_4164477221.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3579922763_3227001476_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3579922763_3227001476", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3579922763_3227001476.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_2535905180_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_2535905180", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_2535905180.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1137071313_0808694668_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1137071313_0808694668", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1137071313_0808694668.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0330175904_3886565843_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0330175904_3886565843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0330175904_3886565843.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_0144024478_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_0144024478", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_0144024478.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_0105275489_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_0105275489", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_0105275489.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1362517884_2617284412_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1362517884_2617284412", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1362517884_2617284412.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1159575906_0453575992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1159575906_0453575992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1159575906_0453575992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0092506900_2508726320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0092506900_2508726320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0092506900_2508726320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3538134887_2484369933_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3538134887_2484369933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3538134887_2484369933.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_1891036341_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_1891036341", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_1891036341.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2890412865_0966713725_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2890412865_0966713725", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2890412865_0966713725.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_2602864547_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_2602864547", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_2602864547.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_4062100810_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_4062100810", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_4062100810.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_3147016793_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_3147016793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_3147016793.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_2249492607_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_2249492607", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_2249492607.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_1520280686_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_1520280686", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_1520280686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_3629906135_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_3629906135", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_3629906135.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_0269900021_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_0269900021", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_0269900021.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_0324460204_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_0324460204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_0324460204.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_1511050267_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_1511050267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_1511050267.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_1731306601_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_1731306601", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_1731306601.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_0074960413_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_0074960413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_0074960413.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0811049147_3100432226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0811049147_3100432226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0811049147_3100432226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0090447744_0675099307_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0090447744_0675099307", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0090447744_0675099307.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_0725140993_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_0725140993", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_0725140993.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1595077949_2586103544_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1595077949_2586103544", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1595077949_2586103544.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_3638725423_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_3638725423", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_3638725423.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_2355076064_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_2355076064", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_2355076064.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_2647958978_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_2647958978", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_2647958978.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_0352543605_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_0352543605", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_0352543605.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4129444368_3757168818_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4129444368_3757168818", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4129444368_3757168818.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2516406211_2197892261_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_2197892261", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_2197892261.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_0364515469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_0364515469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_0364515469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_0660066766_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_0660066766", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_0660066766.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_1906131944_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_1906131944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_1906131944.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4129444368_1091001814_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4129444368_1091001814", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4129444368_1091001814.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_2168581031_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_2168581031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_2168581031.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_4103269004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_4103269004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_4103269004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_1411430944_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_1411430944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_1411430944.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_0273709705_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_0273709705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_0273709705.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_1422086768_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_1422086768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_1422086768.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_0137154662_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_0137154662", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_0137154662.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_2002370083_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_2002370083", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_2002370083.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_1625205611_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_1625205611", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_1625205611.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3475865810_3020228506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3475865810_3020228506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3475865810_3020228506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1362517884_1966151519_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1362517884_1966151519", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1362517884_1966151519.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2286054170_2739557824_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2286054170_2739557824", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2286054170_2739557824.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2370737840_1128777536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2370737840_1128777536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2370737840_1128777536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2370737840_0025283898_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2370737840_0025283898", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2370737840_0025283898.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3093550431_0023879996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3093550431_0023879996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3093550431_0023879996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_0034956626_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_0034956626", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_0034956626.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_4121684782_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_4121684782", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_4121684782.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_2958426793_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_2958426793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_2958426793.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1681352429_0141173485_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1681352429_0141173485", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1681352429_0141173485.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_3715766804_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_3715766804", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_3715766804.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0354992839_2276593171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0354992839_2276593171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0354992839_2276593171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0746069551_3703618294_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0746069551_3703618294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0746069551_3703618294.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1647941984_0940359250_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1647941984_0940359250", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1647941984_0940359250.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2587474290_4059578090_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2587474290_4059578090", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2587474290_4059578090.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_2187015320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_2187015320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_2187015320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4238007408_1053507691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4238007408_1053507691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4238007408_1053507691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2821654552_2479844994_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2821654552_2479844994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2821654552_2479844994.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_0173542633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_0173542633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_0173542633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_2013746418_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_2013746418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_2013746418.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_3042955088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_3042955088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_3042955088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_2770927247_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_2770927247", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_2770927247.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_0249522246_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_0249522246", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_0249522246.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_0154346994_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_0154346994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_0154346994.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0821277161_0281191987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0821277161_0281191987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0821277161_0281191987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2917805990_1607331101_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2917805990_1607331101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2917805990_1607331101.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_3852101591_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_3852101591", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_3852101591.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0513560621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0513560621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0513560621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1659937761_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1659937761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1659937761.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1729791560_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1729791560", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1729791560.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_2228840613_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_2228840613", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_2228840613.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_1260454329_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_1260454329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_1260454329.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3211164260_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3211164260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3211164260.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_3782195178_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_3782195178", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_3782195178.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_3129761741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_3129761741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_3129761741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0483197804_1999324444_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0483197804_1999324444", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0483197804_1999324444.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4072568369_1711633372_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4072568369_1711633372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4072568369_1711633372.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1180466501_1166014375_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1180466501_1166014375", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1180466501_1166014375.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2471993628_0977178710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2471993628_0977178710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2471993628_0977178710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2745810320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2745810320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2745810320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3154439686_0683848664_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3154439686_0683848664", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3154439686_0683848664.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_2964712185_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_2964712185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_2964712185.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2921684672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2921684672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2921684672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1395622046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1395622046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1395622046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2713868467_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2713868467", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2713868467.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3068184698_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3068184698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3068184698.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3486127174_2864553113_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3486127174_2864553113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3486127174_2864553113.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3845374108_1098229481_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3845374108_1098229481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3845374108_1098229481.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_1796932507_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_1796932507", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_1796932507.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1941145413_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1941145413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1941145413.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_1908721506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_1908721506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_1908721506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3405635499_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3405635499", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3405635499.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0572469672_1314502407_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0572469672_1314502407", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0572469672_1314502407.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1726371755_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1726371755", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1726371755.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3154439686_0772080204_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3154439686_0772080204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3154439686_0772080204.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_4270697358_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_4270697358", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_4270697358.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0572469672_4202199987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0572469672_4202199987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0572469672_4202199987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_2548894758_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_2548894758", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_2548894758.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1287420135_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1287420135", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1287420135.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2092415377_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2092415377", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2092415377.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_2569106943_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_2569106943", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_2569106943.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_1994596033_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_1994596033", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_1994596033.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_0109996254_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_0109996254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_0109996254.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_3675828571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_3675828571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_3675828571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_1478672267_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_1478672267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_1478672267.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3084965045_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3084965045", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3084965045.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1557622710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1557622710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1557622710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1457069283_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1457069283", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1457069283.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_3793534284_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_3793534284", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_3793534284.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_1438863039_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_1438863039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_1438863039.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_3590126440_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_3590126440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_3590126440.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1667378233_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1667378233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1667378233.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3792286734_2777779575_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3792286734_2777779575", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3792286734_2777779575.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2326585614_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2326585614", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2326585614.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3544822211_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3544822211", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3544822211.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_0646969166_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_0646969166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_0646969166.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0855822792_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0855822792", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0855822792.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4134947379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4134947379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4134947379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0138186094_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0138186094", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0138186094.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2853502404_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2853502404", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2853502404.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1695354101_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1695354101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1695354101.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3029850912_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3029850912", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3029850912.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0572469672_2278627212_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0572469672_2278627212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0572469672_2278627212.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4264293018_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4264293018", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4264293018.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3144696329_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3144696329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3144696329.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2300899506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2300899506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2300899506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_2657854184_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_2657854184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_2657854184.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1505860579_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1505860579", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1505860579.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_0633550356_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_0633550356", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_0633550356.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3157854047_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3157854047", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3157854047.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3050481445_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3050481445", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3050481445.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4086063599_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4086063599", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4086063599.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4151947730_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4151947730", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4151947730.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1774869141_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1774869141", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1774869141.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2353720381_1418096430_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2353720381_1418096430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2353720381_1418096430.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1595077949_0474876625_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1595077949_0474876625", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1595077949_0474876625.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_1583903827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_1583903827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_1583903827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2243181466_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2243181466", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2243181466.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0204183025_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0204183025", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0204183025.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_3881289888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_3881289888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_3881289888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0829540680_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0829540680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0829540680.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0742104041_0949904104_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0742104041_0949904104", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0742104041_0949904104.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_2917723512_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_2917723512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_2917723512.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_1033958954_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_1033958954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_1033958954.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_0820445927_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_0820445927", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_0820445927.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3025961744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3025961744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3025961744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0211723496_2620707109_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0211723496_2620707109", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0211723496_2620707109.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3756876134_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3756876134", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3756876134.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1026652703_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1026652703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1026652703.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2355058990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2355058990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2355058990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3051797672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3051797672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3051797672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1274372133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1274372133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1274372133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1512363926_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1512363926", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1512363926.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1875258475_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1875258475", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1875258475.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4118582672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4118582672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4118582672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3116212947_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3116212947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3116212947.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2566248539_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2566248539", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2566248539.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3213167982_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3213167982", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3213167982.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3070009689_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3070009689", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3070009689.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_3880304289_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_3880304289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_3880304289.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_2085353271_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_2085353271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_2085353271.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_0679198752_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_0679198752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_0679198752.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_0231074541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_0231074541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_0231074541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2171636849_1438699207_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2171636849_1438699207", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2171636849_1438699207.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_1090837934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_1090837934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_1090837934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1959866565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1959866565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1959866565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1866038767_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1866038767", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1866038767.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_2588531868_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_2588531868", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_2588531868.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_2342021935_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_2342021935", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_2342021935.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2060027411_0911345633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2060027411_0911345633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2060027411_0911345633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_2903034621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_2903034621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_2903034621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_3300909004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_3300909004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_3300909004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1463433355_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1463433355", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1463433355.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3776775032_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3776775032", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3776775032.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2191996307_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2191996307", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2191996307.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0833728939_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0833728939", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0833728939.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0581413654_3178228103_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0581413654_3178228103", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0581413654_3178228103.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3358834441_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3358834441", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3358834441.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_0892993037_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_0892993037", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_0892993037.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1726389132_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1726389132", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1726389132.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3055055156_0781655361_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3055055156_0781655361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3055055156_0781655361.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_1516381469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_1516381469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_1516381469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0356880894_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0356880894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0356880894.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0924901393_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0924901393", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0924901393.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3937810836_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3937810836", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3937810836.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_1401521511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_1401521511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_1401521511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3159092825_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3159092825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3159092825.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2280979608_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2280979608", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2280979608.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2546286540_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2546286540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2546286540.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_4058598905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_4058598905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_4058598905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4282770026_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4282770026", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4282770026.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2060027411_1824737179_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2060027411_1824737179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2060027411_1824737179.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0232707698_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0232707698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0232707698.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_0602207096_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_0602207096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_0602207096.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3154439686_1587016992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3154439686_1587016992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3154439686_1587016992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1595077949_1649017628_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1595077949_1649017628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1595077949_1649017628.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_2051689230_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_2051689230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_2051689230.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3746051088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3746051088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3746051088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1298913368_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1298913368", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1298913368.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_2429212037_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_2429212037", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_2429212037.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_0709520988_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_0709520988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_0709520988.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1140685677_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1140685677", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1140685677.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_2473972399_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_2473972399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_2473972399.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1173523947_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1173523947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1173523947.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2608840750_0188042735_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2608840750_0188042735", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2608840750_0188042735.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_3386070196_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_3386070196", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_3386070196.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_2007383888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_2007383888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_2007383888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_0108181794_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_0108181794", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_0108181794.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_2755070747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_2755070747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_2755070747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1835359917_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1835359917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1835359917.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_1395717791_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_1395717791", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_1395717791.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3205766657_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3205766657", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3205766657.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1752196397_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1752196397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1752196397.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_2252138728_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_2252138728", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_2252138728.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1779957878_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1779957878", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1779957878.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0206050100_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0206050100", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0206050100.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_2682686406_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_2682686406", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_2682686406.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2914138493_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2914138493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2914138493.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0146653961_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0146653961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0146653961.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1776697137_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1776697137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1776697137.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3736314486_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3736314486", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3736314486.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3823763151_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3823763151", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3823763151.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0290453918_0644999616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0290453918_0644999616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0290453918_0644999616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_2932160232_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_2932160232", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_2932160232.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2855331541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2855331541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2855331541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0319773222_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0319773222", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0319773222.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_1934880621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_1934880621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_1934880621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0559671453_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0559671453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0559671453.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_3224958158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_3224958158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_3224958158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4031089392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4031089392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4031089392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_2515735803_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_2515735803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_2515735803.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0093958401_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0093958401", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0093958401.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3154439686_2438938700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3154439686_2438938700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3154439686_2438938700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_0015516561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_0015516561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_0015516561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3758269841_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3758269841", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3758269841.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_2292861917_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_2292861917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_2292861917.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2463051737_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2463051737", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2463051737.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_3286937133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_3286937133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_3286937133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_2618864769_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_2618864769", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_2618864769.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_3365303589_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_3365303589", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_3365303589.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_4145332070_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_4145332070", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_4145332070.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_0713189091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_0713189091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_0713189091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0852929691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0852929691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0852929691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3086620986_1336257219_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3086620986_1336257219", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3086620986_1336257219.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_2541703958_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_2541703958", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_2541703958.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_0022438771_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_0022438771", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_0022438771.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_2423286184_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_2423286184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_2423286184.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_1758879956_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_1758879956", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_1758879956.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_3819993669_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_3819993669", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_3819993669.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0138461406_2050064325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0138461406_2050064325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0138461406_2050064325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_2189951160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_2189951160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_2189951160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_3472133399_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_3472133399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_3472133399.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4161206353_4067411469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4161206353_4067411469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4161206353_4067411469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_2136107710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_2136107710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_2136107710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_1447760046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_1447760046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_1447760046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_2081516703_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_2081516703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_2081516703.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_1360912695_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_1360912695", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_1360912695.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2991650286_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2991650286", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2991650286.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922224307_2785404881_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922224307_2785404881", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922224307_2785404881.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_4278242573_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_4278242573", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_4278242573.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3128954271_3771301419_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3128954271_3771301419", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3128954271_3771301419.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0246896403_0741827557_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0246896403_0741827557", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0246896403_0741827557.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_4142624119_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_4142624119", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_4142624119.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_3188452245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_3188452245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_3188452245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_2624455968_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_2624455968", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_2624455968.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_3966863360_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_3966863360", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_3966863360.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_1495442244_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_1495442244", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_1495442244.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2129103041_1988348043_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2129103041_1988348043", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2129103041_1988348043.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1374197414_1759071197_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1374197414_1759071197", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1374197414_1759071197.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4279317356_0445084272_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4279317356_0445084272", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4279317356_0445084272.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0567713443_0524785965_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0567713443_0524785965", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0567713443_0524785965.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_4049484563_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_4049484563", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_4049484563.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1575855633_1467766106_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1575855633_1467766106", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1575855633_1467766106.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1266325221_1481421517_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1266325221_1481421517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1266325221_1481421517.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_1645466859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_1645466859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_1645466859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3642663284_3195637744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3642663284_3195637744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3642663284_3195637744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4017332395_0005595294_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4017332395_0005595294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4017332395_0005595294.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0284942040_4083964602_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0284942040_4083964602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0284942040_4083964602.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1442149751_1535267322_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1442149751_1535267322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1442149751_1535267322.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_1978049990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_1978049990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_1978049990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0408563312_0511473576_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0408563312_0511473576", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0408563312_0511473576.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1020495346_3737687741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1020495346_3737687741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1020495346_3737687741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1020495346_1883958718_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1020495346_1883958718", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1020495346_1883958718.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1374197414_2102657699_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1374197414_2102657699", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1374197414_2102657699.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2416390619_1057182747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2416390619_1057182747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2416390619_1057182747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1374197414_3958840630_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1374197414_3958840630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1374197414_3958840630.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_2924750215_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_2924750215", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_2924750215.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_2944616438_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_2944616438", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_2944616438.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2404798728_2461276946_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2404798728_2461276946", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2404798728_2461276946.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3946533733_3103282101_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3946533733_3103282101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3946533733_3103282101.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0567713443_2423201705_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0567713443_2423201705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0567713443_2423201705.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4279317356_3502325541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4279317356_3502325541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4279317356_3502325541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0905772714_2380621462_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0905772714_2380621462", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0905772714_2380621462.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4279317356_0452740795_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4279317356_0452740795", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4279317356_0452740795.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_0156250756_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_0156250756", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_0156250756.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3256702861_2711346233_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3256702861_2711346233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3256702861_2711346233.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4012859310_3242888292_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4012859310_3242888292", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4012859310_3242888292.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_3251071346_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_3251071346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_3251071346.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1595077949_2431878981_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1595077949_2431878981", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1595077949_2431878981.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_1945549339_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_1945549339", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_1945549339.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_2601737211_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_2601737211", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_2601737211.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_0932811753_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_0932811753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_0932811753.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_0574810702_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_0574810702", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_0574810702.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3266314467_0504441441_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3266314467_0504441441", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3266314467_0504441441.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3340709229_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3340709229", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3340709229.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_2254397636_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_2254397636", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_2254397636.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3506860562_3280466916_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3506860562_3280466916", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3506860562_3280466916.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3506860562_3389087018_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3506860562_3389087018", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3506860562_3389087018.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0354992839_0632142040_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0354992839_0632142040", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0354992839_0632142040.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0138461406_4006952649_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0138461406_4006952649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0138461406_4006952649.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0138461406_0460468723_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0138461406_0460468723", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0138461406_0460468723.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0284942040_2480080801_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0284942040_2480080801", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0284942040_2480080801.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_1445317919_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_1445317919", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_1445317919.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3792142803_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3792142803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3792142803.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_2501910747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_2501910747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_2501910747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3720591643_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3720591643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3720591643.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_4052908338_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_4052908338", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_4052908338.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_1414644071_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_1414644071", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_1414644071.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_0050941226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_0050941226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_0050941226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_1718880411_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_1718880411", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_1718880411.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_0392889902_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_0392889902", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_0392889902.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_2789263542_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_2789263542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_2789263542.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2060027411_0580261000_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2060027411_0580261000", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2060027411_0580261000.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_2256392325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_2256392325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_2256392325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2516406211_0897849717_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_0897849717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_0897849717.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_0258328740_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_0258328740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_0258328740.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_2221131864_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_2221131864", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_2221131864.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_3868350906_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_3868350906", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_3868350906.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_0379028656_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_0379028656", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_0379028656.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_2707709258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_2707709258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_2707709258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0354992839_3262672472_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0354992839_3262672472", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0354992839_3262672472.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3619447294_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3619447294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3619447294.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_0343038313_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_0343038313", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_0343038313.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_3601044586_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_3601044586", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_3601044586.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3969032862_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3969032862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3969032862.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_4226397917_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_4226397917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_4226397917.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_4171853072_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_4171853072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_4171853072.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_1671246352_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_1671246352", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_1671246352.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0473296187_1240664120_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0473296187_1240664120", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0473296187_1240664120.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_2729030502_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_2729030502", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_2729030502.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0195502421_2250527759_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0195502421_2250527759", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0195502421_2250527759.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_4106972678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_4106972678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_4106972678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_4231180395_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_4231180395", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_4231180395.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_0384164053_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_0384164053", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_0384164053.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4129444368_0133995799_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4129444368_0133995799", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4129444368_0133995799.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_2606742376_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_2606742376", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_2606742376.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_1692073783_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_1692073783", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_1692073783.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_4222628439_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_4222628439", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_4222628439.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_1196267022_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_1196267022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_1196267022.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_2077626675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_2077626675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_2077626675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1599048751_0443121680_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1599048751_0443121680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1599048751_0443121680.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_1771899898_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_1771899898", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_1771899898.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3475865810_2916889659_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3475865810_2916889659", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3475865810_2916889659.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2410918564_1149270050_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2410918564_1149270050", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2410918564_1149270050.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1762900403_1675157433_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1762900403_1675157433", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1762900403_1675157433.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922224307_3978089942_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922224307_3978089942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922224307_3978089942.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3760201800_3937826361_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3760201800_3937826361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3760201800_3937826361.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0930310971_3620656492_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0930310971_3620656492", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0930310971_3620656492.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_0161625757_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_0161625757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_0161625757.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_2742948825_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_2742948825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_2742948825.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_3350833950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_3350833950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_3350833950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3985869124_1646726568_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3985869124_1646726568", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3985869124_1646726568.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2072776288_3677157186_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2072776288_3677157186", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2072776288_3677157186.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3098033077_3788854867_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3098033077_3788854867", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3098033077_3788854867.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2890412865_2442130452_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2890412865_2442130452", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2890412865_2442130452.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_1198203772_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_1198203772", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_1198203772.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_3963058827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_3963058827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_3963058827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0314937493_1235065380_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0314937493_1235065380", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0314937493_1235065380.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_3844114030_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_3844114030", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_3844114030.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922224307_0747507741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922224307_0747507741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922224307_0747507741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3773459662_2001098616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3773459662_2001098616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3773459662_2001098616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2890412865_0103509717_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2890412865_0103509717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2890412865_0103509717.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_4112293316_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_4112293316", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_4112293316.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2935285163_3918672160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2935285163_3918672160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2935285163_3918672160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2935285163_3443937987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2935285163_3443937987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2935285163_3443937987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3985869124_3686655021_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3985869124_3686655021", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3985869124_3686655021.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3985869124_1109286661_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3985869124_1109286661", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3985869124_1109286661.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3985869124_2142074007_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3985869124_2142074007", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3985869124_2142074007.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0247863225_3079592435_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0247863225_3079592435", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0247863225_3079592435.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2935285163_2386212854_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2935285163_2386212854", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2935285163_2386212854.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0824351388_1347007413_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0824351388_1347007413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0824351388_1347007413.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3182956085_2459330973_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3182956085_2459330973", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3182956085_2459330973.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2286054170_1183154814_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2286054170_1183154814", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2286054170_1183154814.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2039777822_2861937571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2039777822_2861937571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2039777822_2861937571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_0720321322_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_0720321322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_0720321322.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0821277161_2452845382_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0821277161_2452845382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0821277161_2452845382.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1145179157_0985731365_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1145179157_0985731365", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1145179157_0985731365.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2482520447_2357934258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2482520447_2357934258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2482520447_2357934258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0354992839_4270985640_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0354992839_4270985640", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0354992839_4270985640.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_0450819834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_0450819834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_0450819834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_1539796132_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_1539796132", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_1539796132.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_2599648353_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_2599648353", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_2599648353.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_4090833218_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_4090833218", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_4090833218.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_4019653536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_4019653536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_4019653536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_3099475556_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_3099475556", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_3099475556.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922224307_2594028800_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922224307_2594028800", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922224307_2594028800.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0199533715_2626815019_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0199533715_2626815019", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0199533715_2626815019.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_0788169535_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_0788169535", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_0788169535.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_3067371156_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_3067371156", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_3067371156.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_2433139910_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_2433139910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_2433139910.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3256702861_3372738015_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3256702861_3372738015", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3256702861_3372738015.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3256702861_0589001227_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3256702861_0589001227", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3256702861_0589001227.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0317303085_2266237930_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0317303085_2266237930", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0317303085_2266237930.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_2119016234_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_2119016234", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_2119016234.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_1939991412_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_1939991412", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_1939991412.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_3533556880_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_3533556880", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_3533556880.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_0655434565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_0655434565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_0655434565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0147049628_3382816651_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0147049628_3382816651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0147049628_3382816651.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3499568526_0387588484_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3499568526_0387588484", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3499568526_0387588484.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4140156548_2730799931_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4140156548_2730799931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4140156548_2730799931.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3807256730_1096735068_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3807256730_1096735068", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3807256730_1096735068.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2441073904_0370636159_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2441073904_0370636159", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2441073904_0370636159.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0163571437_2440949773_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0163571437_2440949773", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0163571437_2440949773.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4175523013_0849860572_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4175523013_0849860572", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4175523013_0849860572.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1327345084_4012969561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1327345084_4012969561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1327345084_4012969561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2678088137_0426518830_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2678088137_0426518830", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2678088137_0426518830.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3807256730_2073934028_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3807256730_2073934028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3807256730_2073934028.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1619349386_1775690561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1619349386_1775690561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1619349386_1775690561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2441073904_0767165798_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2441073904_0767165798", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2441073904_0767165798.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1540480822_0947784384_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1540480822_0947784384", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1540480822_0947784384.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0127618220_0130763087_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0127618220_0130763087", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0127618220_0130763087.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1899266048_3841402577_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1899266048_3841402577", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1899266048_3841402577.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4152787363_2820501031_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4152787363_2820501031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4152787363_2820501031.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3486127174_2509917185_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3486127174_2509917185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3486127174_2509917185.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2877905067_1053495238_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2877905067_1053495238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2877905067_1053495238.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2813670738_3951831549_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2813670738_3951831549", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2813670738_3951831549.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0156791417_2476327169_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0156791417_2476327169", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0156791417_2476327169.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2691224916_1532342302_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2691224916_1532342302", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2691224916_1532342302.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2813670738_0629787697_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2813670738_0629787697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2813670738_0629787697.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2246879312_1191928965_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2246879312_1191928965", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2246879312_1191928965.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0156791417_2300853397_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0156791417_2300853397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0156791417_2300853397.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0640091355_2194225365_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0640091355_2194225365", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0640091355_2194225365.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2377645808_1829458923_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2377645808_1829458923", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2377645808_1829458923.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2813670738_2057835039_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2813670738_2057835039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2813670738_2057835039.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_0182644048_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_0182644048", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_0182644048.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0005908294_3769082778_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0005908294_3769082778", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0005908294_3769082778.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0640091355_2429630212_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0640091355_2429630212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0640091355_2429630212.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2081581984_3004499080_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2081581984_3004499080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2081581984_3004499080.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0260284362_3891182424_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0260284362_3891182424", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0260284362_3891182424.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0833270390_3026737747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0833270390_3026737747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0833270390_3026737747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0104062982_2624711803_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0104062982_2624711803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0104062982_2624711803.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0127618220_1969215038_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0127618220_1969215038", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0127618220_1969215038.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1856103883_1611257301_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1856103883_1611257301", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1856103883_1611257301.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2814032954_1622134828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2814032954_1622134828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2814032954_1622134828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_1320849312_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_1320849312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_1320849312.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2796763367_1317951203_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2796763367_1317951203", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2796763367_1317951203.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0403581287_0838980133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0403581287_0838980133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0403581287_0838980133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2796763367_3818048004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2796763367_3818048004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2796763367_3818048004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1128090537_1421632392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1128090537_1421632392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1128090537_1421632392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2125608614_0880774931_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2125608614_0880774931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2125608614_0880774931.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2521145442_1805755238_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2521145442_1805755238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2521145442_1805755238.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0191395795_3236694536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0191395795_3236694536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0191395795_3236694536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3388370273_2297679703_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3388370273_2297679703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3388370273_2297679703.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_3145599158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_3145599158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_3145599158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0108713357_4241305880_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0108713357_4241305880", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0108713357_4241305880.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_4244061630_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_4244061630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_4244061630.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3035046424_4292096971_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3035046424_4292096971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3035046424_4292096971.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0005908294_3447751024_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0005908294_3447751024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0005908294_3447751024.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2691224916_2872019995_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2691224916_2872019995", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2691224916_2872019995.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2796763367_1006011430_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2796763367_1006011430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2796763367_1006011430.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4171426051_3814577731_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4171426051_3814577731", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4171426051_3814577731.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1592073254_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1592073254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1592073254.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1202617950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1202617950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1202617950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_1613704970_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_1613704970", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_1613704970.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_3841422764_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_3841422764", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_3841422764.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_2220311142_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_2220311142", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_2220311142.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2638461193_1573591642_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2638461193_1573591642", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2638461193_1573591642.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0915164424_1325445144_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0915164424_1325445144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0915164424_1325445144.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_3865075107_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_3865075107", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_3865075107.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3872789993_2925552542_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3872789993_2925552542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3872789993_2925552542.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0104062982_1282135726_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0104062982_1282135726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0104062982_1282135726.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3373101593_2825944131_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3373101593_2825944131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3373101593_2825944131.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1165806166_2025666600_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1165806166_2025666600", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1165806166_2025666600.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_1256819347_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_1256819347", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_1256819347.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0915164424_2094708517_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0915164424_2094708517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0915164424_2094708517.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0430716288_2483766177_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0430716288_2483766177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0430716288_2483766177.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1619349386_4151960239_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1619349386_4151960239", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1619349386_4151960239.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1299390507_4241404256_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1299390507_4241404256", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1299390507_4241404256.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1485839121_0368848417_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1485839121_0368848417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1485839121_0368848417.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2335382889_2893948990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2335382889_2893948990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2335382889_2893948990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1673825197_2886016245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1673825197_2886016245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1673825197_2886016245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0137154662_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0137154662", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0137154662.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2002370083_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2002370083", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2002370083.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1625205611_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1625205611", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1625205611.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_3020228506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_3020228506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_3020228506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_1966151519_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_1966151519", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_1966151519.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2877905067_3129761741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2877905067_3129761741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2877905067_3129761741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_1999324444_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_1999324444", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_1999324444.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_1711633372_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_1711633372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_1711633372.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2743926817_0940359250_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2743926817_0940359250", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2743926817_0940359250.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_4059578090_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_4059578090", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_4059578090.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2187015320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2187015320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2187015320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0483197804_1053507691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0483197804_1053507691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0483197804_1053507691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2608840750_2479844994_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2608840750_2479844994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2608840750_2479844994.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0173542633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0173542633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0173542633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2958426793_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2958426793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2958426793.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0740614442_0141173485_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0740614442_0141173485", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0740614442_0141173485.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3715766804_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3715766804", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3715766804.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_2276593171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_2276593171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_2276593171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_3703618294_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_3703618294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_3703618294.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2013746418_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2013746418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2013746418.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3042955088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3042955088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3042955088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2770927247_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2770927247", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2770927247.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0249522246_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0249522246", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0249522246.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_0154346994_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_0154346994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_0154346994.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1873025361_4135170509_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1873025361_4135170509", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1873025361_4135170509.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0191395795_4280824512_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0191395795_4280824512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0191395795_4280824512.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1755159788_2986963300_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1755159788_2986963300", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1755159788_2986963300.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0833270390_0290486934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0833270390_0290486934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0833270390_0290486934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2081581984_1136411392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2081581984_1136411392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2081581984_1136411392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0260284362_1349762835_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0260284362_1349762835", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0260284362_1349762835.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0232316340_1562964490_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0232316340_1562964490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0232316340_1562964490.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0668603926_0653334543_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0668603926_0653334543", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0668603926_0653334543.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1926094489_1822267460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1926094489_1822267460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1926094489_1822267460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2081581984_3496229166_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2081581984_3496229166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2081581984_3496229166.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2813670738_4114492805_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2813670738_4114492805", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2813670738_4114492805.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2081581984_1106828453_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2081581984_1106828453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2081581984_1106828453.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1673825197_0980968157_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1673825197_0980968157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1673825197_0980968157.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0640091355_1537880429_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0640091355_1537880429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0640091355_1537880429.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2125608614_4099405546_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2125608614_4099405546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2125608614_4099405546.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4014497853_2953807395_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4014497853_2953807395", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4014497853_2953807395.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3731081264_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3731081264", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3731081264.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0361781369_0419592700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0361781369_0419592700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0361781369_0419592700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1619349386_1460583516_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1619349386_1460583516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1619349386_1460583516.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3807256730_2414691380_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3807256730_2414691380", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3807256730_2414691380.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1926094489_2273874694_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1926094489_2273874694", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1926094489_2273874694.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1926094489_2229458242_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1926094489_2229458242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1926094489_2229458242.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0709125896_3024108228_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0709125896_3024108228", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0709125896_3024108228.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_1292294149_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_1292294149", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_1292294149.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2253812495_0535937500_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2253812495_0535937500", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2253812495_0535937500.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1540480822_2046334170_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1540480822_2046334170", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1540480822_2046334170.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2441073904_4173815894_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2441073904_4173815894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2441073904_4173815894.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1994596033_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1994596033", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1994596033.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_0109996254_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_0109996254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_0109996254.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3675828571_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3675828571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3675828571.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3482774339_0346401460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3482774339_0346401460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3482774339_0346401460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0232316340_3507053816_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0232316340_3507053816", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0232316340_3507053816.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3029850912_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3029850912", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3029850912.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2370737840_2278627212_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2370737840_2278627212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2370737840_2278627212.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0218244216_4264293018_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0218244216_4264293018", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0218244216_4264293018.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0462790100_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0462790100", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0462790100.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3144696329_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3144696329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3144696329.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2246879312_0334551893_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2246879312_0334551893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2246879312_0334551893.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0913789552_1101138080_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0913789552_1101138080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0913789552_1101138080.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3556319550_3916973561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3556319550_3916973561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3556319550_3916973561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2516016741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2516016741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2516016741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0869609516_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0869609516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0869609516.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3248418296_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3248418296", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3248418296.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3170016673_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3170016673", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3170016673.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1723414189_4217880970_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1723414189_4217880970", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1723414189_4217880970.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2789746591_4084991922_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2789746591_4084991922", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2789746591_4084991922.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_3192784444_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_3192784444", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_3192784444.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_2330627295_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_2330627295", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_2330627295.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2295430934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2295430934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2295430934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0501012084_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0501012084", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0501012084.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_4219987471_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_4219987471", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_4219987471.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_3569905049_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_3569905049", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_3569905049.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_0808389208_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_0808389208", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_0808389208.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0593005861_0252384533_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0593005861_0252384533", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0593005861_0252384533.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_3355400597_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_3355400597", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_3355400597.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1287388431_0062120766_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1287388431_0062120766", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1287388431_0062120766.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1166046932_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1166046932", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1166046932.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3585739235_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3585739235", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3585739235.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2560349469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2560349469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2560349469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_3896440361_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_3896440361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_3896440361.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3878356772_1802899967_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3878356772_1802899967", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3878356772_1802899967.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3152204062_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3152204062", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3152204062.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0277317972_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0277317972", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0277317972.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1972090786_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1972090786", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1972090786.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4009400913_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4009400913", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4009400913.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1015798525_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1015798525", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1015798525.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_0650814952_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_0650814952", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_0650814952.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2060027411_0066392501_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2060027411_0066392501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2060027411_0066392501.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3797812569_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3797812569", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3797812569.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_2379333589_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_2379333589", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_2379333589.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_0446038371_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_0446038371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_0446038371.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0471286396_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0471286396", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0471286396.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0814374702_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0814374702", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0814374702.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2435085447_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2435085447", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2435085447.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1774489456_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1774489456", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1774489456.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0908295334_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0908295334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0908295334.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_2464419320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_2464419320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_2464419320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_2865719206_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_2865719206", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_2865719206.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0567713443_3775749744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0567713443_3775749744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0567713443_3775749744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3842049520_2226420417_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3842049520_2226420417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3842049520_2226420417.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3248471403_3291284342_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3248471403_3291284342", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3248471403_3291284342.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3597147309_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3597147309", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3597147309.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2828008752_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2828008752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2828008752.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3175641838_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3175641838", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3175641838.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_3361635738_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_3361635738", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_3361635738.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_3053711581_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_3053711581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_3053711581.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_3573774875_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_3573774875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_3573774875.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3976000076_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3976000076", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3976000076.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0773516055_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0773516055", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0773516055.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2520448996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2520448996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2520448996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1287388431_1799522065_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1287388431_1799522065", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1287388431_1799522065.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_1100369593_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_1100369593", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_1100369593.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_0895515271_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_0895515271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_0895515271.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_1854111897_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_1854111897", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_1854111897.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_3112795024_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_3112795024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_3112795024.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_1685159844_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_1685159844", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_1685159844.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3829181974_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3829181974", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3829181974.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0091509418_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0091509418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0091509418.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1306964013_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1306964013", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1306964013.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0564423150_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0564423150", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0564423150.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3396127940_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3396127940", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3396127940.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2556712046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2556712046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2556712046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_3494915146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_3494915146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_3494915146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_2223041583_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_2223041583", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_2223041583.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2050307419_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2050307419", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2050307419.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1247012425_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1247012425", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1247012425.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2230189643_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2230189643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2230189643.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1633960996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1633960996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1633960996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1310672268_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1310672268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1310672268.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3331048639_2099668678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3331048639_2099668678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3331048639_2099668678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1437709696_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1437709696", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1437709696.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_2293686320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_2293686320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_2293686320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3490363362_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3490363362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3490363362.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2131975226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2131975226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2131975226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1665749900_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1665749900", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1665749900.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1308214828_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1308214828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1308214828.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1066551156_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1066551156", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1066551156.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2328848331_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2328848331", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2328848331.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0062911027_2042477501_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0062911027_2042477501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0062911027_2042477501.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_1942158338_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_1942158338", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_1942158338.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2516406211_0231142863_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_0231142863", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_0231142863.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_3365255920_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_3365255920", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_3365255920.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1460282971_2489308146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1460282971_2489308146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1460282971_2489308146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2927994113_0475115767_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2927994113_0475115767", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2927994113_0475115767.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_0015951207_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_0015951207", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_0015951207.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1882064473_3842554733_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1882064473_3842554733", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1882064473_3842554733.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3880102520_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3880102520", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3880102520.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2295917942_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2295917942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2295917942.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_4012812463_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_4012812463", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_4012812463.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0138461406_1723847457_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0138461406_1723847457", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0138461406_1723847457.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_2514448735_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_2514448735", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_2514448735.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0028856136_4115950173_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0028856136_4115950173", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0028856136_4115950173.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_0626112979_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_0626112979", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_0626112979.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_4198402360_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_4198402360", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_4198402360.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_3917744991_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_3917744991", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_3917744991.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0201245992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0201245992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0201245992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2856459754_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2856459754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2856459754.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2350560391_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2350560391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2350560391.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_2333643785_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_2333643785", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_2333643785.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_4098412358_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_4098412358", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_4098412358.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3924383382_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3924383382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3924383382.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2972153624_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2972153624", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2972153624.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1956499542_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1956499542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1956499542.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_0041662691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_0041662691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_0041662691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_2630353113_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_2630353113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_2630353113.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4057153887_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4057153887", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4057153887.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0414964460_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0414964460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0414964460.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0363178667_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0363178667", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0363178667.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3093550431_0535738333_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3093550431_0535738333", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3093550431_0535738333.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_3814562286_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_3814562286", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_3814562286.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1951074814_1804937560_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1951074814_1804937560", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1951074814_1804937560.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2565418530_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2565418530", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2565418530.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4129444368_3567647863_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4129444368_3567647863", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4129444368_3567647863.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1533625736_3202320905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1533625736_3202320905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1533625736_3202320905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_0208802171_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_0208802171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_0208802171.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_1099573146_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_1099573146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_1099573146.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_1746107570_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_1746107570", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_1746107570.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_1428175285_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_1428175285", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_1428175285.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2825913906_2923083675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2825913906_2923083675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2825913906_2923083675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3990294124_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3990294124", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3990294124.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3081168447_0966713725_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3081168447_0966713725", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3081168447_0966713725.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2602864547_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2602864547", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2602864547.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4062100810_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4062100810", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4062100810.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3147016793_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3147016793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3147016793.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2249492607_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2249492607", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2249492607.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_0105275489_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_0105275489", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_0105275489.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2029997293_2617284412_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2029997293_2617284412", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2029997293_2617284412.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4269486158_0453575992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4269486158_0453575992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4269486158_0453575992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0553573782_2508726320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0553573782_2508726320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0553573782_2508726320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_2484369933_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_2484369933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_2484369933.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1372703720_1891036341_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1372703720_1891036341", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1372703720_1891036341.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3047181859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3047181859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3047181859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2304084981_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2304084981", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2304084981.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2369825978_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2369825978", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2369825978.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2074589827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2074589827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2074589827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4164477221_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4164477221", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4164477221.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1520280686_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1520280686", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1520280686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3629906135_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3629906135", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3629906135.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0269900021_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0269900021", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0269900021.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0324460204_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0324460204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0324460204.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3227001476_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3227001476", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3227001476.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2535905180_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2535905180", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2535905180.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_0808694668_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_0808694668", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_0808694668.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3886565843_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3886565843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3886565843.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_0144024478_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_0144024478", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_0144024478.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1231164059_0725140993_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1231164059_0725140993", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1231164059_0725140993.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0621378690_2586103544_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0621378690_2586103544", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0621378690_2586103544.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3530895519_3638725423_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3530895519_3638725423", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3530895519_3638725423.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_2355076064_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_2355076064", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_2355076064.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3013530444_0352543605_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3013530444_0352543605", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3013530444_0352543605.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_3757168818_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_3757168818", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_3757168818.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1511050267_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1511050267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1511050267.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1731306601_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1731306601", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1731306601.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0074960413_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0074960413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0074960413.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1995828202_3100432226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1995828202_3100432226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1995828202_3100432226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0930310971_0675099307_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0930310971_0675099307", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0930310971_0675099307.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_2197892261_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_2197892261", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_2197892261.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1860329485_0364515469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1860329485_0364515469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1860329485_0364515469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_0660066766_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_0660066766", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_0660066766.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_1906131944_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_1906131944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_1906131944.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1091001814_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1091001814", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1091001814.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_2168581031_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_2168581031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_2168581031.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_4103269004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_4103269004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_4103269004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1411430944_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1411430944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1411430944.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0273709705_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0273709705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0273709705.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1422086768_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1422086768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1422086768.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3875398205_2739557824_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3875398205_2739557824", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3875398205_2739557824.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0235566329_1128777536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0235566329_1128777536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0235566329_1128777536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0895411269_0025283898_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0895411269_0025283898", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0895411269_0025283898.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4196286441_0023879996_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4196286441_0023879996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4196286441_0023879996.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0034956626_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0034956626", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0034956626.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4121684782_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4121684782", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4121684782.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3482774339_1607331101_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3482774339_1607331101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3482774339_1607331101.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3852101591_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3852101591", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3852101591.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2174163173_0513560621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2174163173_0513560621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2174163173_0513560621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1659937761_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1659937761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1659937761.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1729791560_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1729791560", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1729791560.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4227145008_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4227145008", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4227145008.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2587474290_3444866998_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2587474290_3444866998", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2587474290_3444866998.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4002235209_0281191987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4002235209_0281191987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4002235209_0281191987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0967473043_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0967473043", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0967473043.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2253812495_1838768038_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2253812495_1838768038", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2253812495_1838768038.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3124270881_2931281367_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3124270881_2931281367", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3124270881_2931281367.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2964712185_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2964712185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2964712185.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2921684672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2921684672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2921684672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1395622046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1395622046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1395622046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2228840613_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2228840613", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2228840613.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1990911424_1260454329_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1990911424_1260454329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1990911424_1260454329.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1357909716_3211164260_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1357909716_3211164260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1357909716_3211164260.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1864139759_2004009366_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1864139759_2004009366", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1864139759_2004009366.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0303707576_1166014375_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0303707576_1166014375", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0303707576_1166014375.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_0977178710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_0977178710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_0977178710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3027058188_2745810320_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3027058188_2745810320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3027058188_2745810320.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0568696350_3062749726_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0568696350_3062749726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0568696350_3062749726.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0056125095_0683848664_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0056125095_0683848664", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0056125095_0683848664.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_2713868467_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_2713868467", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_2713868467.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3068184698_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3068184698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3068184698.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3256702861_2864553113_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3256702861_2864553113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3256702861_2864553113.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_1098229481_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_1098229481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_1098229481.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4177099582_1796932507_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4177099582_1796932507", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4177099582_1796932507.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0542701626_1941145413_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0542701626_1941145413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0542701626_1941145413.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1908721506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1908721506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1908721506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_3405635499_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_3405635499", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_3405635499.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0185928614_1314502407_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0185928614_1314502407", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0185928614_1314502407.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0303707576_0772080204_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0303707576_0772080204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0303707576_0772080204.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0572469672_4270697358_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0572469672_4270697358", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0572469672_4270697358.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0303707576_4202199987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0303707576_4202199987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0303707576_4202199987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2883710544_2777779575_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2883710544_2777779575", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2883710544_2777779575.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_2326585614_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_2326585614", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_2326585614.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0646969166_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0646969166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0646969166.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2548894758_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2548894758", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2548894758.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_2092415377_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_2092415377", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_2092415377.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1478672267_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1478672267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1478672267.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1159575906_3084965045_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1159575906_3084965045", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1159575906_3084965045.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_1557622710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_1557622710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_1557622710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1457069283_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1457069283", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1457069283.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_2300899506_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_2300899506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_2300899506.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_2657854184_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_2657854184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_2657854184.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1215878916_1505860579_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1215878916_1505860579", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1215878916_1505860579.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0798997602_3793534284_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0798997602_3793534284", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0798997602_3793534284.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1438863039_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1438863039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1438863039.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0218244216_3590126440_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0218244216_3590126440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0218244216_3590126440.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2391963544_1667378233_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2391963544_1667378233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2391963544_1667378233.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0092506900_0855822792_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0092506900_0855822792", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0092506900_0855822792.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0593148379_4134947379_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0593148379_4134947379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0593148379_4134947379.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_0138186094_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_0138186094", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_0138186094.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_2853502404_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_2853502404", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_2853502404.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1383570267_1695354101_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1383570267_1695354101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1383570267_1695354101.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1849968033_1212786906_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1849968033_1212786906", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1849968033_1212786906.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4102164246_1291404729_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4102164246_1291404729", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4102164246_1291404729.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2118724062_2371869371_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2118724062_2371869371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2118724062_2371869371.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0633550356_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0633550356", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0633550356.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0296250634_3157854047_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0296250634_3157854047", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0296250634_3157854047.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0474876625_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0474876625", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0474876625.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1583903827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1583903827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1583903827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_2243181466_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_2243181466", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_2243181466.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1159575906_3050481445_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1159575906_3050481445", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1159575906_3050481445.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0742104041_4086063599_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0742104041_4086063599", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0742104041_4086063599.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_4151947730_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_4151947730", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_4151947730.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2516406211_1774869141_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2516406211_1774869141", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2516406211_1774869141.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3851932110_0204183025_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3851932110_0204183025", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3851932110_0204183025.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0303707576_3881289888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0303707576_3881289888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0303707576_3881289888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0798997602_0829540680_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0798997602_0829540680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0798997602_0829540680.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0606292111_0949904104_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0606292111_0949904104", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0606292111_0949904104.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_1033958954_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_1033958954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_1033958954.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_0820445927_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_0820445927", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_0820445927.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_3025961744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_3025961744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_3025961744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3756876134_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3756876134", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3756876134.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2410918564_2355058990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2410918564_2355058990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2410918564_2355058990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4118582672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4118582672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4118582672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3116212947_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3116212947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3116212947.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_2566248539_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_2566248539", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_2566248539.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3213167982_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3213167982", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3213167982.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_1438699207_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_1438699207", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_1438699207.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1127742436_1090837934_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1127742436_1090837934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1127742436_1090837934.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1959866565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1959866565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1959866565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1383570267_1866038767_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1383570267_1866038767", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1383570267_1866038767.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_3051797672_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_3051797672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_3051797672.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3475865810_1274372133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3475865810_1274372133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3475865810_1274372133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1629967213_1512363926_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1629967213_1512363926", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1629967213_1512363926.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1875258475_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1875258475", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1875258475.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1392206487_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1392206487", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1392206487.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2037756674_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2037756674", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2037756674.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0483197804_0911345633_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0483197804_0911345633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0483197804_0911345633.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3845374108_2903034621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3845374108_2903034621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3845374108_2903034621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2827578994_3070009689_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2827578994_3070009689", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2827578994_3070009689.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3880304289_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3880304289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3880304289.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1849968033_2085353271_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1849968033_2085353271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1849968033_2085353271.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_0679198752_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_0679198752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_0679198752.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1963767155_0231074541_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1963767155_0231074541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1963767155_0231074541.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2588531868_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2588531868", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2588531868.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2750429466_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2750429466", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2750429466.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0797467855_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0797467855", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0797467855.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3749952727_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3749952727", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3749952727.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2342021935_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2342021935", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2342021935.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1278366244_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1278366244", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1278366244.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1726389132_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1726389132", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1726389132.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2917805990_0781655361_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2917805990_0781655361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2917805990_0781655361.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1516381469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1516381469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1516381469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3116485048_0356880894_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3116485048_0356880894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3116485048_0356880894.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_0924901393_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_0924901393", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_0924901393.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_3937810836_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_3937810836", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_3937810836.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1401521511_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1401521511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1401521511.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3847976551_3159092825_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3847976551_3159092825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3847976551_3159092825.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0111405470_2280979608_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0111405470_2280979608", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0111405470_2280979608.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3628573419_2546286540_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3628573419_2546286540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3628573419_2546286540.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1629967213_3300909004_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1629967213_3300909004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1629967213_3300909004.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1463433355_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1463433355", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1463433355.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3776775032_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3776775032", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3776775032.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2877905067_2191996307_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2877905067_2191996307", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2877905067_2191996307.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4058598905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4058598905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4058598905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3851932110_4282770026_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3851932110_4282770026", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3851932110_4282770026.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2877905067_1824737179_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2877905067_1824737179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2877905067_1824737179.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0232707698_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0232707698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0232707698.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_0833728939_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_0833728939", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_0833728939.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0451805320_3178228103_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0451805320_3178228103", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0451805320_3178228103.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3358834441_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3358834441", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3358834441.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_0892993037_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_0892993037", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_0892993037.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1990911424_0602207096_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1990911424_0602207096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1990911424_0602207096.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0303707576_1587016992_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0303707576_1587016992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0303707576_1587016992.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1649017628_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1649017628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1649017628.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_2051689230_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_2051689230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_2051689230.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_0528998862_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_0528998862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_0528998862.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3746051088_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3746051088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3746051088.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3248471403_1298913368_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3248471403_1298913368", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3248471403_1298913368.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_0709520988_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_0709520988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_0709520988.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_1140685677_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_1140685677", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_1140685677.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_2473972399_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_2473972399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_2473972399.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1629967213_1173523947_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1629967213_1173523947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1629967213_1173523947.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4022058862_0188042735_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4022058862_0188042735", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4022058862_0188042735.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2252138728_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2252138728", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2252138728.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0206050100_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0206050100", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0206050100.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2682686406_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2682686406", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2682686406.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1395717791_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1395717791", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1395717791.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3386070196_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3386070196", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3386070196.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2410918564_2007383888_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2410918564_2007383888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2410918564_2007383888.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2965481593_0108181794_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2965481593_0108181794", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2965481593_0108181794.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2755070747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2755070747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2755070747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2877905067_3823763151_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2877905067_3823763151", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2877905067_3823763151.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2624163076_0644999616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2624163076_0644999616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2624163076_0644999616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2932160232_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2932160232", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2932160232.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0798997602_2914138493_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0798997602_2914138493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0798997602_2914138493.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_0146653961_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_0146653961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_0146653961.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_1776697137_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_1776697137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_1776697137.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2129103041_3736314486_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2129103041_3736314486", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2129103041_3736314486.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1934880621_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1934880621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1934880621.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0048164245_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0048164245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0048164245.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_1758879956_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_1758879956", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_1758879956.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3819993669_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3819993669", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3819993669.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2050064325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2050064325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2050064325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2189951160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2189951160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2189951160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3472133399_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3472133399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3472133399.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3086608405_0511473576_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3086608405_0511473576", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3086608405_0511473576.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_3737687741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_3737687741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_3737687741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0798997602_1883958718_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0798997602_1883958718", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0798997602_1883958718.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2558959287_2102657699_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2558959287_2102657699", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2558959287_2102657699.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_1057182747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_1057182747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_1057182747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2558959287_3958840630_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2558959287_3958840630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2558959287_3958840630.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3286937133_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3286937133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3286937133.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2002008905_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2002008905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2002008905.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_2618864769_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_2618864769", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_2618864769.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_0105929246_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_0105929246", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_0105929246.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_3224958158_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_3224958158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_3224958158.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_4031089392_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_4031089392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_4031089392.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3842049520_2515735803_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3842049520_2515735803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3842049520_2515735803.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1180466501_0093958401_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1180466501_0093958401", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1180466501_0093958401.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4210666365_1336257219_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4210666365_1336257219", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4210666365_1336257219.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0572469672_2541703958_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0572469672_2541703958", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0572469672_2541703958.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_0022438771_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_0022438771", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_0022438771.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2423286184_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2423286184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2423286184.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2286054170_2438938700_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2286054170_2438938700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2286054170_2438938700.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_0015516561_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_0015516561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_0015516561.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1849968033_3758269841_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1849968033_3758269841", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1849968033_3758269841.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2292861917_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2292861917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2292861917.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_4145332070_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_4145332070", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_4145332070.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_0713189091_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_0713189091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_0713189091.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0852929691_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0852929691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0852929691.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2028056633_0524785965_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2028056633_0524785965", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2028056633_0524785965.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4049484563_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4049484563", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4049484563.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1467766106_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1467766106", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1467766106.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1481421517_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1481421517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1481421517.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1645466859_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1645466859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1645466859.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3966863360_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3966863360", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3966863360.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1495442244_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1495442244", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1495442244.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3851932110_1988348043_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3851932110_1988348043", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3851932110_1988348043.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2558959287_1759071197_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2558959287_1759071197", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2558959287_1759071197.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3842049520_0445084272_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3842049520_0445084272", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3842049520_0445084272.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_2785404881_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_2785404881", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_2785404881.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3128954271_4278242573_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3128954271_4278242573", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3128954271_4278242573.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_3771301419_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_3771301419", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_3771301419.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3211486369_0741827557_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3211486369_0741827557", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3211486369_0741827557.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_4142624119_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_4142624119", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_4142624119.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0104062982_4067411469_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0104062982_4067411469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0104062982_4067411469.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_2136107710_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_2136107710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_2136107710.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2890412865_1447760046_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2890412865_1447760046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2890412865_1447760046.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2081516703_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2081516703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2081516703.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1360912695_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1360912695", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1360912695.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2991650286_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2991650286", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2991650286.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_3195637744_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_3195637744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_3195637744.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_0005595294_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_0005595294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_0005595294.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0935998548_4083964602_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0935998548_4083964602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0935998548_4083964602.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2060027411_1535267322_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2060027411_1535267322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2060027411_1535267322.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1978049990_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1978049990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1978049990.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2028056633_2423201705_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2028056633_2423201705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2028056633_2423201705.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3248471403_2380621462_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3248471403_2380621462", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3248471403_2380621462.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2769016646_0156250756_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2769016646_0156250756", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2769016646_0156250756.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1922224307_3242888292_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1922224307_3242888292", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1922224307_3242888292.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3838990781_3251071346_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3838990781_3251071346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3838990781_3251071346.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1795754291_2431878981_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1795754291_2431878981", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1795754291_2431878981.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1231164059_1945549339_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1231164059_1945549339", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1231164059_1945549339.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3530895519_2254397636_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3530895519_2254397636", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3530895519_2254397636.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_3280466916_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_3280466916", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_3280466916.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0016983257_3389087018_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0016983257_3389087018", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0016983257_3389087018.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2012179891_0632142040_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2012179891_0632142040", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2012179891_0632142040.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4275901922_2480080801_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4275901922_2480080801", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4275901922_2480080801.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1192883510_1445317919_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1192883510_1445317919", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1192883510_1445317919.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2501910747_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2501910747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2501910747.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3720591643_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3720591643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3720591643.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4052908338_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4052908338", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4052908338.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0621378690_2601737211_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0621378690_2601737211", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0621378690_2601737211.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3215113909_0932811753_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3215113909_0932811753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3215113909_0932811753.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0597938587_0574810702_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0597938587_0574810702", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0597938587_0574810702.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0824351388_0504441441_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0824351388_0504441441", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0824351388_0504441441.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0290453918_3340709229_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0290453918_3340709229", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0290453918_3340709229.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1414644071_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1414644071", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1414644071.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0050941226_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0050941226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0050941226.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0354992839_1718880411_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0354992839_1718880411", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0354992839_1718880411.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0392889902_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0392889902", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0392889902.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2256392325_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2256392325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2256392325.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0897849717_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0897849717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0897849717.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0258328740_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0258328740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0258328740.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_2707709258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_2707709258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_2707709258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0951474267_0343038313_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0951474267_0343038313", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0951474267_0343038313.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3601044586_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3601044586", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3601044586.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2077626675_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2077626675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2077626675.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2959576533_0443121680_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2959576533_0443121680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2959576533_0443121680.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1771899898_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1771899898", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1771899898.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_3969032862_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_3969032862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_3969032862.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_4226397917_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_4226397917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_4226397917.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_4171853072_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_4171853072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_4171853072.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_1671246352_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_1671246352", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_1671246352.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2533178076_1240664120_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2533178076_1240664120", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2533178076_1240664120.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3946533733_2729030502_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3946533733_2729030502", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3946533733_2729030502.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0905772714_2250527759_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0905772714_2250527759", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0905772714_2250527759.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_4106972678_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_4106972678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_4106972678.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0266113504_0384164053_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0266113504_0384164053", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0266113504_0384164053.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_0133995799_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_0133995799", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_0133995799.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2606742376_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2606742376", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2606742376.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_1692073783_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_1692073783", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_1692073783.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_4222628439_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_4222628439", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_4222628439.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1849968033_0161625757_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1849968033_0161625757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1849968033_0161625757.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2742948825_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2742948825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2742948825.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2858992010_3350833950_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2858992010_3350833950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2858992010_3350833950.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_1646726568_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_1646726568", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_1646726568.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_3844114030_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_3844114030", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_3844114030.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3090996085_0747507741_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3090996085_0747507741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3090996085_0747507741.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2001098616_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2001098616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2001098616.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0103509717_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0103509717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0103509717.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1001794884_2916889659_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1001794884_2916889659", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1001794884_2916889659.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0188790209_1149270050_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0188790209_1149270050", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0188790209_1149270050.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3115218374_1675157433_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3115218374_1675157433", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3115218374_1675157433.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_3978089942_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_3978089942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_3978089942.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2965481593_3620656492_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2965481593_3620656492", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2965481593_3620656492.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3851932110_3677157186_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3851932110_3677157186", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3851932110_3677157186.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0622179496_3788854867_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0622179496_3788854867", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0622179496_3788854867.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1530284962_1198203772_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1530284962_1198203772", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1530284962_1198203772.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2727839352_3963058827_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2727839352_3963058827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2727839352_3963058827.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0451801511_3079592435_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0451801511_3079592435", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0451801511_3079592435.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2370737840_2459330973_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2370737840_2459330973", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2370737840_2459330973.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3925127709_0720321322_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3925127709_0720321322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3925127709_0720321322.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3931166288_4112293316_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3931166288_4112293316", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3931166288_4112293316.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_3918672160_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_3918672160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_3918672160.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4198576579_3443937987_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4198576579_3443937987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4198576579_3443937987.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_3686655021_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_3686655021", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_3686655021.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_4022058862_1109286661_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_4022058862_1109286661", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_4022058862_1109286661.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1738780916_2142074007_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1738780916_2142074007", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1738780916_2142074007.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_0211723496_2452845382_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_0211723496_2452845382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_0211723496_2452845382.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_2433139910_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_2433139910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_2433139910.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2785780313_2266237930_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2785780313_2266237930", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2785780313_2266237930.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1383570267_2357934258_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1383570267_2357934258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1383570267_2357934258.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_4270985640_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_4270985640", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_4270985640.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_0450819834_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_0450819834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_0450819834.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_1830502036_4019653536_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_1830502036_4019653536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_1830502036_4019653536.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0788169535_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0788169535", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0788169535.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2204650441_3067371156_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2204650441_3067371156", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2204650441_3067371156.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3640797848_3099475556_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3640797848_3099475556", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3640797848_3099475556.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3809686103_2626815019_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3809686103_2626815019", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3809686103_2626815019.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_2119016234_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_2119016234", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_2119016234.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3575827597_1939991412_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3575827597_1939991412", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3575827597_1939991412.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_2610451642_0655434565_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_2610451642_0655434565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_2610451642_0655434565.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3674629836_0387588484_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3674629836_0387588484", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3674629836_0387588484.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}

extern void simprims_ver_m_05548409876658398341_3356579494_2141347742_init()
{
	static char *pe[] = {(void *)Gate_38_0,(void *)Gate_39_1,(void *)Gate_40_2,(void *)Gate_41_3,(void *)Gate_43_4,(void *)Cont_45_5,(void *)Always_47_6};
	static char *se[] = {(void *)sp_lut4_mux4};
	xsi_register_didat("simprims_ver_m_05548409876658398341_3356579494_2141347742", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_05548409876658398341_3356579494_2141347742.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
