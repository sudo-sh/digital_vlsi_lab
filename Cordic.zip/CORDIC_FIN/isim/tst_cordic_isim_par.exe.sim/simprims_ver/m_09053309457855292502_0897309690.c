/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_09053309457855292502_0897309690_2827745283_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2827745283", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2827745283.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3382816651_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3382816651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3382816651.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2112952440_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2112952440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2112952440.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2529600379_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2529600379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2529600379.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0150795661_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0150795661", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0150795661.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2691154429_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2691154429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2691154429.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1765083921_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1765083921", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1765083921.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1899742619_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1899742619", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1899742619.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0849860572_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0849860572", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0849860572.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4012969561_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4012969561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4012969561.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2500386582_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2500386582", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2500386582.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2449280811_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2449280811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2449280811.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3798436231_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3798436231", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3798436231.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1360078270_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1360078270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1360078270.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2137549041_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2137549041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2137549041.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1181364733_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1181364733", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1181364733.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1703853813_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1703853813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1703853813.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0387588484_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0387588484", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0387588484.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2730799931_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2730799931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2730799931.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1096735068_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1096735068", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1096735068.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0370636159_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0370636159", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0370636159.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2440949773_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2440949773", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2440949773.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0426518830_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0426518830", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0426518830.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2073934028_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2073934028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2073934028.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0837243269_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0837243269", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0837243269.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1775690561_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1775690561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1775690561.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0767165798_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0767165798", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0767165798.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0947784384_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0947784384", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0947784384.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1273563398_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1273563398", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1273563398.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2425356672_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2425356672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2425356672.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2929504866_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2929504866", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2929504866.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4191493697_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4191493697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4191493697.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1880306848_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1880306848", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1880306848.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2306717727_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2306717727", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2306717727.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2048727649_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2048727649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2048727649.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4183158670_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4183158670", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4183158670.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2096268495_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2096268495", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2096268495.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2142372502_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2142372502", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2142372502.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1158483096_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1158483096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1158483096.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2310431653_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2310431653", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2310431653.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0143114566_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0143114566", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0143114566.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0221899750_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0221899750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0221899750.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0130763087_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0130763087", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0130763087.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0553806871_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0553806871", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0553806871.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1332925565_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1332925565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1332925565.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3215814137_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3215814137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3215814137.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3413326160_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3413326160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3413326160.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0832676622_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0832676622", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0832676622.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3462791888_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3462791888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3462791888.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3841402577_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3841402577", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3841402577.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0900114740_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0900114740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0900114740.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3318577041_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3318577041", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3318577041.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1641887708_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1641887708", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1641887708.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0615600750_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0615600750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0615600750.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2437184723_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2437184723", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2437184723.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0635224991_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0635224991", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0635224991.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1572495645_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1572495645", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1572495645.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2509917185_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2509917185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2509917185.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1053495238_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1053495238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1053495238.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0729658610_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0729658610", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0729658610.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3951831549_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3951831549", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3951831549.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2476327169_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2476327169", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2476327169.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2904569136_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2904569136", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2904569136.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1119607428_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1119607428", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1119607428.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1894737983_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1894737983", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1894737983.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2749056687_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2749056687", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2749056687.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0629787697_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0629787697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0629787697.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0804855688_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0804855688", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0804855688.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3301876875_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3301876875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3301876875.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0702420675_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0702420675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0702420675.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3323756029_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3323756029", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3323756029.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1408986209_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1408986209", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1408986209.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3400821201_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3400821201", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3400821201.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0508563980_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0508563980", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0508563980.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1158866371_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1158866371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1158866371.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0737110088_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0737110088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0737110088.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1105671678_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1105671678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1105671678.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1824720950_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1824720950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1824720950.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4070854346_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4070854346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4070854346.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2204103546_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2204103546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2204103546.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2820501031_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2820501031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2820501031.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0497921331_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0497921331", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0497921331.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2558803014_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2558803014", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2558803014.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0431741683_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0431741683", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0431741683.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1532342302_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1532342302", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1532342302.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2120671391_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2120671391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2120671391.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3338721510_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3338721510", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3338721510.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0765911334_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0765911334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0765911334.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0838132493_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0838132493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0838132493.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3261368856_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3261368856", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3261368856.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2857480034_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2857480034", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2857480034.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1842546268_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1842546268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1842546268.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2141347742_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2141347742", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2141347742.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0996644681_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0996644681", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0996644681.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3892912753_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3892912753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3892912753.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2829666370_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2829666370", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2829666370.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2248598606_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2248598606", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2248598606.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4188940938_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4188940938", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4188940938.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3181317200_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3181317200", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3181317200.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1697179617_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1697179617", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1697179617.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1969215038_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1969215038", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1969215038.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0517644966_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0517644966", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0517644966.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3246496761_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3246496761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3246496761.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1276718481_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1276718481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1276718481.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3664036362_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3664036362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3664036362.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0018306551_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0018306551", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0018306551.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2338562242_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2338562242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2338562242.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2412494571_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2412494571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2412494571.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3318560828_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3318560828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3318560828.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1191928965_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1191928965", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1191928965.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1122131470_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1122131470", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1122131470.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0157924954_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0157924954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0157924954.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2670527233_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2670527233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2670527233.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2300853397_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2300853397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2300853397.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2194225365_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2194225365", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2194225365.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0507139540_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0507139540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0507139540.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1494627754_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1494627754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1494627754.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1622134828_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1622134828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1622134828.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3471538332_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3471538332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3471538332.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2060104744_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2060104744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2060104744.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1320849312_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1320849312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1320849312.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1317951203_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1317951203", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1317951203.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1070128348_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1070128348", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1070128348.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4013978910_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4013978910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4013978910.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0776204487_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0776204487", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0776204487.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2343769242_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2343769242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2343769242.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1237814511_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1237814511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1237814511.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1671295198_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1671295198", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1671295198.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2623766602_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2623766602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2623766602.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2253501729_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2253501729", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2253501729.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3059381335_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3059381335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3059381335.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1611257301_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1611257301", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1611257301.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0705647362_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0705647362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0705647362.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2831749051_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2831749051", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2831749051.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3276569379_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3276569379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3276569379.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3874574028_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3874574028", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3874574028.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3118966305_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3118966305", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3118966305.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3978069675_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3978069675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3978069675.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1943723967_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1943723967", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1943723967.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0376193460_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0376193460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0376193460.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1771298335_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1771298335", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1771298335.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2129185372_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2129185372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2129185372.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0838980133_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0838980133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0838980133.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4154034823_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4154034823", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4154034823.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1805051533_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1805051533", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1805051533.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3495113576_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3495113576", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3495113576.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0962723668_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0962723668", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0962723668.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2054408144_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2054408144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2054408144.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1934651157_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1934651157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1934651157.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3144645541_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3144645541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3144645541.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1131378464_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1131378464", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1131378464.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3236694536_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3236694536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3236694536.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2453800961_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2453800961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2453800961.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1339347332_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1339347332", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1339347332.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3818048004_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3818048004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3818048004.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1421632392_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1421632392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1421632392.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0880774931_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0880774931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0880774931.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1805755238_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1805755238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1805755238.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3447751024_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3447751024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3447751024.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2872019995_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2872019995", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2872019995.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1006011430_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1006011430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1006011430.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3205195776_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3205195776", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3205195776.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3814577731_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3814577731", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3814577731.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1743062843_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1743062843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1743062843.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2284284933_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2284284933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2284284933.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3721362834_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3721362834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3721362834.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2427061199_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2427061199", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2427061199.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2151787260_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2151787260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2151787260.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4072192179_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4072192179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4072192179.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1574400889_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1574400889", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1574400889.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0211795325_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0211795325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0211795325.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3173694241_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3173694241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3173694241.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0228975289_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0228975289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0228975289.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2297679703_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2297679703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2297679703.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3145599158_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3145599158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3145599158.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4241305880_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4241305880", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4241305880.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4244061630_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4244061630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4244061630.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4292096971_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4292096971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4292096971.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1325445144_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1325445144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1325445144.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3865075107_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3865075107", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3865075107.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2925552542_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2925552542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2925552542.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1282135726_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1282135726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1282135726.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2825944131_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2825944131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2825944131.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3375592241_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3375592241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3375592241.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3099488713_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3099488713", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3099488713.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1648079996_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1648079996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1648079996.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1372160171_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1372160171", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1372160171.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0097329490_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0097329490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0097329490.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0339179022_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0339179022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0339179022.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0570738738_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0570738738", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0570738738.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0037651901_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0037651901", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0037651901.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3053469448_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3053469448", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3053469448.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2715627186_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2715627186", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2715627186.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0402197091_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0402197091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0402197091.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2025666600_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2025666600", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2025666600.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1256819347_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1256819347", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1256819347.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3159073268_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3159073268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3159073268.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3436779829_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3436779829", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3436779829.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0559442149_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0559442149", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0559442149.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1401539274_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1401539274", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1401539274.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2265677291_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2265677291", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2265677291.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1490992768_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1490992768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1490992768.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1573591642_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1573591642", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1573591642.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1679794709_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1679794709", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1679794709.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2346567979_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2346567979", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2346567979.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1160147757_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1160147757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1160147757.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2867075091_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2867075091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2867075091.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3573508063_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3573508063", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3573508063.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3870020964_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3870020964", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3870020964.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1735691022_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1735691022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1735691022.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2855495341_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2855495341", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2855495341.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0780724058_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0780724058", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0780724058.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0484201953_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0484201953", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0484201953.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2094708517_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2094708517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2094708517.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2483766177_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2483766177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2483766177.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0742758618_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0742758618", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0742758618.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4151960239_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4151960239", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4151960239.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0494588813_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0494588813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0494588813.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0882894651_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0882894651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0882894651.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2574991008_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2574991008", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2574991008.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0632203258_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0632203258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0632203258.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4164641117_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4164641117", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4164641117.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1223490988_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1223490988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1223490988.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0414943633_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0414943633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0414943633.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2695937859_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2695937859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2695937859.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1349453511_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1349453511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1349453511.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2220133811_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2220133811", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2220133811.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2475269129_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2475269129", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2475269129.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0319609438_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0319609438", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0319609438.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4241404256_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4241404256", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4241404256.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0368848417_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0368848417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0368848417.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2893948990_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2893948990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2893948990.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2886016245_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2886016245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2886016245.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2429630212_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2429630212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2429630212.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3004499080_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3004499080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3004499080.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3891182424_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3891182424", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3891182424.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3026737747_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3026737747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3026737747.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2624711803_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2624711803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2624711803.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4135170509_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4135170509", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4135170509.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4280824512_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4280824512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4280824512.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2986963300_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2986963300", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2986963300.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3879640755_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3879640755", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3879640755.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0290486934_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0290486934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0290486934.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1136411392_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1136411392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1136411392.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3496229166_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3496229166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3496229166.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4114492805_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4114492805", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4114492805.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1106828453_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1106828453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1106828453.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0980968157_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0980968157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0980968157.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1537880429_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1537880429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1537880429.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1349762835_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1349762835", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1349762835.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1562964490_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1562964490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1562964490.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0653334543_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0653334543", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0653334543.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1822267460_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1822267460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1822267460.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1829458923_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1829458923", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1829458923.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2057835039_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2057835039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2057835039.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1853873158_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1853873158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1853873158.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1774173115_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1774173115", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1774173115.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0182644048_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0182644048", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0182644048.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3769082778_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3769082778", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3769082778.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4099405546_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4099405546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4099405546.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2953807395_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2953807395", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2953807395.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1368157442_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1368157442", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1368157442.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1313201700_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1313201700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1313201700.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3731081264_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3731081264", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3731081264.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1533131178_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1533131178", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1533131178.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1233298312_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1233298312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1233298312.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1748408230_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1748408230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1748408230.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2865794813_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2865794813", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2865794813.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2754306616_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2754306616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2754306616.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3452347148_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3452347148", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3452347148.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3065597168_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3065597168", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3065597168.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1173425555_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1173425555", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1173425555.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3733143362_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3733143362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3733143362.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4078845663_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4078845663", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4078845663.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0419592700_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0419592700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0419592700.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1460583516_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1460583516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1460583516.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2414691380_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2414691380", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2414691380.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2046334170_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2046334170", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2046334170.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0616773131_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0616773131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0616773131.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2469457905_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2469457905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2469457905.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4029471971_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4029471971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4029471971.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4173815894_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4173815894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4173815894.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2556941334_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2556941334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2556941334.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2526848905_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2526848905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2526848905.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0990512807_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0990512807", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0990512807.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1786138788_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1786138788", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1786138788.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4105198285_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4105198285", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4105198285.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3405864245_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3405864245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3405864245.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1319515764_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1319515764", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1319515764.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3613133270_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3613133270", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3613133270.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3791953649_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3791953649", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3791953649.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2176694072_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2176694072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2176694072.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0535937500_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0535937500", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0535937500.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4154049834_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4154049834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4154049834.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2987726919_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2987726919", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2987726919.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1156441893_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1156441893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1156441893.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2816810581_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2816810581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2816810581.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_0334551893_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_0334551893", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_0334551893.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3241715628_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3241715628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3241715628.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1998574578_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1998574578", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1998574578.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_4206954571_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_4206954571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_4206954571.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1210545515_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1210545515", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1210545515.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1101138080_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1101138080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1101138080.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_3916973561_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_3916973561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_3916973561.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2273874694_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2273874694", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2273874694.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2229458242_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2229458242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2229458242.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_1363436989_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_1363436989", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_1363436989.didat");
}

extern void simprims_ver_m_09053309457855292502_0897309690_2362620984_init()
{
	xsi_register_didat("simprims_ver_m_09053309457855292502_0897309690_2362620984", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_09053309457855292502_0897309690_2362620984.didat");
}
