/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_02253721222203995675_2662658903_1806524459_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1806524459", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1806524459.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3964253995_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3964253995", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3964253995.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3853542665_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3853542665", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3853542665.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0905704604_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0905704604", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0905704604.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0950965143_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0950965143", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0950965143.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1707380673_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1707380673", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1707380673.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2665060387_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2665060387", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2665060387.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3283321973_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3283321973", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3283321973.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2939257534_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2939257534", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2939257534.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1236486227_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1236486227", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1236486227.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0520399921_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0520399921", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0520399921.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0393731621_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0393731621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0393731621.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2132585986_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2132585986", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2132585986.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0155617546_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0155617546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0155617546.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1733899916_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1733899916", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1733899916.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3015093916_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3015093916", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3015093916.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3241033016_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3241033016", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3241033016.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0109991756_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0109991756", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0109991756.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2700696824_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2700696824", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2700696824.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1700684406_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1700684406", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1700684406.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0655713422_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0655713422", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0655713422.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3274271170_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3274271170", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3274271170.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0925206728_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0925206728", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0925206728.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_4072764255_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_4072764255", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_4072764255.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3993344612_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3993344612", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3993344612.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0736746847_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0736746847", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0736746847.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0436324290_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0436324290", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0436324290.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2375997163_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2375997163", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2375997163.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3998147537_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3998147537", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3998147537.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_4048191823_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_4048191823", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_4048191823.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1211754597_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1211754597", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1211754597.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1038123473_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1038123473", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1038123473.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1412207964_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1412207964", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1412207964.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3551440047_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3551440047", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3551440047.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0141933159_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0141933159", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0141933159.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2919412179_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2919412179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2919412179.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1806012253_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1806012253", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1806012253.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3453125865_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3453125865", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3453125865.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2149197282_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2149197282", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2149197282.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0644689494_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0644689494", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0644689494.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0427743712_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0427743712", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0427743712.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2363923507_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2363923507", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2363923507.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_0680969085_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_0680969085", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_0680969085.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2397161673_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2397161673", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2397161673.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_2170711866_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_2170711866", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_2170711866.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1999249363_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1999249363", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1999249363.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3512538215_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3512538215", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3512538215.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3769962234_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3769962234", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3769962234.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_3594770011_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_3594770011", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_3594770011.didat");
}

extern void simprims_ver_m_02253721222203995675_2662658903_1882512879_init()
{
	xsi_register_didat("simprims_ver_m_02253721222203995675_2662658903_1882512879", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_02253721222203995675_2662658903_1882512879.didat");
}
