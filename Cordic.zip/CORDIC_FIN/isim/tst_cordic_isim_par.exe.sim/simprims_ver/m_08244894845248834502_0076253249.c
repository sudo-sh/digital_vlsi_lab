/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static int ng0[] = {0, 0};
static int ng1[] = {1095521093, 0, 70, 0};
static unsigned int ng2[] = {1U, 1U};
static unsigned int ng3[] = {0U, 0U};
static int ng4[] = {1, 0};



static int TChk_111_24_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6072U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_112_25_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6072U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_113_26_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 5912U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_114_27_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 5912U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_115_28_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6872U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_116_29_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6872U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_117_30_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 7032U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_118_31_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 7032U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_120_32_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6232U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_121_33_tstmp(char *t1)
{
    char t4[8];
    int t0;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t2 = (t1 + 6392U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng0)));
    memset(t4, 0, 8);
    t5 = (t3 + 4);
    t6 = (t2 + 4);
    t7 = *((unsigned int *)t3);
    t8 = *((unsigned int *)t2);
    t9 = (t7 ^ t8);
    t10 = *((unsigned int *)t5);
    t11 = *((unsigned int *)t6);
    t12 = (t10 ^ t11);
    t13 = (t9 | t12);
    t14 = *((unsigned int *)t5);
    t15 = *((unsigned int *)t6);
    t16 = (t14 | t15);
    t17 = (~(t16));
    t18 = (t13 & t17);
    if (t18 != 0)
        goto LAB3;

LAB2:    if (t16 != 0)
        goto LAB4;

LAB5:    t20 = (t4 + 4);
    t21 = *((unsigned int *)t20);
    t22 = (~(t21));
    t23 = *((unsigned int *)t4);
    t24 = (t23 & t22);
    t25 = (t24 != 0);
    t0 = t25;

LAB1:    return t0;
LAB3:    *((unsigned int *)t4) = 1;
    goto LAB5;

LAB4:    t19 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB5;

}

static int TChk_124_35_tchk(char *t1)
{
    int t0;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;

LAB0:    t2 = (t1 + 1752U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t4 = *((unsigned int *)t2);
    t5 = (~(t4));
    t6 = *((unsigned int *)t3);
    t7 = (t6 & t5);
    t8 = (t7 != 0);
    t0 = t8;

LAB1:    return t0;
}

static int TChk_125_36_tchk(char *t1)
{
    int t0;
    char *t2;
    char *t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;

LAB0:    t2 = (t1 + 1752U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t4 = *((unsigned int *)t2);
    t5 = (~(t4));
    t6 = *((unsigned int *)t3);
    t7 = (t6 & t5);
    t8 = (t7 != 0);
    t0 = t8;

LAB1:    return t0;
}

static void NetDecl_43_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 9144U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 19632);
    t3 = *((char **)t2);
    t4 = ((((char*)(t3))) + 40U);
    t5 = *((char **)t4);
    t4 = (t0 + 15616);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t5 + 4);
    t13 = *((unsigned int *)t5);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t4, 0, 0U);
    t18 = (t0 + 15168);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Gate_58_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;

LAB0:    t1 = (t0 + 9392U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 7912);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 15680);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 4);
    t11 = (t4 + 4);
    if (*((unsigned int *)t11) == 1)
        goto LAB4;

LAB5:    t12 = *((unsigned int *)t4);
    t13 = (t12 & 1);
    *((unsigned int *)t9) = t13;
    t14 = *((unsigned int *)t11);
    t15 = (t14 & 1);
    *((unsigned int *)t10) = t15;

LAB6:    t16 = (t0 + 15680);
    xsi_driver_vfirst_trans(t16, 0, 0);
    t17 = (t0 + 15184);
    *((int *)t17) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t9) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB6;

}

static void Gate_60_2(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 9640U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2872U);
    t3 = *((char **)t2);
    t2 = (t0 + 15744);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 15744);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15200);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_61_3(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 9888U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3352U);
    t3 = *((char **)t2);
    t2 = (t0 + 15808);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 15808);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15216);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_62_4(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 10136U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3832U);
    t3 = *((char **)t2);
    t2 = (t0 + 15872);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 15872);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15232);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_63_5(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 10384U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3992U);
    t3 = *((char **)t2);
    t2 = (t0 + 15936);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 15936);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15248);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_64_6(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 10632U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3512U);
    t3 = *((char **)t2);
    t2 = (t0 + 16000);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 16000);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15264);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_65_7(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 10880U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3672U);
    t3 = *((char **)t2);
    t2 = (t0 + 16064);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 16064);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15280);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_66_8(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 11128U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 3352U);
    t3 = *((char **)t2);
    t2 = (t0 + 1592U);
    t4 = *((char **)t2);
    t2 = (t0 + 16128);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    xsi_vlog_XorGate(t8, 2, t3, t4);
    t9 = (t0 + 16128);
    xsi_driver_vfirst_trans(t9, 0, 0);
    t10 = (t0 + 15296);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Gate_68_9(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 11376U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 4472U);
    t4 = *((char **)t2);
    t2 = (t0 + 4632U);
    t5 = *((char **)t2);
    t2 = (t0 + 4792U);
    t6 = *((char **)t2);
    t2 = (t0 + 4952U);
    t7 = *((char **)t2);
    t2 = (t0 + 3032U);
    t8 = *((char **)t2);
    t2 = (t0 + 16192);
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    xsi_vlog_AndGate(t12, 6, t3, t4, t5, t6, t7, t8);
    t13 = (t0 + 16192);
    xsi_driver_vfirst_trans(t13, 0, 0);
    t14 = (t0 + 15312);
    *((int *)t14) = 1;

LAB1:    return;
}

static void Gate_69_10(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;

LAB0:    t1 = (t0 + 11624U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 4472U);
    t4 = *((char **)t2);
    t2 = (t0 + 4632U);
    t5 = *((char **)t2);
    t2 = (t0 + 4792U);
    t6 = *((char **)t2);
    t2 = (t0 + 4952U);
    t7 = *((char **)t2);
    t2 = (t0 + 5112U);
    t8 = *((char **)t2);
    t2 = (t0 + 16256);
    t9 = (t2 + 56U);
    t10 = *((char **)t9);
    t11 = (t10 + 56U);
    t12 = *((char **)t11);
    xsi_vlog_AndGate(t12, 6, t3, t4, t5, t6, t7, t8);
    t13 = (t0 + 16256);
    xsi_driver_vfirst_trans(t13, 0, 0);
    t14 = (t0 + 15328);
    *((int *)t14) = 1;

LAB1:    return;
}

static void Gate_70_11(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 11872U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 16320);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_AndGate(t7, 1, t3);
    t8 = (t0 + 16320);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 15344);
    *((int *)t9) = 1;

LAB1:    return;
}

static void Gate_71_12(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;

LAB0:    t1 = (t0 + 12120U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 4472U);
    t4 = *((char **)t2);
    t2 = (t0 + 16384);
    t5 = (t2 + 56U);
    t6 = *((char **)t5);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    xsi_vlog_AndGate(t8, 2, t3, t4);
    t9 = (t0 + 16384);
    xsi_driver_vfirst_trans(t9, 0, 0);
    t10 = (t0 + 15360);
    *((int *)t10) = 1;

LAB1:    return;
}

static void Gate_72_13(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;

LAB0:    t1 = (t0 + 12368U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 4472U);
    t4 = *((char **)t2);
    t2 = (t0 + 4632U);
    t5 = *((char **)t2);
    t2 = (t0 + 16448);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    xsi_vlog_AndGate(t9, 3, t3, t4, t5);
    t10 = (t0 + 16448);
    xsi_driver_vfirst_trans(t10, 0, 0);
    t11 = (t0 + 15376);
    *((int *)t11) = 1;

LAB1:    return;
}

static void Gate_73_14(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 12616U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 4152U);
    t3 = *((char **)t2);
    t2 = (t0 + 4472U);
    t4 = *((char **)t2);
    t2 = (t0 + 4632U);
    t5 = *((char **)t2);
    t2 = (t0 + 4792U);
    t6 = *((char **)t2);
    t2 = (t0 + 16512);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    xsi_vlog_AndGate(t10, 4, t3, t4, t5, t6);
    t11 = (t0 + 16512);
    xsi_driver_vfirst_trans(t11, 0, 0);
    t12 = (t0 + 15392);
    *((int *)t12) = 1;

LAB1:    return;
}

static void Cont_75_15(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    char *t29;
    char *t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    char *t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;

LAB0:    t1 = (t0 + 12864U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 744);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t25, 8);

LAB16:    t26 = (t0 + 16576);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    t29 = (t28 + 56U);
    t30 = *((char **)t29);
    memset(t30, 0, 8);
    t31 = 1U;
    t32 = t31;
    t33 = (t3 + 4);
    t34 = *((unsigned int *)t3);
    t31 = (t31 & t34);
    t35 = *((unsigned int *)t33);
    t32 = (t32 & t35);
    t36 = (t30 + 4);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t37 | t31);
    t38 = *((unsigned int *)t36);
    *((unsigned int *)t36) = (t38 | t32);
    xsi_driver_vfirst_trans(t26, 0, 0);
    t39 = (t0 + 15408);
    *((int *)t39) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng2)));
    goto LAB9;

LAB10:    t23 = (t0 + 7752);
    t24 = (t23 + 56U);
    t25 = *((char **)t24);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t25, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_76_16(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 13112U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16640);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15424);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 5432U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_77_17(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 13360U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16704);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15440);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 5272U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_78_18(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 13608U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16768);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15456);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 5592U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_79_19(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 13856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16832);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15472);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 5752U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_80_20(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 14104U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16896);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15488);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 6552U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Cont_81_21(char *t0)
{
    char t3[8];
    char t4[8];
    char t6[16];
    char *t1;
    char *t2;
    char *t5;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;

LAB0:    t1 = (t0 + 14352U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 880);
    t5 = *((char **)t2);
    t2 = ((char*)((ng1)));
    xsi_vlog_unsigned_equal(t6, 40, t5, 32, t2, 40);
    memset(t4, 0, 8);
    t7 = (t6 + 4);
    t8 = *((unsigned int *)t7);
    t9 = (~(t8));
    t10 = *((unsigned int *)t6);
    t11 = (t10 & t9);
    t12 = (t11 & 1U);
    if (t12 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t7) != 0)
        goto LAB6;

LAB7:    t14 = (t4 + 4);
    t15 = *((unsigned int *)t4);
    t16 = *((unsigned int *)t14);
    t17 = (t15 || t16);
    if (t17 > 0)
        goto LAB8;

LAB9:    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    t21 = *((unsigned int *)t14);
    t22 = (t20 || t21);
    if (t22 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t14) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t24, 8);

LAB16:    t23 = (t0 + 16960);
    t25 = (t23 + 56U);
    t26 = *((char **)t25);
    t27 = (t26 + 56U);
    t28 = *((char **)t27);
    memset(t28, 0, 8);
    t29 = 1U;
    t30 = t29;
    t31 = (t3 + 4);
    t32 = *((unsigned int *)t3);
    t29 = (t29 & t32);
    t33 = *((unsigned int *)t31);
    t30 = (t30 & t33);
    t34 = (t28 + 4);
    t35 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t35 | t29);
    t36 = *((unsigned int *)t34);
    *((unsigned int *)t34) = (t36 | t30);
    xsi_driver_vfirst_trans(t23, 0, 0);
    t37 = (t0 + 15504);
    *((int *)t37) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t13 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t13) = 1;
    goto LAB7;

LAB8:    t18 = ((char*)((ng3)));
    goto LAB9;

LAB10:    t23 = (t0 + 6712U);
    t24 = *((char **)t23);
    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 1, t18, 1, t24, 1);
    goto LAB16;

LAB14:    memcpy(t3, t18, 8);
    goto LAB16;

}

static void Always_83_22(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;

LAB0:    t1 = (t0 + 14600U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 15520);
    *((int *)t2) = 1;
    t3 = (t0 + 14632);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:
LAB5:    t4 = (t0 + 2872U);
    t5 = *((char **)t4);
    t4 = (t5 + 4);
    t6 = *((unsigned int *)t4);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 != 0);
    if (t10 > 0)
        goto LAB6;

LAB7:
LAB14:    t2 = (t0 + 3992U);
    t3 = *((char **)t2);
    t2 = (t0 + 8232);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);
    t2 = (t0 + 3832U);
    t3 = *((char **)t2);
    t2 = (t0 + 8072);
    xsi_vlogvar_assign_value(t2, t3, 0, 0, 1);

LAB8:    goto LAB2;

LAB6:    t11 = (t0 + 472);
    t12 = *((char **)t11);
    t11 = (t12 + 4);
    t13 = *((unsigned int *)t11);
    t14 = (~(t13));
    t15 = *((unsigned int *)t12);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB9;

LAB10:
LAB13:    t2 = ((char*)((ng4)));
    t3 = (t0 + 8072);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 8232);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB11:    goto LAB8;

LAB9:
LAB12:    t18 = ((char*)((ng4)));
    t19 = (t0 + 8232);
    xsi_vlogvar_assign_value(t19, t18, 0, 0, 1);
    t2 = ((char*)((ng0)));
    t3 = (t0 + 8072);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);
    goto LAB11;

}

static void Always_99_23(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;

LAB0:    t1 = (t0 + 14848U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 15536);
    *((int *)t2) = 1;
    t3 = (t0 + 14880);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    t4 = (t0 + 7192U);
    t5 = *((char **)t4);
    t4 = (t0 + 7912);
    xsi_vlogvar_assign_value(t4, t5, 0, 0, 1);
    goto LAB2;

}


extern void simprims_ver_m_08244894845248834502_0076253249_3382816651_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3382816651", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3382816651.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2691154429_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2691154429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2691154429.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2820501031_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2820501031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2820501031.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0497921331_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0497921331", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0497921331.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2509917185_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2509917185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2509917185.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1053495238_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1053495238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1053495238.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3951831549_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3951831549", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3951831549.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2476327169_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2476327169", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2476327169.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2558803014_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2558803014", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2558803014.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0431741683_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0431741683", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0431741683.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1532342302_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1532342302", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1532342302.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0629787697_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0629787697", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0629787697.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2300853397_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2300853397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2300853397.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2194225365_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2194225365", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2194225365.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1829458923_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1829458923", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1829458923.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2057835039_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2057835039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2057835039.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0182644048_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0182644048", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0182644048.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3769082778_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3769082778", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3769082778.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2429630212_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2429630212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2429630212.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3004499080_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3004499080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3004499080.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3891182424_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3891182424", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3891182424.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3026737747_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3026737747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3026737747.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2624711803_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2624711803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2624711803.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1622134828_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1622134828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1622134828.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1320849312_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1320849312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1320849312.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1317951203_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1317951203", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1317951203.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3818048004_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3818048004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3818048004.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1421632392_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1421632392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1421632392.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0880774931_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0880774931", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0880774931.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1805755238_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1805755238", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1805755238.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3236694536_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3236694536", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3236694536.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2297679703_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2297679703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2297679703.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3145599158_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3145599158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3145599158.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4241305880_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4241305880", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4241305880.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4244061630_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4244061630", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4244061630.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3447751024_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3447751024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3447751024.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2872019995_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2872019995", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2872019995.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1006011430_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1006011430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1006011430.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3205195776_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3205195776", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3205195776.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3814577731_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3814577731", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3814577731.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2556712046_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2556712046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2556712046.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1592073254_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1592073254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1592073254.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1202617950_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1202617950", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1202617950.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1573591642_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1573591642", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1573591642.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4292096971_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4292096971", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4292096971.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1325445144_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1325445144", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1325445144.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3865075107_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3865075107", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3865075107.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2925552542_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2925552542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2925552542.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1282135726_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1282135726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1282135726.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2025666600_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2025666600", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2025666600.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2825944131_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2825944131", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2825944131.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3375592241_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3375592241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3375592241.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2094708517_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2094708517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2094708517.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2483766177_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2483766177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2483766177.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4241404256_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4241404256", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4241404256.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0368848417_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0368848417", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0368848417.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2893948990_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2893948990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2893948990.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2886016245_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2886016245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2886016245.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0137154662_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0137154662", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0137154662.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2002370083_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2002370083", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2002370083.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1625205611_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1625205611", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1625205611.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3782195178_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3782195178", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3782195178.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3129761741_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3129761741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3129761741.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1999324444_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1999324444", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1999324444.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1711633372_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1711633372", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1711633372.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1166014375_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1166014375", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1166014375.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4059578090_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4059578090", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4059578090.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2187015320_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2187015320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2187015320.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1053507691_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1053507691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1053507691.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2479844994_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2479844994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2479844994.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2958426793_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2958426793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2958426793.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0141173485_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0141173485", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0141173485.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3715766804_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3715766804", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3715766804.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0173542633_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0173542633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0173542633.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2013746418_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2013746418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2013746418.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3042955088_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3042955088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3042955088.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2770927247_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2770927247", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2770927247.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0249522246_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0249522246", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0249522246.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4135170509_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4135170509", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4135170509.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4280824512_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4280824512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4280824512.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2986963300_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2986963300", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2986963300.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0290486934_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0290486934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0290486934.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1537880429_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1537880429", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1537880429.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1349762835_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1349762835", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1349762835.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1562964490_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1562964490", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1562964490.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0653334543_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0653334543", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0653334543.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1822267460_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1822267460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1822267460.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1136411392_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1136411392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1136411392.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3496229166_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3496229166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3496229166.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4114492805_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4114492805", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4114492805.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1106828453_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1106828453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1106828453.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0980968157_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0980968157", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0980968157.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4099405546_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4099405546", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4099405546.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2953807395_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2953807395", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2953807395.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3916973561_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3916973561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3916973561.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2273874694_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2273874694", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2273874694.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2229458242_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2229458242", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2229458242.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1994596033_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1994596033", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1994596033.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0109996254_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0109996254", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0109996254.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3675828571_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3675828571", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3675828571.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0346401460_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0346401460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0346401460.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3507053816_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3507053816", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3507053816.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1695354101_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1695354101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1695354101.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3029850912_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3029850912", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3029850912.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2278627212_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2278627212", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2278627212.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4264293018_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4264293018", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4264293018.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0462790100_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0462790100", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0462790100.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3144696329_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3144696329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3144696329.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1101138080_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1101138080", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1101138080.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0501012084_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0501012084", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0501012084.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2516016741_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2516016741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2516016741.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0869609516_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0869609516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0869609516.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3248418296_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3248418296", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3248418296.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3170016673_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3170016673", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3170016673.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2295430934_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2295430934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2295430934.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3355400597_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3355400597", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3355400597.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1166046932_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1166046932", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1166046932.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3585739235_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3585739235", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3585739235.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2560349469_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2560349469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2560349469.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3152204062_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3152204062", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3152204062.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0277317972_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0277317972", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0277317972.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1972090786_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1972090786", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1972090786.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4009400913_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4009400913", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4009400913.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0908295334_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0908295334", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0908295334.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0066392501_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0066392501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0066392501.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3797812569_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3797812569", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3797812569.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0446038371_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0446038371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0446038371.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0471286396_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0471286396", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0471286396.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0814374702_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0814374702", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0814374702.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2435085447_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2435085447", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2435085447.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1774489456_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1774489456", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1774489456.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3597147309_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3597147309", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3597147309.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2828008752_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2828008752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2828008752.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3175641838_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3175641838", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3175641838.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3053711581_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3053711581", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3053711581.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3573774875_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3573774875", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3573774875.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1015798525_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1015798525", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1015798525.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3976000076_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3976000076", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3976000076.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0773516055_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0773516055", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0773516055.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2520448996_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2520448996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2520448996.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0895515271_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0895515271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0895515271.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1854111897_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1854111897", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1854111897.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3829181974_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3829181974", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3829181974.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0091509418_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0091509418", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0091509418.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1306964013_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1306964013", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1306964013.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0564423150_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0564423150", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0564423150.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3396127940_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3396127940", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3396127940.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2050307419_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2050307419", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2050307419.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1247012425_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1247012425", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1247012425.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2230189643_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2230189643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2230189643.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1633960996_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1633960996", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1633960996.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1310672268_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1310672268", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1310672268.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1437709696_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1437709696", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1437709696.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2293686320_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2293686320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2293686320.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2131975226_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2131975226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2131975226.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1665749900_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1665749900", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1665749900.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1308214828_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1308214828", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1308214828.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3490363362_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3490363362", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3490363362.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3880102520_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3880102520", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3880102520.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2295917942_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2295917942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2295917942.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4012812463_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4012812463", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4012812463.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0201245992_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0201245992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0201245992.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2856459754_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2856459754", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2856459754.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2350560391_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2350560391", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2350560391.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3924383382_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3924383382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3924383382.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2972153624_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2972153624", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2972153624.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1956499542_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1956499542", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1956499542.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0041662691_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0041662691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0041662691.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2630353113_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2630353113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2630353113.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1066551156_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1066551156", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1066551156.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4057153887_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4057153887", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4057153887.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0414964460_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0414964460", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0414964460.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0363178667_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0363178667", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0363178667.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2565418530_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2565418530", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2565418530.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1099573146_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1099573146", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1099573146.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3990294124_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3990294124", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3990294124.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2602864547_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2602864547", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2602864547.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4062100810_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4062100810", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4062100810.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3147016793_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3147016793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3147016793.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0144024478_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0144024478", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0144024478.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0105275489_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0105275489", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0105275489.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2484369933_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2484369933", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2484369933.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3047181859_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3047181859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3047181859.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2304084981_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2304084981", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2304084981.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2369825978_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2369825978", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2369825978.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2074589827_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2074589827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2074589827.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2249492607_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2249492607", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2249492607.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1520280686_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1520280686", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1520280686.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3629906135_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3629906135", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3629906135.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0269900021_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0269900021", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0269900021.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0324460204_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0324460204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0324460204.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4164477221_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4164477221", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4164477221.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3227001476_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3227001476", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3227001476.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2535905180_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2535905180", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2535905180.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3886565843_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3886565843", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3886565843.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1511050267_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1511050267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1511050267.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1731306601_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1731306601", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1731306601.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0074960413_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0074960413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0074960413.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2197892261_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2197892261", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2197892261.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0364515469_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0364515469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0364515469.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1906131944_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1906131944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1906131944.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1091001814_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1091001814", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1091001814.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2168581031_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2168581031", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2168581031.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4103269004_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4103269004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4103269004.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1411430944_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1411430944", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1411430944.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0273709705_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0273709705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0273709705.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1422086768_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1422086768", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1422086768.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0034956626_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0034956626", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0034956626.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4121684782_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4121684782", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4121684782.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1607331101_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1607331101", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1607331101.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3852101591_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3852101591", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3852101591.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0513560621_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0513560621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0513560621.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1659937761_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1659937761", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1659937761.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1729791560_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1729791560", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1729791560.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4227145008_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4227145008", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4227145008.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3444866998_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3444866998", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3444866998.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0281191987_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0281191987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0281191987.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0967473043_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0967473043", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0967473043.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1838768038_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1838768038", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1838768038.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2931281367_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2931281367", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2931281367.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2964712185_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2964712185", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2964712185.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2921684672_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2921684672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2921684672.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1395622046_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1395622046", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1395622046.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2713868467_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2713868467", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2713868467.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2228840613_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2228840613", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2228840613.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1260454329_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1260454329", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1260454329.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3211164260_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3211164260", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3211164260.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2004009366_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2004009366", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2004009366.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0977178710_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0977178710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0977178710.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2745810320_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2745810320", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2745810320.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3062749726_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3062749726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3062749726.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0683848664_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0683848664", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0683848664.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3068184698_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3068184698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3068184698.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2864553113_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2864553113", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2864553113.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1098229481_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1098229481", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1098229481.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1796932507_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1796932507", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1796932507.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1941145413_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1941145413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1941145413.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1908721506_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1908721506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1908721506.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3405635499_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3405635499", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3405635499.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1314502407_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1314502407", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1314502407.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1726371755_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1726371755", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1726371755.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0772080204_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0772080204", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0772080204.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4270697358_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4270697358", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4270697358.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4202199987_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4202199987", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4202199987.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2777779575_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2777779575", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2777779575.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2326585614_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2326585614", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2326585614.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3544822211_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3544822211", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3544822211.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0646969166_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0646969166", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0646969166.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0855822792_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0855822792", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0855822792.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2548894758_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2548894758", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2548894758.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1287420135_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1287420135", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1287420135.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2092415377_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2092415377", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2092415377.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2569106943_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2569106943", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2569106943.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1478672267_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1478672267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1478672267.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3084965045_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3084965045", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3084965045.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1557622710_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1557622710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1557622710.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1457069283_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1457069283", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1457069283.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2300899506_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2300899506", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2300899506.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2657854184_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2657854184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2657854184.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1505860579_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1505860579", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1505860579.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3793534284_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3793534284", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3793534284.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1438863039_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1438863039", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1438863039.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3590126440_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3590126440", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3590126440.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1667378233_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1667378233", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1667378233.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4134947379_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4134947379", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4134947379.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0138186094_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0138186094", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0138186094.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2853502404_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2853502404", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2853502404.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1212786906_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1212786906", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1212786906.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1291404729_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1291404729", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1291404729.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2371869371_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2371869371", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2371869371.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0633550356_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0633550356", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0633550356.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3157854047_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3157854047", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3157854047.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1418096430_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1418096430", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1418096430.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0474876625_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0474876625", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0474876625.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1583903827_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1583903827", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1583903827.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2243181466_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2243181466", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2243181466.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3050481445_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3050481445", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3050481445.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4086063599_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4086063599", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4086063599.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4151947730_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4151947730", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4151947730.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1774869141_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1774869141", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1774869141.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0204183025_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0204183025", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0204183025.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3881289888_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3881289888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3881289888.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0829540680_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0829540680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0829540680.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0949904104_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0949904104", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0949904104.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2917723512_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2917723512", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2917723512.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1033958954_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1033958954", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1033958954.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0820445927_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0820445927", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0820445927.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3025961744_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3025961744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3025961744.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2620707109_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2620707109", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2620707109.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3756876134_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3756876134", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3756876134.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1026652703_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1026652703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1026652703.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2355058990_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2355058990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2355058990.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3051797672_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3051797672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3051797672.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4118582672_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4118582672", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4118582672.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3116212947_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3116212947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3116212947.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2566248539_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2566248539", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2566248539.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3213167982_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3213167982", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3213167982.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3070009689_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3070009689", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3070009689.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0231074541_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0231074541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0231074541.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1438699207_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1438699207", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1438699207.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1090837934_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1090837934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1090837934.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1959866565_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1959866565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1959866565.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1866038767_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1866038767", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1866038767.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1274372133_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1274372133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1274372133.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1512363926_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1512363926", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1512363926.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1875258475_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1875258475", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1875258475.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1278366244_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1278366244", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1278366244.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1392206487_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1392206487", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1392206487.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2037756674_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2037756674", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2037756674.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0911345633_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0911345633", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0911345633.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2903034621_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2903034621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2903034621.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3300909004_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3300909004", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3300909004.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3880304289_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3880304289", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3880304289.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2085353271_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2085353271", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2085353271.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0679198752_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0679198752", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0679198752.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2588531868_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2588531868", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2588531868.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2750429466_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2750429466", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2750429466.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0797467855_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0797467855", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0797467855.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3749952727_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3749952727", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3749952727.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2342021935_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2342021935", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2342021935.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1726389132_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1726389132", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1726389132.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0781655361_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0781655361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0781655361.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1516381469_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1516381469", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1516381469.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0356880894_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0356880894", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0356880894.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0924901393_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0924901393", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0924901393.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3937810836_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3937810836", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3937810836.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1401521511_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1401521511", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1401521511.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3159092825_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3159092825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3159092825.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2280979608_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2280979608", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2280979608.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2546286540_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2546286540", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2546286540.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1463433355_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1463433355", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1463433355.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3776775032_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3776775032", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3776775032.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2191996307_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2191996307", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2191996307.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0833728939_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0833728939", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0833728939.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4058598905_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4058598905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4058598905.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4282770026_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4282770026", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4282770026.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1824737179_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1824737179", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1824737179.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0232707698_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0232707698", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0232707698.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3178228103_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3178228103", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3178228103.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3358834441_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3358834441", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3358834441.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0892993037_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0892993037", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0892993037.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0602207096_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0602207096", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0602207096.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1587016992_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1587016992", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1587016992.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1649017628_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1649017628", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1649017628.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2051689230_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2051689230", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2051689230.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0528998862_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0528998862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0528998862.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3746051088_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3746051088", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3746051088.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1298913368_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1298913368", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1298913368.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2429212037_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2429212037", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2429212037.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0709520988_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0709520988", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0709520988.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1140685677_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1140685677", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1140685677.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2473972399_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2473972399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2473972399.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1173523947_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1173523947", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1173523947.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0188042735_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0188042735", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0188042735.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2252138728_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2252138728", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2252138728.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1779957878_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1779957878", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1779957878.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0206050100_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0206050100", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0206050100.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2682686406_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2682686406", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2682686406.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1835359917_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1835359917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1835359917.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1395717791_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1395717791", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1395717791.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3205766657_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3205766657", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3205766657.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1752196397_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1752196397", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1752196397.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3386070196_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3386070196", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3386070196.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2007383888_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2007383888", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2007383888.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0108181794_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0108181794", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0108181794.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2755070747_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2755070747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2755070747.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3823763151_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3823763151", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3823763151.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0644999616_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0644999616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0644999616.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2932160232_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2932160232", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2932160232.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2855331541_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2855331541", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2855331541.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2914138493_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2914138493", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2914138493.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0146653961_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0146653961", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0146653961.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1776697137_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1776697137", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1776697137.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3736314486_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3736314486", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3736314486.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0319773222_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0319773222", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0319773222.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1934880621_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1934880621", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1934880621.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0559671453_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0559671453", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0559671453.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0048164245_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0048164245", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0048164245.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1758879956_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1758879956", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1758879956.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3819993669_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3819993669", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3819993669.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2050064325_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2050064325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2050064325.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2189951160_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2189951160", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2189951160.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3472133399_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3472133399", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3472133399.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1978049990_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1978049990", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1978049990.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2292861917_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2292861917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2292861917.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2463051737_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2463051737", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2463051737.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3286937133_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3286937133", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3286937133.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2002008905_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2002008905", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2002008905.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2618864769_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2618864769", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2618864769.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3224958158_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3224958158", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3224958158.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4031089392_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4031089392", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4031089392.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2515735803_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2515735803", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2515735803.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0093958401_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0093958401", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0093958401.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0852929691_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0852929691", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0852929691.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1336257219_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1336257219", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1336257219.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2541703958_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2541703958", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2541703958.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2423286184_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2423286184", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2423286184.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2438938700_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2438938700", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2438938700.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0015516561_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0015516561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0015516561.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3758269841_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3758269841", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3758269841.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0105929246_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0105929246", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0105929246.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3365303589_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3365303589", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3365303589.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4145332070_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4145332070", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4145332070.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0713189091_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0713189091", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0713189091.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4049484563_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4049484563", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4049484563.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1467766106_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1467766106", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1467766106.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1481421517_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1481421517", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1481421517.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3966863360_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3966863360", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3966863360.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1495442244_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1495442244", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1495442244.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2991650286_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2991650286", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2991650286.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4142624119_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4142624119", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4142624119.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2081516703_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2081516703", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2081516703.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1360912695_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1360912695", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1360912695.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1645466859_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1645466859", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1645466859.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3195637744_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3195637744", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3195637744.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0005595294_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0005595294", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0005595294.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4083964602_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4083964602", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4083964602.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1535267322_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1535267322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1535267322.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1537063073_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1537063073", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1537063073.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2944616438_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2944616438", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2944616438.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3251071346_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3251071346", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3251071346.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2480080801_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2480080801", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2480080801.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2406333202_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2406333202", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2406333202.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2685844154_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2685844154", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2685844154.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2501910747_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2501910747", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2501910747.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3720591643_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3720591643", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3720591643.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0932811753_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0932811753", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0932811753.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3340709229_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3340709229", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3340709229.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4052908338_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4052908338", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4052908338.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1414644071_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1414644071", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1414644071.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0050941226_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0050941226", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0050941226.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2771116461_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2771116461", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2771116461.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0392889902_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0392889902", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0392889902.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2256392325_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2256392325", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2256392325.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0897849717_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0897849717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0897849717.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0258328740_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0258328740", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0258328740.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3601044586_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3601044586", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3601044586.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4222628439_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4222628439", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4222628439.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1196267022_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1196267022", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1196267022.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2077626675_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2077626675", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2077626675.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0443121680_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0443121680", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0443121680.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1771899898_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1771899898", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1771899898.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1877922726_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1877922726", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1877922726.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3969032862_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3969032862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3969032862.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4226397917_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4226397917", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4226397917.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4171853072_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4171853072", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4171853072.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1671246352_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1671246352", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1671246352.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1240664120_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1240664120", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1240664120.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4106972678_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4106972678", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4106972678.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2897026078_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2897026078", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2897026078.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2606742376_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2606742376", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2606742376.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1692073783_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1692073783", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1692073783.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3620656492_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3620656492", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3620656492.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0161625757_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0161625757", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0161625757.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2742948825_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2742948825", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2742948825.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3801451934_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3801451934", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3801451934.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1202545020_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1202545020", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1202545020.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0751362710_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0751362710", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0751362710.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3844114030_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3844114030", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3844114030.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2001098616_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2001098616", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2001098616.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2916889659_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2916889659", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2916889659.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1149270050_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1149270050", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1149270050.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3978089942_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3978089942", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3978089942.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1913979177_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1913979177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1913979177.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3932326143_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3932326143", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3932326143.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4160941443_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4160941443", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4160941443.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0103509717_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0103509717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0103509717.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0398493373_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0398493373", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0398493373.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3429063361_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3429063361", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3429063361.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0167260783_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0167260783", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0167260783.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0920407457_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0920407457", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0920407457.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0237201741_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0237201741", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0237201741.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0762203092_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0762203092", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0762203092.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1110826857_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1110826857", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1110826857.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0900402585_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0900402585", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0900402585.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2433139910_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2433139910", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2433139910.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2266237930_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2266237930", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2266237930.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2357934258_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2357934258", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2357934258.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4270985640_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4270985640", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4270985640.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0450819834_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0450819834", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0450819834.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0788169535_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0788169535", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0788169535.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_4138615312_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_4138615312", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_4138615312.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0582937413_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0582937413", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0582937413.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0117490056_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0117490056", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0117490056.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_3381231793_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_3381231793", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_3381231793.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0337598772_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0337598772", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0337598772.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2131279547_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2131279547", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2131279547.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_2119016234_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_2119016234", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_2119016234.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_1939991412_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_1939991412", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_1939991412.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}

extern void simprims_ver_m_08244894845248834502_0076253249_0655434565_init()
{
	static char *pe[] = {(void *)NetDecl_43_0,(void *)Gate_58_1,(void *)Gate_60_2,(void *)Gate_61_3,(void *)Gate_62_4,(void *)Gate_63_5,(void *)Gate_64_6,(void *)Gate_65_7,(void *)Gate_66_8,(void *)Gate_68_9,(void *)Gate_69_10,(void *)Gate_70_11,(void *)Gate_71_12,(void *)Gate_72_13,(void *)Gate_73_14,(void *)Cont_75_15,(void *)Cont_76_16,(void *)Cont_77_17,(void *)Cont_78_18,(void *)Cont_79_19,(void *)Cont_80_20,(void *)Cont_81_21,(void *)Always_83_22,(void *)Always_99_23};
	xsi_register_didat("simprims_ver_m_08244894845248834502_0076253249_0655434565", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_08244894845248834502_0076253249_0655434565.didat");
	xsi_register_executes(pe);
	xsi_register_timingcheckfuncs(0, (void *)TChk_111_24_tstmp, 0);
	xsi_register_timingcheckfuncs(1, (void *)TChk_112_25_tstmp, 0);
	xsi_register_timingcheckfuncs(2, (void *)TChk_113_26_tstmp, 0);
	xsi_register_timingcheckfuncs(3, (void *)TChk_114_27_tstmp, 0);
	xsi_register_timingcheckfuncs(4, (void *)TChk_115_28_tstmp, 0);
	xsi_register_timingcheckfuncs(5, (void *)TChk_116_29_tstmp, 0);
	xsi_register_timingcheckfuncs(6, (void *)TChk_117_30_tstmp, 0);
	xsi_register_timingcheckfuncs(7, (void *)TChk_118_31_tstmp, 0);
	xsi_register_timingcheckfuncs(8, (void *)TChk_120_32_tstmp, 0);
	xsi_register_timingcheckfuncs(9, (void *)TChk_121_33_tstmp, 0);
	xsi_register_timingcheckfuncs(11, 0, (void *)TChk_124_35_tchk);
	xsi_register_timingcheckfuncs(12, 0, (void *)TChk_125_36_tchk);
}
