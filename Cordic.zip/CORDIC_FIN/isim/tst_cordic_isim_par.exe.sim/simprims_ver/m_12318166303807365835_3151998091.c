/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_12318166303807365835_3151998091_3011633529_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3011633529", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3011633529.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0368503501_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0368503501", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0368503501.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4080284319_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4080284319", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4080284319.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2187983844_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2187983844", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2187983844.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0814376195_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0814376195", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0814376195.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2533191351_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2533191351", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2533191351.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2718753516_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2718753516", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2718753516.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2481256561_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2481256561", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2481256561.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0075229528_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0075229528", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0075229528.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1655851684_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1655851684", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1655851684.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1522499374_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1522499374", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1522499374.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1398427705_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1398427705", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1398427705.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0176161907_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0176161907", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0176161907.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2901872583_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2901872583", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2901872583.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2636059994_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2636059994", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2636059994.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0996679406_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0996679406", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0996679406.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1488464852_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1488464852", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1488464852.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1766863177_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1766863177", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1766863177.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3475454717_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3475454717", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3475454717.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3693809024_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3693809024", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3693809024.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3252475862_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3252475862", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3252475862.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1739316322_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1739316322", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1739316322.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_1447282431_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_1447282431", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_1447282431.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4029992267_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4029992267", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4029992267.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0023232414_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0023232414", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0023232414.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2803201066_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2803201066", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2803201066.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_2350151389_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_2350151389", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_2350151389.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0711163241_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0711163241", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0711163241.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_0462120948_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_0462120948", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_0462120948.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3187436608_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3187436608", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3187436608.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_3727448442_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_3727448442", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_3727448442.didat");
}

extern void simprims_ver_m_12318166303807365835_3151998091_4022617063_init()
{
	xsi_register_didat("simprims_ver_m_12318166303807365835_3151998091_4022617063", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_12318166303807365835_3151998091_4022617063.didat");
}
