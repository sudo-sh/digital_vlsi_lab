/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif



static void Gate_29_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 2496U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 1344U);
    t3 = *((char **)t2);
    t2 = (t0 + 2896);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    xsi_vlog_notGate(t7, t3);
    t8 = (t0 + 2896);
    xsi_driver_vfirst_trans(t8, 0, 0);
    t9 = (t0 + 2816);
    *((int *)t9) = 1;

LAB1:    return;
}


extern void simprims_ver_m_00358400182994406296_2534611871_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_2534611871", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_2534611871.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_0730872118_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_0730872118", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_0730872118.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_0047987635_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_0047987635", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_0047987635.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_2229960073_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_2229960073", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_2229960073.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_2571991461_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_2571991461", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_2571991461.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_4041989382_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_4041989382", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_4041989382.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_3823219778_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_3823219778", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_3823219778.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_3440623192_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_3440623192", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_3440623192.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_1374145750_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_1374145750", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_1374145750.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_0036832662_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_0036832662", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_0036832662.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_2996329840_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_2996329840", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_2996329840.didat");
	xsi_register_executes(pe);
}

extern void simprims_ver_m_00358400182994406296_1725965915_init()
{
	static char *pe[] = {(void *)Gate_29_0};
	xsi_register_didat("simprims_ver_m_00358400182994406296_1725965915", "isim/tst_cordic_isim_par.exe.sim/simprims_ver/m_00358400182994406296_1725965915.didat");
	xsi_register_executes(pe);
}
