/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_3247168877_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3247168877", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3247168877.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3313372496_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3313372496", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3313372496.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4186466186_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4186466186", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4186466186.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0592954900_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0592954900", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0592954900.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1472450284_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1472450284", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1472450284.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3087115730_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3087115730", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3087115730.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1225457247_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1225457247", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1225457247.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2721924444_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2721924444", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2721924444.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2798163297_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2798163297", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2798163297.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2938320155_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2938320155", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2938320155.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1308569186_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1308569186", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1308569186.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1887945370_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1887945370", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1887945370.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2033575530_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2033575530", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2033575530.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2882987302_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2882987302", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2882987302.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2672142756_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2672142756", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2672142756.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2532805972_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2532805972", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2532805972.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1850667561_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1850667561", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1850667561.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1953632935_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1953632935", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1953632935.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2173475095_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2173475095", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2173475095.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2612033945_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2612033945", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2612033945.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1142197784_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1142197784", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1142197784.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2037146336_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2037146336", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2037146336.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1088511525_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1088511525", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1088511525.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2527988190_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2527988190", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2527988190.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2107224797_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2107224797", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2107224797.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2455493091_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2455493091", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2455493091.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0716990062_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0716990062", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0716990062.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2362142170_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2362142170", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2362142170.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0776582739_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0776582739", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0776582739.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1793238686_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1793238686", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1793238686.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2233519520_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2233519520", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2233519520.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3432361258_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3432361258", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3432361258.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1085856431_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1085856431", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1085856431.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2944053649_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2944053649", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2944053649.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1584523804_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1584523804", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1584523804.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2981331234_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2981331234", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2981331234.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1518615073_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1518615073", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1518615073.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3041284383_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3041284383", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3041284383.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1469729382_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1469729382", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1469729382.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3092783448_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3092783448", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3092783448.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1399822939_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1399822939", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1399822939.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3165516133_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3165516133", "isim/test_scan_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3165516133.didat");
}
