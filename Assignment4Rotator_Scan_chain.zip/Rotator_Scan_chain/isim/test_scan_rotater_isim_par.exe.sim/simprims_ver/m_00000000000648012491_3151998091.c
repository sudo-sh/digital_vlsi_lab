/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_3872379163_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3872379163", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3872379163.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0151894565_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0151894565", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0151894565.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4161200552_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4161200552", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4161200552.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0398756502_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0398756502", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0398756502.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4243796373_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4243796373", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4243796373.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0322001579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0322001579", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0322001579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4058857938_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4058857938", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4058857938.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0506407660_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0506407660", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0506407660.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4112028143_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4112028143", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4112028143.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3951568342_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3951568342", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3951568342.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1744623321_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1744623321", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1744623321.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0664933929_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0664933929", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0664933929.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1661535972_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1661535972", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1661535972.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2178227613_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2178227613", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2178227613.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1847031459_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1847031459", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1847031459.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3361766679_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3361766679", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3361766679.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2285813223_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2285813223", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2285813223.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0228716178_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0228716178", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0228716178.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0071978728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0071978728", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0071978728.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4055156056_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4055156056", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4055156056.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3359242653_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3359242653", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3359242653.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0511094374_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0511094374", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0511094374.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0670798499_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0670798499", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0670798499.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4018009579_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4018009579", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4018009579.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3606104366_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3606104366", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3606104366.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3745705438_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3745705438", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3745705438.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3798173100_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3798173100", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3798173100.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0959619600_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0959619600", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0959619600.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0813729504_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0813729504", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0813729504.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3868611985_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3868611985", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3868611985.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3523549459_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3523549459", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3523549459.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0156516015_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0156516015", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0156516015.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1036481069_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1036481069", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1036481069.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0450558673_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0450558673", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0450558673.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3743115604_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3743115604", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3743115604.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0012558037_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0012558037", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0012558037.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0819528298_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0819528298", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0819528298.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3689855337_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3689855337", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3689855337.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0875352663_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0875352663", "isim/test_scan_rotater_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0875352663.didat");
}
