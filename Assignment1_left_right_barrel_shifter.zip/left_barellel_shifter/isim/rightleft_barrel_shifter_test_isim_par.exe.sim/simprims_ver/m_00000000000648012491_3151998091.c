/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_2149197282_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2149197282", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2149197282.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2985443199_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2985443199", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2985443199.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0680969085_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0680969085", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0680969085.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3144158794_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3144158794", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3144158794.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3161902198_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3161902198", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3161902198.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0621949044_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0621949044", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0621949044.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1915980053_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1915980053", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1915980053.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3561259681_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3561259681", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3561259681.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1421244651_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1421244651", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1421244651.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4231700084_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4231700084", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4231700084.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2204449728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2204449728", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2204449728.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0436324290_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0436324290", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0436324290.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1806012253_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1806012253", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1806012253.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0394605771_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0394605771", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0394605771.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2700696824_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2700696824", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2700696824.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0351939305_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0351939305", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0351939305.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1170021228_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1170021228", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1170021228.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3274271170_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3274271170", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3274271170.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0300137519_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0300137519", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0300137519.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1187120462_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1187120462", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1187120462.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4072764255_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4072764255", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4072764255.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3853293628_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3853293628", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3853293628.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1262941767_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1262941767", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1262941767.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1700684406_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1700684406", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1700684406.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2058284250_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2058284250", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2058284250.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3769962234_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3769962234", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3769962234.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1203392406_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1203392406", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1203392406.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3948377367_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3948377367", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3948377367.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0644689494_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0644689494", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0644689494.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3079976859_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3079976859", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3079976859.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3788325922_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3788325922", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3788325922.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3821670616_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3821670616", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3821670616.didat");
}
