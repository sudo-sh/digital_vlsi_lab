/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_3453125865_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3453125865", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3453125865.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1024366090_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1024366090", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1024366090.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3979476467_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3979476467", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3979476467.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2861664035_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2861664035", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2861664035.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2919412179_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2919412179", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2919412179.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0502132496_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0502132496", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0502132496.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3147490468_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3147490468", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3147490468.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0587077798_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0587077798", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0587077798.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0236139139_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0236139139", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0236139139.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2223575826_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2223575826", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2223575826.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0738588045_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0738588045", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0738588045.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0216435863_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0216435863", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0216435863.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3043035535_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3043035535", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3043035535.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3919760131_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3919760131", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3919760131.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1293975203_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1293975203", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1293975203.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3111082672_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3111082672", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3111082672.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0553208924_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0553208924", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0553208924.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2322791993_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2322791993", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2322791993.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3601939637_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3601939637", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3601939637.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1073424414_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1073424414", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1073424414.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1892038401_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1892038401", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1892038401.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0320209467_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0320209467", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0320209467.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1093545372_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1093545372", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1093545372.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3881379368_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3881379368", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3881379368.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4137725761_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4137725761", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4137725761.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0488572414_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0488572414", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0488572414.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1344622107_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1344622107", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1344622107.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3417574413_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3417574413", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3417574413.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3350880050_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3350880050", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3350880050.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0001717574_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0001717574", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0001717574.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1138463624_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1138463624", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1138463624.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2093507646_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2093507646", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2093507646.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2792177394_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2792177394", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2792177394.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4200339088_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4200339088", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4200339088.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4132586927_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4132586927", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4132586927.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3669979018_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3669979018", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3669979018.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1546329380_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1546329380", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1546329380.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1841498041_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1841498041", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1841498041.didat");
}
