/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000001160127574_0897309690_2763677305_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2763677305", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2763677305.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3348009638_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3348009638", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3348009638.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0731771892_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0731771892", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0731771892.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0943441991_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0943441991", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0943441991.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3349572971_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3349572971", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3349572971.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3120291884_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3120291884", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3120291884.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3556792024_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3556792024", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3556792024.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1379112433_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1379112433", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1379112433.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0576629827_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0576629827", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0576629827.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1546378953_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1546378953", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1546378953.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3296159495_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3296159495", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3296159495.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_2745074728_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_2745074728", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_2745074728.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3129778196_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3129778196", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3129778196.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3294599370_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3294599370", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3294599370.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_0677643861_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_0677643861", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_0677643861.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3647954392_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3647954392", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3647954392.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3171823633_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3171823633", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3171823633.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1170617387_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1170617387", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1170617387.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3034943595_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3034943595", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3034943595.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_3015789114_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_3015789114", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_3015789114.didat");
}

extern void simprims_ver_m_00000000001160127574_0897309690_1540896139_init()
{
	xsi_register_didat("simprims_ver_m_00000000001160127574_0897309690_1540896139", "isim/rightleft_barrel_shifter_test_isim_par.exe.sim/simprims_ver/m_00000000001160127574_0897309690_1540896139.didat");
}
