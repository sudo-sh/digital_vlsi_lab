/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_4264993156_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4264993156", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4264993156.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3890578729_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3890578729", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3890578729.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0920006388_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0920006388", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0920006388.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0896168481_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0896168481", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0896168481.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0257954641_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0257954641", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0257954641.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1513744619_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1513744619", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1513744619.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3475454717_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3475454717", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3475454717.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1450771948_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1450771948", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1450771948.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1733935451_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1733935451", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1733935451.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0393731621_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0393731621", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0393731621.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3277228084_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3277228084", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3277228084.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0553237387_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0553237387", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0553237387.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3236615393_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3236615393", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3236615393.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4240995482_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4240995482", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4240995482.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1706365688_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1706365688", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1706365688.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0176161907_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0176161907", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0176161907.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0679326707_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0679326707", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0679326707.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0996679406_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0996679406", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0996679406.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2498842951_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2498842951", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2498842951.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1796811868_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1796811868", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1796811868.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3187436608_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3187436608", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3187436608.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2052851252_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2052851252", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2052851252.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3727448442_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3727448442", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3727448442.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_4022617063_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_4022617063", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_4022617063.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1236486227_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1236486227", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1236486227.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2019250894_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2019250894", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2019250894.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0308618217_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0308618217", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0308618217.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2350151389_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2350151389", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2350151389.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2313588885_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2313588885", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2313588885.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1118351962_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1118351962", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1118351962.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1605206754_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1605206754", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1605206754.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3292315892_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3292315892", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3292315892.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2886067497_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2886067497", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2886067497.didat");
}
