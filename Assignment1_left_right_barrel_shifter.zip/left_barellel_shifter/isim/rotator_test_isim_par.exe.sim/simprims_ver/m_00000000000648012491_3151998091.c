/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_2636502601_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2636502601", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2636502601.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1657645906_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1657645906", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1657645906.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1973436465_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1973436465", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1973436465.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2269818417_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2269818417", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2269818417.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2844883191_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2844883191", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2844883191.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1591649072_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1591649072", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1591649072.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2314494463_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2314494463", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2314494463.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3644452940_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3644452940", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3644452940.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0196478788_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0196478788", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0196478788.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3831093756_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3831093756", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3831093756.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4263792878_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4263792878", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4263792878.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2230776548_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2230776548", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2230776548.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0897090379_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0897090379", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0897090379.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_4274987104_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_4274987104", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_4274987104.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2934554973_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2934554973", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2934554973.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0750343820_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0750343820", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0750343820.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1119503152_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1119503152", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1119503152.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3028728101_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3028728101", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3028728101.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0711163241_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0711163241", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0711163241.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3693809024_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3693809024", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3693809024.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2196741110_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2196741110", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2196741110.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2475288813_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2475288813", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2475288813.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3810615382_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3810615382", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3810615382.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3018650085_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3018650085", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3018650085.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2024809024_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2024809024", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2024809024.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1981553892_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1981553892", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1981553892.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0788859481_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0788859481", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0788859481.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1276542356_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1276542356", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1276542356.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2538409362_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2538409362", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2538409362.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1544674871_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1544674871", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1544674871.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1634858887_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1634858887", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1634858887.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2688942073_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2688942073", "isim/rotator_test_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2688942073.didat");
}
