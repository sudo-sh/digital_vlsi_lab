/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000003359274523_2662658903_3561259681_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3561259681", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3561259681.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3594770011_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3594770011", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3594770011.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1882512879_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1882512879", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1882512879.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3417574413_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3417574413", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3417574413.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0521687300_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0521687300", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0521687300.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2609608528_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2609608528", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2609608528.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_1039957220_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_1039957220", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_1039957220.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0787499929_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0787499929", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0787499929.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2290565165_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2290565165", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2290565165.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3111082672_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3111082672", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3111082672.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3144158794_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3144158794", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3144158794.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_3853293628_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_3853293628", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_3853293628.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2093507646_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2093507646", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2093507646.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_2995593565_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_2995593565", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_2995593565.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0537634482_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0537634482", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0537634482.didat");
}

extern void simprims_ver_m_00000000003359274523_2662658903_0300137519_init()
{
	xsi_register_didat("simprims_ver_m_00000000003359274523_2662658903_0300137519", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000003359274523_2662658903_0300137519.didat");
}
