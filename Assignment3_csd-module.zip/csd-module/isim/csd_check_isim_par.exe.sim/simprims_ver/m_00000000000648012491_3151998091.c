/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif




extern void simprims_ver_m_00000000000648012491_3151998091_1187120462_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1187120462", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1187120462.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3769962234_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3769962234", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3769962234.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3512538215_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3512538215", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3512538215.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1999249363_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1999249363", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1999249363.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0736746847_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0736746847", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0736746847.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2170711866_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2170711866", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2170711866.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0436324290_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0436324290", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0436324290.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0655713422_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0655713422", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0655713422.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3161902198_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3161902198", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3161902198.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1262941767_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1262941767", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1262941767.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2043802360_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2043802360", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2043802360.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1245625503_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1245625503", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1245625503.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3705268078_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3705268078", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3705268078.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3752261964_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3752261964", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3752261964.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3964253995_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3964253995", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3964253995.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2058284250_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2058284250", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2058284250.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3998147537_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3998147537", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3998147537.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0427743712_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0427743712", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0427743712.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0714184583_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0714184583", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0714184583.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1211754597_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1211754597", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1211754597.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3205091924_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3205091924", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3205091924.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2375997163_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2375997163", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2375997163.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2397161673_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2397161673", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2397161673.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0680969085_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0680969085", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0680969085.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3979476467_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3979476467", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3979476467.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1293975203_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1293975203", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1293975203.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_3079976859_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_3079976859", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_3079976859.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0488572414_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0488572414", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0488572414.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1138463624_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1138463624", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1138463624.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2256317702_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2256317702", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2256317702.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_1915980053_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_1915980053", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_1915980053.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0351939305_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0351939305", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0351939305.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_0621949044_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_0621949044", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_0621949044.didat");
}

extern void simprims_ver_m_00000000000648012491_3151998091_2204449728_init()
{
	xsi_register_didat("simprims_ver_m_00000000000648012491_3151998091_2204449728", "isim/csd_check_isim_par.exe.sim/simprims_ver/m_00000000000648012491_3151998091_2204449728.didat");
}
